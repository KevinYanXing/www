# coding=utf-8
from basedb import BaseDB
from pymongo import MongoClient
from damyunit.dredis import DRedis

class Dmongo(object):
    """
    自己的MONGODB类
    用于网站的Models替代
    """
    def __init__(self, app=None):
        self.app = None
        self.conns = {}
        if app:
            self.init_app(app)

    def init_app(self, app, dbs='DBS'):
        self.app = app
        self.dbs = dbs
        self.status_redis = None
        if app.config.get('DB_STATUS_REDIS_URL'):
            self.status_redis = DRedis()
            self.status_redis.init_app(app, 'DB_STATUS_REDIS_')

    def conn(self, db):
        if self.status_redis:
            # 检查这个db是否存在切换记录
            status = self.status_redis.get('SWITCH.{0}'.format(db))
            if status:
                # 这里跟web是直接反过来的(这里主要是写,web是读)
                if status == '0':
                    status = '1'
                else:
                    status = '0'
                db = '{0}_{1}'.format(db, status)

        if self.conns.get(db):
            return self.conns[db]

        if db:
            prex = db + '_'
        else:
            prex = ''
        conn_settings = self.app.config.get(prex + 'MONGODB_SETTINGS', None)
        if not conn_settings:
            conn_settings = {
                'db': self.app.config.get(prex + 'MONGODB_DB', None),
                'username': self.app.config.get(prex + 'MONGODB_USERNAME', None),
                'password': self.app.config.get(prex + 'MONGODB_PASSWORD', None),
                'host': self.app.config.get(prex + 'MONGODB_HOST', None),
                'port': int(self.app.config.get(prex + 'MONGODB_PORT', 0)) or None,
                'use_greenlets': self.app.config.get(prex + 'USE_GREENLETS', False),
                'alias':db
            }
        # print conn_settings
        ret = MongoClient(host=conn_settings['host'], port=conn_settings['port'])[conn_settings['db']]
        self.conns[db] = ret
        return ret

    def __getitem__(self, item):
        return MDB(item, self)

    def __getattr__(self, item):
        if item not in ['app', 'connection'] and item[0] != '_':
            return MDB(item, self)


class MDB(BaseDB):
    """
    内部类库
    """
    def collection(self, table_name):
        return self.db()[table_name]

    def db(self):
        return self.db_self.conn(self.db_name)