# coding=utf-8
from basedb import BaseDB
from damyunit.dredis import DRedis
from pymongo import MongoClient
from datetime import date, timedelta
from time import mktime
#
'''
    这个类库只用于关键词数据库七天数据存储
'''
#
class XMongo(object):
    """
    自己的MONGODB类
    用于网站的Models替代
    """

    def __init__(self):
        self.app = None
        # self.conns = {}

    def init_app(self, app, dbs):
        self.app = app
        self.dbs = dbs
        self.status_redis = None
        # if app.config.get('DB_STATUS_REDIS_URL'):
        self.status_redis = DRedis()
        self.status_redis.init_app(app, 'DB_STATUS_REDIS_')

    def conn(self, db, id):
        # 检查这个db是否存在切换记录
        # if self.status_redis:
        status = self.status_redis.get('SWITCH.{0}'.format(db))
        status = int(status)

        id = float(id)
        id = date.today() - date.fromtimestamp(id)
        id = id.days
        if id == 0:
            id = status + 1
        else:
            id = 8 - id + 1
            if id > 8:
                raise Exception('the day not data')

            if id == 8:
                id = 0
            id += status
            if id > 8:
                id -= 8

        db = '{0}_{1}'.format(db, id)



        if db:
            prex = db + '_'
        else:
            prex = ''

        conn_settings = self.app.config.get(prex + 'MONGODB_SETTINGS', None)
        if not conn_settings:
            raise Exception('{0} db setting not exists'.format(prex))

        ret = MongoClient(conn_settings)

        return ret

    def __getitem__(self, item):
        return MDB(item, self)

    def __getattr__(self, item):
        if item not in ['app', 'connection'] and item[0] != '_':
            return MDB(item, self)

class MDB(BaseDB):
    """
    内部类库
    """
    def collection(self, table_name):
        table_name, id = table_name.split('_')
        return self.db(id)[table_name]

    def db(self, id):
        return self.db_self.conn(self.db_name, id)