# coding=utf-8
from pymongo import MongoClient
from damyunit.dredis import DRedis

class SMongo(object):
    """
    自己的MONGODB类
    用于服务的pymongo替代
    """
    def __init__(self, app=None):
        # self.dbs = None
        self.conn = {}
        if app is not None:
            self.init_app(app)

    def init_app(self, app,dbs=None):
        self.app = app
        self.status_redis = None
        if app.config.get('DB_STATUS_REDIS_URL'):
            self.status_redis = DRedis()
            self.status_redis.init_app(app, 'DB_STATUS_REDIS_')
        # self.dbs = dbs
        #
        # if not dbs :
        #     self.connection = self.make_conn(app,None)
        # else:
        #     self.muilt = True
        #     self.connection = []
        #     dbs_list = app.config.get(dbs,[])
        #     for item in dbs_list:
        #         self.connection.append(self.make_conn(app,item))

    def _make_conn(self, db_name):
        if self.status_redis:
            status = self.status_redis.get('SWITCH.{0}'.format(db_name))
            if status:
                if status == '0':
                    status = '1'
                else:
                    status = '0'
                db_name = '{0}_{1}'.format(db_name, status)

        if self.conn.get(db_name):
            return self.conn[db_name]

        if db_name:
            prex = db_name + '_'
        else:
            prex = ''

        conn_settings = self.app.config.get(prex + 'MONGODB_SETTINGS', None)
        if not conn_settings:
            conn_settings = {
                'db': self.app.config.get(prex + 'MONGODB_DB', None),
                'username': self.app.config.get(prex + 'MONGODB_USERNAME', None),
                'password': self.app.config.get(prex + 'MONGODB_PASSWORD', None),
                'host': self.app.config.get(prex + 'MONGODB_HOST', None),
                'port': int(self.app.config.get(prex + 'MONGODB_PORT', 0)) or None,
                'use_greenlets': self.app.config.get(prex + 'USE_GREENLETS', False),
                'alias':db_name
            }

        ret = MongoClient(host=conn_settings['host'], port=conn_settings['port'])[conn_settings['db']]

        self.conn[db_name] = ret

        return ret

    def _drop_database(self, db_name):
        if self.status_redis:
            status = self.status_redis.get('SWITCH.{0}'.format(db_name))
            if status:
                # 这里跟web是直接反过来的(这里主要是写,web是读)
                if status == '0':
                    status = '1'
                else:
                    status = '0'
                db_name = '{0}_{1}'.format(db_name, status)

        if db_name:
            prex = db_name + '_'
        else:
            prex = ''

        conn_settings = self.app.config.get(prex + 'MONGODB_SETTINGS', None)
        if not conn_settings:
            conn_settings = {
                'db': self.app.config.get(prex + 'MONGODB_DB', None),
                'username': self.app.config.get(prex + 'MONGODB_USERNAME', None),
                'password': self.app.config.get(prex + 'MONGODB_PASSWORD', None),
                'host': self.app.config.get(prex + 'MONGODB_HOST', None),
                'port': int(self.app.config.get(prex + 'MONGODB_PORT', 0)) or None,
                'use_greenlets': self.app.config.get(prex + 'USE_GREENLETS', False),
                'alias':db_name
            }
        return MongoClient(host=conn_settings['host'], port=conn_settings['port']).drop_database(conn_settings['db'])

    def __getattr__(self, item):
        if item not in ['init_app','app', 'conn']:
            return self._make_conn(item)


    def __getitem__(self, item):
        if item not in ['init_app', 'app', 'conn']:
            return self._make_conn(item)