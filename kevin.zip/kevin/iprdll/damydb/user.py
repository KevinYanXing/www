# coding=utf-8
from flask import request
from ext import db
from damydb.models import Models
from werkzeug import cached_property
from flask.ext.principal import RoleNeed, UserNeed
from time import time
from datetime import datetime


class User(Models):
    db = db.USER
    # 尽量避免直接使用数字
    ROLES = {5: u'演示帐号', 10: u'免费版', 11: u'试用版', 20: u'基础版', 30: u'专业版', 40: u'企业版',
             50: u'VIP会员', 100: u'客服', 101: u'推广', 300: u'管理员'}

    USER_DEMO = 5

    USER = 10
    USER_TRY = 11

    MEMBER = 20
    MEMBER_1 = 20
    MEMBER_2 = 30
    MEMBER_3 = 40

    VIP = 50
    MODERATOR = (100, 300)
    MANAGER = (101, 300)
    ADMIN = 300

    help_cls = None

    @classmethod
    def new(cls):
        return cls()

    @cached_property
    def role_name(self):
        # 取角色名
        return self.ROLES.get(self.r, u'未知')

    @staticmethod
    def get_role_name(r):
        """
        根据r取版本名称（购买时调用了此方法）
        """
        return User.ROLES.get(r, u'未知')

    @cached_property
    def get_item_monitor_num(self):
        """取当前账号能监控宝贝明细的数量 """
        num = 0
        if self.r >= self.MEMBER_2 and self.r < self.MEMBER_3:
            num = 10
        elif self.r >= self.MEMBER_3 and self.r < self.VIP:
            num = 20
        elif self.r in range(100, 301):
            num = 99999
        return num

    @cached_property
    def can_monitor_item_online_num(self):
        """当前账号是否可以重点监控宝贝"""
        if self.get_item_monitor_num > 0:
            return True
        else:
            return False

    @cached_property
    def is_free_user(self):
        """是否免费用户"""
        return self.r <= self.USER

    @cached_property
    def is_demo_user(self):
        """是否演示帐号."""
        return self.r == self.USER_DEMO

    @cached_property
    def is_try_user(self):
        """是否试用会员"""
        return self.r > self.USER and self.r < self.MEMBER

    @cached_property
    def is_member(self):
        """是否网站付费会员"""
        return self.r >= self.MEMBER

    @cached_property
    def is_member2(self):
        """是否专业版及以上的会员"""
        return self.r >= self.MEMBER_2

    @cached_property
    def is_vip(self):
        """是否网站VIP"""
        return self.r >= self.VIP

    @cached_property
    def is_master(self):
        """
        是否有后台访问权限.
        :return:
        """
        return self.r >= 100

    @cached_property
    def is_moderator(self):
        """是否客服"""
        return self.r in self.MODERATOR

    @cached_property
    def is_manager(self):
        """是否推广"""
        return self.r in self.MANAGER

    @cached_property
    def is_admin(self):
        """是否超级管理员"""
        return self.r == self.ADMIN

    @cached_property
    def expire_day(self):
        """
        离过期的剩余天数
        -1 表示不会过期.
        0 表示已经过期.
        :return:
        """
        if not self.re:
            return -1
        time_span = self.re - time()
        if time_span < 0:
            return 0
        time_span = int(time_span / 86400)
        if time_span == 0:
            time_span = 1
        return time_span

    @cached_property
    def re_date(self):
        """
        到期时间
        :return:
        """
        if not self.re:
            return u'无限'

        try:
            return datetime.fromtimestamp(self.re).strftime('%Y-%m-%d')
        except:
            return u'错误时间'

    @cached_property
    def add_date(self):
        """
        注册时间
        :return:
        """
        if not self.d:
            return u'无'

        try:
            return datetime.fromtimestamp(self.d).strftime('%Y-%m-%d %H:%M')
        except:
            return u'错误时间'

    @cached_property
    def lastdate_date(self):
        """
        注册时间
        :return:
        """
        if not self.lastdate:
            return u'未登陆过'

        val = ''
        try:
            val = datetime.fromtimestamp(self.lastdate).strftime('%Y-%m-%d %H:%M')
        except:
            return u'错误时间'

        return u'<span title="'+ val +u'">'+ self.time_left(self.lastdate) + u'</span>'

    @staticmethod
    def time_left(ts):
        """
        计算多少小时或者多少天之前
        :param ts:
        :return:
        """
        ts = float(ts)
        tleft = time() - ts
        if tleft < 86400:
            val = int(tleft / 3600)
            if val == 0:
                return u'刚刚'
            return u'%d小时前' % val

        return u'%d天前' % int(tleft / 86400)


    @cached_property
    def provides(self):
        '用于登录验证提供'
        needs = [RoleNeed('authenticated'), UserNeed(self.mongo_id)]
        if not self.is_demo_user:
            needs.append(RoleNeed('member'))
        if self.is_vip:
            needs.append(RoleNeed('vip'))
        if self.is_master:
            needs.append(RoleNeed('master'))
        if self.is_moderator:
            needs.append(RoleNeed('moderator'))
        if self.is_manager:
            needs.append(RoleNeed('manager'))
        if self.is_admin:
            needs.append(RoleNeed('admin'))

        return needs

    def get_ip_addr(self):
        """
        获取IP地址的方法
        :return:
        """
        if request.headers.getlist("X-Forwarded-For"):
           ip = request.headers.getlist("X-Forwarded-For")[0]
        else:
           ip = request.environ.get('HTTP_X_REAL_IP', request.remote_addr)
        return ip


    def updater(self):
        """
        更新用户的最后登陆信息
        """
        self.lastip = self.currip
        self.lastdate = self.currdate
        self.currip = self.get_ip_addr()
        self.currdate = time()
        # 检查套餐到期时间
        # if self.r > self.USER and self.re and self.re < time():
        #     rr = self.r
        #     self.r = self.USER
        #     self.re = None
        #     if hasattr(self, 'role_change') and self.role_change:
        #         self.role_change(rr)
        self.save()

    def new_init(self):
        """
        新注册初始化用户一些基本数据
        :return:
        """
        pass

    @cached_property
    def qq_accounts(self):
        """
        获取已绑定的QQ列表
        """
        return QQOpenID.query(uid=self.mongo_id)

    @cached_property
    def helper(self):
        """
        返回帮助类
        """
        if self.help_cls:
            return self.help_cls(self)

class QQOpenID(Models):
    """
    QQ绑定的oepnid库
    _id
    openid
    nick    昵称
    uid 未绑定之前此uid为空
    face   头像
    d   加入日期
    """
    db = db.USER

    @cached_property
    def user(self):
        return User.one(self.uid)