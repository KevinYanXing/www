# coding=utf-8

class FormAction(object):
    def __init__(self, text, opr, ico='icon-trash', handler='operFunction', btnCls='button-success'):
        self.text = text
        self.opr = opr
        self.ico = ico
        self.handler = handler
        self.btnCls = btnCls

    def __str__(self):
        return "{text: '<i class=\"icon-white %s\" opr=\"%s\"></i>%s', btnCls: 'button %s', handler: %s}" % (self.ico, self.opr, self.text, self.btnCls, self.handler)