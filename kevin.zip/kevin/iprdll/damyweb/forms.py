# coding=utf-8
from flask import request
from werkzeug import cached_property
import json


class BaseForm:

    SUCCESS = 1
    FAILD = 0
    INIT = -1

    @cached_property
    def column_obj(self):
        return ColumnObj()

    def __init__(self, view=None, obj=None):
        self.view = view
        self.name = __name__.lower()
        # self.items = []
        self.button = u'保存'
        # self.column = []
        self.obj = obj
        self.errors = []
        self.after_init()
        # 如果是提交后的就不再赋值了，直接从form里面取数据了
        self.result = self.INIT
        if self.is_submitted():
            formdata = request.form
            if request.files:
                formdata = formdata.copy()
                formdata.update(request.files)
            if not self.set_value_form(formdata):
                # 验证失败，将不再做任何处理
                self.result = self.FAILD
                self.faild()
            else:
                # 验证完毕，开始处理数据
                if self.submit():
                    self.result = self.SUCCESS
                else:
                    self.result = self.FAILD
        elif obj:
            self.set_value(obj)
        else:
            self.add_init()

    def add_init(self):
        """
        新增数据之前先对表单进行相关处理
        :return:
        """
        pass

    def is_submitted(self):
        """
        Checks if form has been submitted. The default case is if the HTTP
        method is **PUT** or **POST**.
        """
        return request and request.method in ("PUT", "POST")

    def faild(self):
        """
        控件未经过验证
        :return:
        """
        pass


    def submit(self):
        """
        对提交后的数据处理
        :return:
        """
        return True

    def set_value_form(self, form):
        success = True
        # 先赋值
        for item in self.items:
            # 基于控件的验证, 木有?
            if form.get(item.name):
                item.value = form[item.name]
                # print item.name, item.value

        # 再验证
        for item in self.items:
            # print item.value, item.name
            # 基于表单里面的验证
            if item.t == 'html': continue
            '''
            if hasattr(item, 'validate'):
                try:
                    item.validate()
                except ValueError as e:
                    self.errors.append({'item': item, 'error': e})
                    success = False
                    continue
            '''
            if hasattr(self, 'validate_' + item.name):
                try:
                    getattr(self, 'validate_' + item.name)(item)
                except ValueError as e:
                    self.errors.append({'item': item, 'error': e})
                    success = False

        return success

    def load_objval(self, obj):
        """
        加载
        :param obj:
        :return:
        """

        for item in self.items:
            # print item.name, item.value
            if type(item) == RePasswordField or item.t == 'html': continue
            if hasattr(self, 'value_' + item.name):
                # print item.value, item.name
                val = getattr(self, 'value_' + item.name)(item, obj)
            else:
                val = item.value
            setattr(obj, item.name, val)
        return self.ext_set_obj(obj)


    def ext_set_obj(self, obj):
        """
        额外设置数据
        :param obj:
        :return:
        """
        pass

    def set_value(self, obj):
        """
        对表单赋值
        :param obj:
        :return:
        """
        for item in self.items:
            if type(item) == PasswordField or type(item) == RePasswordField: continue
            if hasattr(obj, item.name):
                item.value = getattr(obj, item.name)
                if hasattr(self, 'set_value_' + item.name):
                    item.value = getattr(self, 'set_value_' + item.name)(item.value, obj)

    def after_init(self):
        pass


    @cached_property
    def items(self):
        vals = self.__dict__.iteritems()
        vals = sorted(vals, cmp=lambda x, y: cmp(x[0], y[0]))
        ret = []
        for item, val in vals:
            if isinstance(val, BaseField):
                ret.append(val)
        return ret


    @cached_property
    def column(self):
        vals = self.__dict__.iteritems()
        vals = sorted(vals, cmp=lambda x, y: cmp(x[0], y[0]))
        ret = []
        for item, val in vals:
            if isinstance(val, Column):
                ret.append(val)
        return ret

    @cached_property
    def columns(self):
        vals = self.__dict__.iteritems()
        vals = sorted(vals, cmp=lambda x, y: cmp(x[0], y[0]))
        ret = []
        for item, val in vals:
            if isinstance(val, Column):
                ret.append(val.json)
        return '[%s]' % ','.join(ret)

    def errors_text(self, formate='%s%s'):
        ret = []
        for item in self.errors:
            ret.append(formate % (item['item'].text, item['error']))
        return ''.join(ret)

class BaseField(object):
    def __init__(self, **kwargs):
        self.name = ''
        self.text = ''
        self.value = ''
        self.width = 15
        self.t = 'BASE'
        self.required = False
        for k, v in kwargs.iteritems():
            setattr(self, k, v)

    def __str__(self):
        return '%s-%s=%s' % (self.name, self.text, self.value)

class HtmlField(BaseField):
    def __init__(self, **kwargs):
        super(HtmlField, self).__init__(**kwargs)
        self.t = 'html'

class EditField(BaseField):
    def __init__(self, **kwargs):
        super(EditField, self).__init__(**kwargs)
        self.t = 'edit'


class SelectField(BaseField):
    def __init__(self, **kwargs):
        super(SelectField, self).__init__(**kwargs)
        self.t = 'select'


    @cached_property
    def items_json(self):
        if not self.items:
            return None
        return json.dumps(self.items)


class InputField(BaseField):
    def __init__(self, **kwargs):
        super(InputField, self).__init__(**kwargs)
        self.t = 'input'

class HiddenField(BaseField):
    def __init__(self, **kwargs):
        super(HiddenField, self).__init__(**kwargs)
        self.t = 'hidden'

class FileField(BaseField):
    """
    必须有以下参数:
    upload  上传地址
    delete  删除地址，删除标示ID为: -id-
    url     文件地址
    ext     扩展名
    value   为文件列表，特殊数据，字典形式 {'name':'', 'id':'', url:''}
    """
    def __init__(self, **kwargs):
        super(FileField, self).__init__(**kwargs)
        self.t = 'file'


class PasswordField(BaseField):
    def __init__(self, **kwargs):
        super(PasswordField, self).__init__(**kwargs)
        self.t = 'password'

class RePasswordField(BaseField):
    def __init__(self, **kwargs):
        super(RePasswordField, self).__init__(**kwargs)
        self.t = 'repassword'


class DateField(BaseField):
    def __init__(self, **kwargs):
        super(DateField, self).__init__(**kwargs)
        self.t = 'date'

class TextField(BaseField):
    def __init__(self, **kwargs):
        super(TextField, self).__init__(**kwargs)
        self.t = 'text'

class TreeField(BaseField):
    def __init__(self, **kwargs):
        super(TreeField, self).__init__(**kwargs)
        self.t = 'tree'


class ColumnObj(dict):
    def __getattr__(self, item):
        return "'+ obj." + item + " +'"


class Column:

    def __init__(self, title, dataIndex=None, width=100, render=None, fun = False):
        self.attrs = {}
        self.attrs['title'] = title
        if dataIndex:
            self.attrs['dataIndex'] = dataIndex
        if render:
            render = "function(v,obj){ return '" + render + "';}"
            self.render = render
        else:
            self.render = None
        self.attrs['width'] = width
        self.fun = fun

    @cached_property
    def json(self):
        ret = json.dumps(self.attrs)
        if self.render:
            ret = ret[0:-1] + ',"renderer":' + self.render + '}'
        return ret