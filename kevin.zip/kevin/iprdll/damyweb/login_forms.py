# coding=utf-8
from baseform import BaseForm, SuccessResp, ErrorResp
from flask.ext.principal import identity_changed, Identity
from flask import session, url_for, request, current_app, flash, render_template
from wtforms import HiddenField, PasswordField, StringField, ValidationError, IntegerField
from wtforms.validators import required, equal_to, Length
from hashlib import md5
from time import time
from bson import ObjectId


def login(user_id):
    identity_changed.send(current_app._get_current_object(), identity=Identity(str(user_id)))


class MobileField(StringField):
    """
        需要发手机验证码的
    """
    tag = 'mobile'
    def __init__(self, act, vd, **kwargs):
        self.act = act
        self.vd = vd
        super(MobileField, self).__init__(**kwargs)

class CodeField(StringField):
    """
    This field is the base for most of the more complicated fields, and
    represents an ``<input type="text">``. resubmit
    """
    tag = 'code'

    def __init__(self, img, **kwargs):
        self.img = img
        super(CodeField, self).__init__(**kwargs)



class BaseLoginForm(BaseForm):
    def __init__(self, model, view, **kwargs):
        super(BaseLoginForm, self).__init__(**kwargs)
        self.model = model
        self.view = view
        self.bcrypt = getattr(view, 'bcrypt')

    def render(self, template, **kwargs):
        kwargs['form'] = self
        kwargs['view'] = self.view
        kwargs['admin_view'] = self.view
        kwargs['config'] = current_app.config
        return render_template(template, **kwargs)


class QQLoginForm(BaseLoginForm):
    name = u'已有账号登陆'
    button = u'确定'

    next = HiddenField()
    username = StringField(u"手机号", validators=[required(message=u'请输入您的手机号')], description='xe603')
    password = PasswordField(u"密码", validators=[required(message=u'请输入密码')], description='xe600')
    validatecode = CodeField(img='/login/validcode?r=qqlogin',  label=u"验证码", validators=[required(message=u'请输入验证码。')], description='xe607')

    def validate_validatecode(self, field):
        """
        验证
        """
        if len(field.errors) > 0:
            return False

        if session.get('vcode') is None:
            raise ValidationError, u'验证码已经过期'

        if field.data.strip() != str(session['vcode'].strip()):
            raise ValidationError, u'验证码错误'

        # del(session['vcode'])

    def validate_username(self, field):
        if field.data:
            field.data = field.data.strip().lower()

    def getItem(self, username, psw):
        """
        获取一条数据，根据用户名和密码， 在哪里指定加密方法
        :param username:
        :param psw:
        :return:
        """
        user = self.model.findone(u=username)
        if not user:
            return None

        if self.bcrypt == 'md5':
            md = md5()
            md.update(psw)
            psw = md.hexdigest()
            if psw != user.p:
                return None
        elif self.bcrypt:
            if not user.p or not psw or not self.bcrypt.check_password_hash(user.p, psw):
                return None

        return user

    def submit(self):
        from damydb.user import QQOpenID
        q = request.args.get('q')
        if q:
            try:
                q = ObjectId(q)
            except:
                q = None
        if q:
            q = QQOpenID.one(q)


        if not q or q.uid:
            raise ErrorResp(message=u'完善信息失败，请联系管理员')

        user = self.getItem(self.username.data, self.password.data)
        if user:
            q.uid = user.mongo_id
            q.save()
            raise LoginForm.Login(user.mongo_id, False, self.next.data)
        else:
            raise ErrorResp(message=u'登录失败，用户名或者密码错误')


class QQRegForm(BaseLoginForm):
    name = u'完善用户信息'
    button = u'确定'

    next = HiddenField()
    validatecode = CodeField(img='/login/validcode?r=qqreg', label=u"验证码", validators=[required(message=u'请输入验证码。')], description='xe607')
    username = MobileField(act='3553', vd='validatecode', label=u"手机号", validators=[required(message=u'请输入手机号。'), Length(min = 11, max = 11, message=u'请输入11位手机号码')], description = 'xe603')
    msgcode = StringField(u"请输入手机短信码", validators=[required(message=u'请输入验证码'), Length(min=5,max = 5, message=u"校验码只有五位")], description = 'xe607')
    qq = IntegerField(u"QQ", validators=[required(message=u'请输入QQ')], description='xe606')
    nickname = StringField(u"昵称", validators=[required(message=u'请输入昵称')], description='xe605')
    # uf = StringField(u"邀请ID(无可留空)", description='xe605')

    # def validate_uf(self, field):
    #     """
    #     验证邀请人ID
    #     :param field:
    #     :return:
    #     """
    #     field.data = field.data.strip()
    #     if not field:
    #         return
    #     try:
    #         field.data = int(field.data)
    #     except:
    #         raise ValidationError, u'请输入正确的邀请ID'
    #
    #     item = self.model.findone(agent_code=field.data)
    #     if not item:
    #         raise ValidationError, u'该邀请人不存在,请核对您的邀请ID'


    def validate_msgcode(self, field):
        """
        验证是否已经收到
        """
        from sms import SMS
        field.data = field.data.strip()
        send_key = SMS.getVal(self.username.data, self.view.redis)
        if not send_key:
            raise ValidationError, u'手机短信码已经过期'
        if field.data != send_key:
            raise ValidationError, u'手机短信码错误'

    def user_bykey(self, key, val):
        return self.model.findone(**{key: val})

    def validate_username(self, field):
        if len(field.errors) > 0:
            return False
        field.data = field.data.lower().strip()
        for item in field.data:
            try:
                item = int(item)
            except:
                raise ValidationError, u'请输入正确的手机号码'

        user = self.user_bykey('u', field.data)
        if user:
            raise ValidationError, u"此用户名已被注册。"

    def validate_nickname(self, field):
        if len(field.errors) > 0:
            return False
        field.data = field.data.lower().strip()
        user = self.user_bykey('n', field.data)
        if user:
            raise ValidationError, u"此昵称已被注册。"

    def submit(self):
        # 如果包含q的参数的话,直接绑定
        from damydb.user import QQOpenID
        q = request.args.get('q')
        if q:
            try:
                q = ObjectId(q)
            except:
                q = None
        if q:
            q = QQOpenID.one(q)

        if not q or q.uid:
            raise ErrorResp(message=u'完善信息失败，请联系管理员')

        obj = self.model.new()
        obj.u = self.username.data
        obj.p = None
        obj.n = self.nickname.data
        # 初始
        r_config = current_app.config['REG_START_ROLES']
        obj.r = r_config['r']
        obj.re = time() + r_config['d'] * 86400
        # 覆盖来源,如果指定了代理ID的话
        # if self.uf.data:
        #     obj.z = self.uf.data
        obj.d = time()
        obj.q = self.qq.data
        if hasattr(obj, 'new_init'):
            obj.new_init()
        u_id = obj.save()
        if u_id:
            q.uid = u_id
            q.save()
            flash(u'完善信息完毕')
            next_url = request.args.get('next')
            if not next_url:
                next_url = url_for('member.index')
            raise LoginForm.Login(u_id, False, next_url)
        else:
            raise ErrorResp(message=u'注册失败，请联系管理员')


class RegForm(BaseLoginForm):
    name = u'用户注册'
    button = u'注册账号'
    validatecode = CodeField(img='/login/validcode?r=reg', label=u"验证码", validators=[required(message=u'请输入验证码。')], description='xe607')
    username = MobileField(act='3553', vd='validatecode', label=u"手机号", validators=[required(message=u'请输入手机号。'), Length(min = 11, max = 11, message=u'请输入11位手机号码')], description = 'xe603')
    msgcode = StringField(u"请输入手机短信码", validators=[required(message=u'请输入验证码'), Length(min=5,max = 5, message=u"校验码只有五位")], description = 'xe607')
    password = PasswordField(u"登录密码", validators=[required(message=u'请输入密码'), Length(min = 6, max = 20, message=u'密码位数应该在6至20个之间')], description= 'xe600')
    repassword = PasswordField(u"确认密码", validators=[required(message=u'再输一次密码'), Length(min = 6, max = 20, message=u'密码位数应该在6至20个之间')], description= 'xe604')
    qq = IntegerField(u"QQ", validators=[required(message=u'请输入QQ')], description='xe606')
    nickname = StringField(u"昵称", validators=[required(message=u'请输入昵称')], description='xe605')
    # uf = StringField(u"邀请ID(无可留空)", description='xe605')
    # def validate_validatecode(self, field):
    #     if len(field.errors) > 0:
    #         return False
    #
    #     if session.get('vcode') is None or field.data != session['vcode']:
    #         raise ValidationError, u'验证码错误或已经过期'

    # def validate_qq(self, field):
    #     """
    #     验证QQ号码是否正确
    #     :param field:
    #     :return:
    #     """
    #     field.data = field.data.strip()
    #     for item in

    def validate_msgcode(self, field):
        """
        验证是否已经收到
        """
        from sms import SMS
        field.data = field.data.strip()
        send_key = SMS.getVal(self.username.data, self.view.redis)
        if not send_key:
            raise ValidationError, u'手机短信码已经过期'
        if field.data != send_key:
            raise ValidationError, u'手机短信码错误'

    def user_bykey(self, key, val):
        return self.model.findone(**{key: val})

    # def validate_repassword(self, field):
    #     field.data = field.data.strip()
    #     normal_val = field.data
    #     if self.bcrypt == 'md5':
    #         md = md5()
    #         md.update(field.data)
    #         field.data = md.hexdigest()
    #     elif self.bcrypt:
    #         field.data = self.bcrypt.generate_password_hash(field.data)
    #
    #     print field.data, self.password.data, normal_val
    #     if field.data != self.password.data and normal_val != self.password.data:
    #         raise ValidationError, u'两次输入密码不一致'
    # def validate_uf(self, field):
    #     """
    #     验证邀请人ID
    #     :param field:
    #     :return:
    #     """
    #     field.data = field.data.strip()
    #     if not field:
    #         return
    #     try:
    #         field.data = int(field.data)
    #     except:
    #         raise ValidationError, u'请输入正确的邀请ID'
    #
    #     item = self.model.findone(agent_code=field.data)
    #     if not item:
    #         raise ValidationError, u'该邀请人不存在,请核对您的邀请ID'

    def validate_password(self, field):

        field.data = field.data.strip()
        if field.data != self.repassword.data:
            raise ValidationError, u'两次输入密码不一致'

        if self.bcrypt == 'md5':
            md = md5()
            md.update(field.data)
            field.data = md.hexdigest()
        elif self.bcrypt:
            field.data = self.bcrypt.generate_password_hash(field.data)

    def validate_username(self, field):
        if len(field.errors) > 0:
            return False
        field.data = field.data.lower().strip()
        for item in field.data:
            try:
                item = int(item)
            except:
                raise ValidationError, u'请输入正确的手机号码'

        user = self.user_bykey('u', field.data)
        if user:
            raise ValidationError, u"此用户名已被注册。"

    def validate_nickname(self, field):
        if len(field.errors) > 0:
            return False
        field.data = field.data.lower().strip()
        user = self.user_bykey('n', field.data)
        if user:
            raise ValidationError, u"此昵称已被注册。"

    def submit(self):
        obj = self.model.new()
        obj.u = self.username.data
        obj.p = self.password.data
        obj.n = self.nickname.data

        r_config = current_app.config['REG_START_ROLES']
        obj.r = r_config['r']
        obj.re = time() + r_config['d'] * 86400
        # 覆盖来源,如果指定了代理ID的话
        # if self.uf.data:
        #     obj.z = self.uf.data
        obj.d = time()
        obj.q = self.qq.data
        if hasattr(obj, 'new_init'):
            obj.new_init()
        u_id = obj.save()
        if u_id:
            flash(u'注册成功')
            next_url = request.args.get('next')
            if not next_url:
                next_url = url_for('member.index')
            raise LoginForm.Login(u_id, False, next_url)
        else:
            raise ErrorResp(message=u'注册失败，请联系管理员')


class LoginForm(BaseLoginForm):
    name = u'用户登陆'
    button = u'马上登陆'

    next = HiddenField()
    username = StringField(u"手机号", validators=[required(message=u'请输入您的手机号')], description='xe603')
    password = PasswordField(u"密码", validators=[required(message=u'请输入密码')], description='xe600')
    validatecode = CodeField(img='/login/validcode?r=login', label=u"验证码", validators=[required(message=u'请输入验证码。')], description='xe607')

    def validate_validatecode(self, field):
        """
        验证
        """
        if len(field.errors) > 0:
            return False

        if session.get('vcode') is None:
            raise ValidationError, u'验证码已经过期'

        if field.data.strip() != str(session['vcode'].strip()):
            raise ValidationError, u'验证码错误'

        # del(session['vcode'])

    def validate_username(self, field):
        if field.data:
            field.data = field.data.strip().lower()

    def getItem(self, username, psw):
        """
        获取一条数据，根据用户名和密码， 在哪里指定加密方法
        :param username:
        :param psw:
        :return:
        """
        user = self.model.findone(u=username)
        if not user:
            return None

        if self.bcrypt == 'md5':
            md = md5()
            md.update(psw)
            psw = md.hexdigest()
            if psw != user.p:
                return None
        elif self.bcrypt:
            try:
                if not self.bcrypt.check_password_hash(user.p, psw):
                    return None
            except:
                return None

        return user

    def submit(self):
        user = self.getItem(self.username.data, self.password.data)
        if user:
            raise self.Login(user.mongo_id, False, self.next.data)
        else:
            raise ErrorResp(message=u'登录失败，用户名或者密码错误')

    @staticmethod
    def Login(user_id, remeber, next_url=None, admin_id=None):
        '''
            保存登录信息
        '''
        # 记住密码
        session.permanent = remeber
        if admin_id:
            session.admin_id = admin_id
        # 保存session
        login(user_id)
        if next_url is None or not next_url or next_url == request.path:
            next_url = current_app.config.get('USER_INDEX') or url_for('frontend.index')


        # 跳转到链接
        return SuccessResp(message=u'', url=next_url, redirect=True)


class ForgotForm(BaseLoginForm):
    name = u'找回密码'
    button = u'找回密码'
    validatecode = CodeField(img='/login/validcode?r=forgot', label=u"验证码", validators=[required(message=u'请输入验证码。')], description='xe607')
    username = MobileField(act='6000', vd='validatecode', label=u"手机号", validators=[required(message=u'请输入手机号。'), Length(min = 11, max = 11, message=u'请输入11位手机号码')], description = 'xe603')
    msgcode = StringField(u"请输入手机短信码", validators=[required(message=u'请输入验证码'), Length(min=5,max = 5, message=u"校验码只有五位")], description = 'xe607')
    password = PasswordField(u"新密码", validators=[required(message=u'请输入密码'), Length(min = 6, max = 20, message=u'密码位数应该在6至20个之间')], description= 'xe600')
    repassword = PasswordField(u"确认密码", validators=[required(message=u'再输一次密码'), Length(min = 6, max = 20, message=u'密码位数应该在6至20个之间')], description= 'xe604')

    def validate_msgcode(self, field):
        """
        验证是否已经收到
        """
        from sms import SMS
        if not self.username.data:
            raise ValidationError, u'请输入登陆名'

        if type(self.username.data) == unicode:
            user = self.user_bykey('u', self.username.data)
        else:
            user = self.username.data
        if not user:
            raise ValidationError, u'请输入正确的登陆名'

        field.data = field.data.strip()
        send_key = SMS.getVal(user.u, self.view.redis)
        if not send_key or field.data != send_key:
            raise ValidationError, u'校验码错误或已经过期'

    def user_bykey(self, key, val):
        return self.model.findone(**{key: val})

    def validate_password(self, field):
        field.data = field.data.strip()
        if field.data != self.repassword.data:
            raise ValidationError, u'两次输入密码不一致'
        if self.bcrypt == 'md5':
            md = md5()
            md.update(field.data)
            field.data = md.hexdigest()
        elif self.bcrypt:
            field.data = self.bcrypt.generate_password_hash(field.data)

    def validate_username(self, field):
        if len(field.errors) > 0:
            return False
        field.data = field.data.lower().strip()
        for item in field.data:
            try:
                item = int(item)
            except:
                raise ValidationError, u'请输入正确的手机号码'

        user = self.user_bykey('u', field.data)
        if not user:
            raise ValidationError, u"用户不存在。"

        field.data = user

    def submit(self):
        obj = self.username.data
        obj.p = self.password.data
        u_id = obj.save()
        if u_id:
            flash(u'重设密码成功')
            raise LoginForm.Login(u_id, False, url_for('member.index'))
        else:
            raise ErrorResp(message=u'注册失败，请联系管理员')