# coding=utf-8
from functools import wraps
from flask import Blueprint, current_app, render_template, abort, g, url_for, request, redirect, jsonify, session
import helpers as h
from _compat import with_metaclass
from menu import MenuCategory, MenuView, Menu
from werkzeug import cached_property
from baseform import damy
from login_forms import LoginForm, RegForm, ForgotForm, QQRegForm, QQLoginForm
from flask.ext.principal import Principal, identity_loaded, identity_changed, AnonymousIdentity
from bson import ObjectId
import permissions as per
from redis import Redis
from cross_session import RedisSessionInterface
from helpers import get_ip_addr


def expose(url='/', methods=('GET',)):
    """
        Use this decorator to expose views in your view classes.
        :param url:
            Relative URL for the view
        :param methods:
            Allowed HTTP methods. By default only GET is allowed.
    """
    def wrap(f):
        if not hasattr(f, '_urls'):
            f._urls = []
        f._urls.append((url, methods))
        return f
    return wrap


def expose_plugview(url='/'):
    """
        Decorator to expose Flask's pluggable view classes
        (``flask.views.View`` or ``flask.views.MethodView``).
        :param url:
            Relative URL for the view
        .. versionadded:: 1.0.4
    """
    def wrap(v):
        handler = expose(url, v.methods)

        if hasattr(v, 'as_view'):
            return handler(v.as_view(v.__name__))
        else:
            return handler(v)

    return wrap


# Base views
def _wrap_view(f):
    # Avoid wrapping view method twice
    if hasattr(f, '_wrapped'):
        return f

    @wraps(f)
    def inner(self, *args, **kwargs):
        # Store current admin view
        h.set_current_view(self)

        # Check if administrative piece is accessible
        abort = self._handle_view(f.__name__, **kwargs)
        if abort is not None:
            return abort

        return self._run_view(f, *args, **kwargs)

    inner._wrapped = True

    return inner


class AdminViewMeta(type):

    def __init__(cls, classname, bases, fields):
        type.__init__(cls, classname, bases, fields)

        # Gather exposed views
        cls._urls = []
        cls._default_view = None

        for p in dir(cls):
            attr = getattr(cls, p)

            if hasattr(attr, '_urls'):
                # Collect methods
                for url, methods in attr._urls:
                    cls._urls.append((url, p, methods))

                    if url == '/':
                        cls._default_view = p

                # Wrap views
                setattr(cls, p, _wrap_view(attr))


class BaseViewClass(object):
    pass


class BaseView(with_metaclass(AdminViewMeta, BaseViewClass)):

    @property
    def _template_args(self):
        """
            Extra template arguments.
            If you need to pass some extra parameters to the template,
            you can override particular view function, contribute
            arguments you want to pass to the template and call parent view.
            These arguments are local for this request and will be discarded
            in the next request.
            Any value passed through ``_template_args`` will override whatever
            parent view function passed to the template.
            For example::
                class MyAdmin(ModelView):
                    @expose('/')
                    def index(self):
                        self._template_args['name'] = 'foobar'
                        self._template_args['code'] = '12345'
                        super(MyAdmin, self).index()
        """
        args = getattr(g, '_admin_template_args', None)

        if args is None:
            args = g._admin_template_args = dict()

        return args

    def __init__(self, name=None, category=None, endpoint=None, url=None,
                 static_folder=None, static_url_path=None,
                 menu_class_name=None, menu_icon_type=None, menu_icon_value=None):
        """
            Constructor.
            :param name:
                Name of this view. If not provided, will default to the class name.
            :param category:
                View category. If not provided, this view will be shown as a top-level menu item. Otherwise, it will
                be in a submenu.
            :param endpoint:
                Base endpoint name for the view. For example, if there's a view method called "index" and
                endpoint is set to "myadmin", you can use `url_for('myadmin.index')` to get the URL to the
                view method. Defaults to the class name in lower case.
            :param url:
                Base URL. If provided, affects how URLs are generated. For example, if the url parameter
                is "test", the resulting URL will look like "/admin/test/". If not provided, will
                use endpoint as a base url. However, if URL starts with '/', absolute path is assumed
                and '/admin/' prefix won't be applied.
            :param static_url_path:
                Static URL Path. If provided, this specifies the path to the static url directory.
            :param menu_class_name:
                Optional class name for the menu item.
            :param menu_icon_type:
                Optional icon. Possible icon types:
                 - `flask.ext.admin.consts.ICON_TYPE_GLYPH` - Bootstrap glyph icon
                 - `flask.ext.admin.consts.ICON_TYPE_IMAGE` - Image relative to Flask static directory
                 - `flask.ext.admin.consts.ICON_TYPE_IMAGE_URL` - Image with full URL
            :param menu_icon_value:
                Icon glyph name or URL, depending on `menu_icon_type` setting
        """
        self.name = name
        self.category = category
        self.endpoint = endpoint
        self.url = url
        self.static_folder = static_folder
        self.static_url_path = static_url_path
        self.menu = None

        self.menu_class_name = menu_class_name
        self.menu_icon_type = menu_icon_type
        self.menu_icon_value = menu_icon_value

        # Initialized from create_blueprint
        self.admin = None
        self.blueprint = None

        # Default view
        if self._default_view is None:
            raise Exception(u'Attempted to instantiate admin view %s without default view' % self.__class__.__name__)

    def create_blueprint(self, admin):
        """
            Create Flask blueprint.
        """
        # Store admin instance
        self.admin = admin

        # If endpoint name is not provided, get it from the class name
        if self.endpoint is None:
            self.endpoint = self.__class__.__name__.lower()

        # If the static_url_path is not provided, use the admin's
        if not self.static_url_path:
            self.static_url_path = admin.static_url_path

        # If url is not provided, generate it from endpoint name
        if self.url is None:
            if self.admin.url != '/':
                self.url = '%s/%s' % (self.admin.url, self.endpoint)
            else:
                if self == admin.index_view:
                    self.url = '/'
                else:
                    self.url = '/%s' % self.endpoint
        else:
            if not self.url.startswith('/'):
                self.url = '%s/%s' % (self.admin.url, self.url)


        # If we're working from the root of the site, set prefix to None
        if self.url == '/':
            self.url = None
            # prevent admin static files from conflicting with flask static files
            if not self.static_url_path:
                self.static_folder='static'
                self.static_url_path='/static/admin'


        # If name is not povided, use capitalized endpoint name
        if self.name is None:
            self.name = self._prettify_class_name(self.__class__.__name__)

        # Create blueprint and register rules

        self.blueprint = Blueprint(self.endpoint, __name__,
                                   url_prefix=self.url,
                                   subdomain=self.admin.subdomain,
                                   template_folder='templates',
                                   static_folder=self.static_folder,
                                   static_url_path=self.static_url_path)

        for url, name, methods in self._urls:
            self.blueprint.add_url_rule(url,
                                        name,
                                        getattr(self, name),
                                        methods=methods)

        return self.blueprint


    @cached_property
    def new_url(self):
        return self.get_url('.create_view')

    def render(self, template, **kwargs):
        """
            Render template
            :param template:
                Template path to render
            :param kwargs:
                Template arguments
        """
        # Store self as admin_view
        kwargs['admin_view'] = self
        kwargs['admin_base_template'] = self.admin.base_template

        # Provide i18n support even if flask-babel is not installed
        # or enabled.
        # kwargs['_gettext'] = babel.gettext
        # kwargs['_ngettext'] = babel.ngettext
        kwargs['h'] = h

        # Expose get_url helper
        kwargs['get_url'] = self.get_url

        # Expose config info
        kwargs['config'] = current_app.config

        # Contribute extra arguments
        kwargs.update(self._template_args)

        return render_template(template, **kwargs)

    def _prettify_class_name(self, name):
        """
            Split words in PascalCase string into separate words.
            :param name:
                String to prettify
        """
        return h.prettify_class_name(name)

    def is_visible(self):
        """
            Override this method if you want dynamically hide or show administrative views
            from Flask-Admin menu structure
            By default, item is visible in menu.
            Please note that item should be both visible and accessible to be displayed in menu.
        """
        return True

    def is_accessible(self):
        """
            Override this method to add permission checks.
            Flask-Admin does not make any assumptions about the authentication system used in your application, so it is
            up to you to implement it.
            By default, it will allow access for everyone.
        """
        return True

    def _handle_view(self, name, **kwargs):
        """
            This method will be executed before calling any view method.
            It will execute the ``inaccessible_callback`` if the view is not
            accessible.
            :param name:
                View function name
            :param kwargs:
                View function arguments
        """
        if not self.is_accessible():
            return self.inaccessible_callback(name, **kwargs)

    def _run_view(self, fn, *args, **kwargs):
        """
            This method will run actual view function.
            While it is similar to _handle_view, can be used to change
            arguments that are passed to the view.
            :param fn:
                View function
            :param kwargs:
                Arguments
        """
        return fn(self, *args, **kwargs)

    def inaccessible_callback(self, name, **kwargs):
        """
            Handle the response to inaccessible views.
            By default, it throw HTTP 403 error. Override this method to
            customize the behaviour.
        """
        return abort(403)

    @staticmethod
    def get_url(endpoint, **kwargs):
        """
            Generate URL for the endpoint. If you want to customize URL generation
            logic (persist some query string argument, for example), this is
            right place to do it.
            :param endpoint:
                Flask endpoint name
            :param kwargs:
                Arguments for `url_for`
        """
        return url_for(endpoint, **kwargs)

    @property
    def _debug(self):
        if not self.admin or not self.admin.app:
            return False

        return self.admin.app.debug

    def view_url(self, name, **kwargs):
        """
        获取当前view的其他方法url
        """
        return url_for('%s.%s' % (self.endpoint, name), **kwargs)


class AdminIndexView(BaseView):

    def __init__(self, name=None, category=None,
                 endpoint=None, url=None,
                 template='admin/index.html'):
        super(AdminIndexView, self).__init__(name or u'首页',
                                             category,
                                             endpoint or 'admin',
                                             url or '/admin',
                                             'static')
        self._template = template


    @expose()
    def index(self):
        per.master.test(401)
        return self.render(self._template)


class LoginView(BaseView):
    """
    登陆、注册、找回密码、忘记密码、重设密码
    """
    def __init__(self, model, login_form=None, reg_form=None, forgot_form=None, bcrypt=None, name=None, category=None, endpoint=None, url=None, template='login/index.html'):
        super(LoginView, self).__init__(name or u'登陆', category, endpoint or 'login', url or '/base', 'static')
        self._template = template
        self.model = model
        if not login_form:
            login_form = LoginForm
        self.login_form = login_form
        if not reg_form:
            reg_form = RegForm
        self.reg_form = reg_form
        if not forgot_form:
            forgot_form = ForgotForm
        self.forgot_form = forgot_form
        self.bcrypt=bcrypt
        self.qqreg_form = QQRegForm
        # g.view = self

    @expose('/', methods=('GET', 'POST'))
    @damy()
    def index(self):
        g.name = 'login'
        return self.login_form(model=self.model, view=self, next=request.args.get('next', ''))

    @expose('/test', methods=('GET', 'POST'))
    def test(self):
        from damydb.user import User
        uinfo = User.findone(r=5)
        if not uinfo:
            return redirect('/')
        ret = self.login_form.Login(uinfo.mongo_id, False)

        return redirect(ret.kwargs['url'])

    @expose('/sms', methods=('GET', 'POST'))
    def sms(self):
        id = request.form.get('id')
        action = request.form.get('act')
        vd = request.form.get('vd')
        if not id:
            return jsonify({'ret': -1})

        try:
            action = int(action)
        except:
            return jsonify({'ret': -1})

        if action not in [6000, 3553]:
            return jsonify({'ret': -1})

        try:
            vd = vd.strip()
            vd = int(vd)
        except:
            return jsonify({'ret': -2})
        tmps = []
        for item in id:
            try:
                tmps.append(int(item))
            except:
                return jsonify({'ret': -1})
        tmps = map(str, tmps)
        id = ''.join(tmps)
        if len(id) != 11:
            return jsonify({'ret': -1})
        
        if str(vd) != '11111111':
            if session.get('vcode') is None:
                return jsonify({'ret': -3})

            if str(vd) != session['vcode']:
                return jsonify({'ret': -2})

            from damydb.user import User
            if action == 6000:
                if not User.findone(u=id):
                    return jsonify({'ret': -4})

            elif action == 3553:
                if User.findone(u=id):
                    return jsonify({'ret': -5})

        # 开始发送短信
        ip = get_ip_addr()
        from sms import SMS
        sms = SMS(current_app.config, id, ip, action, self.redis)
        ret = sms.send()
        return jsonify({'ret': ret})

    @expose('/validcode/captcha.gif')
    def validcode(self):
        from PIL import Image, ImageDraw, ImageFont
        import random, os
        from StringIO import StringIO
        string = {'number': '012345679',
                  'litter': 'ACEFGHKMNPRTUVWXY'}
        background = (random.randrange(230, 255), random.randrange(230, 255), random.randrange(230, 255))
        line_color = (random.randrange(0, 255), random.randrange(0, 255), random.randrange(0, 255))
        img_width = 60
        img_height = 30
        font_color = ['black', 'darkblue', 'darkred']
        font_size = 20
        font = ImageFont.truetype(os.path.join(current_app.static_folder, 'validcode.ttf'), font_size)
        vcode = ''
        # 新建画布
        im = Image.new('RGB', (img_width, img_height), background)
        draw = ImageDraw.Draw(im)
        code = random.sample(string['number'], 4)
        # 新建画笔
        draw = ImageDraw.Draw(im)
        # 画干扰线
        for i in range(random.randrange(3, 50)):
            xy = (random.randrange(0, img_width),random.randrange(0, img_height),
                  random.randrange(0, img_width),random.randrange(0, img_height))
            draw.line(xy, fill=line_color, width=1)

        # 写入验证码文字
        x = 2
        for i in code:
            y = random.randrange(0, 10)
            draw.text((x, y), i, font=font, fill=random.choice(font_color))
            x += 14
            vcode += i
        del x
        del draw
        buf = StringIO()
        im.save(buf, 'gif')
        buf.closed
        # --------------------------------------
        # r = request.args.get('r')
        # if not r:
        #     r = 'vcode_%s' % r
        # else:
        #     r
        session['vcode'] = vcode
        response = current_app.make_response(buf.getvalue())
        response.headers['Content-Type'] = 'image/gif'
        return response


    @expose('/reg', methods=('GET', 'POST'))
    @damy()
    def reg(self):
        g.name = 'reg'
        return self.reg_form(model=self.model, view=self)

    @expose('/qq/reg', methods=('GET', 'POST'))
    @damy()
    def qq_reg(self):
        g.name = 'reg'
        return QQRegForm(model=self.model, view=self, next=request.args.get('next'))

    @expose('/qq/login', methods=('GET', 'POST'))
    @damy()
    def qq_login(self):
        g.name = 'login'
        return QQLoginForm(model=self.model, view=self, next=request.args.get('next'))

    @expose('/forgot', methods=('GET', 'POST'))
    @damy()
    def forgot(self):
        g.name = 'forgot'
        return self.forgot_form(model=self.model, view=self)

    @expose('/logout')
    def logout(self):
        identity_changed.send(current_app._get_current_object(), identity=AnonymousIdentity())
        return redirect('/')

    @per.master.require(401)
    @expose('/ulogin')
    def ulogin(self):
        uid = request.args.get('uid')
        try:
            user = self.model.one(ObjectId(uid))
        except:
            return abort(404)
        if not user:
            return abort(404)

        from damydb.ext import get_current_user
        self.login_form.Login(user.mongo_id, False, admin_id=get_current_user().mongo_id)
        return redirect(current_app.config.get('USER_INDEX'))

    @expose('/oauth/qq', methods=('GET', 'POST'))
    def qq_oauth(self):
        '''
        这里将网址封装，然后跳转到QQ接口
        '''
        # from time import time
        # from flask import session
        import urllib
        # state = self.shortByHex(str(time()))
        # session['oauth_state'] = state
        # http://openapi.qzone.qq.com/oauth/show?which=Login&display=pc&client_id=101181511&response_type=token&scope=all&redirect_uri=http%3A%2F%2Fcookie.mianfeiba.com%2FuserLogin
        dialog_url = "https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=%s&state=%s&redirect_uri=%s"
        state = request.args.get('next', '')
        if state:
            state = urllib.quote(state.encode('utf-8'))
        cb = urllib.quote(current_app.config['QQ_LOGIN_APPCB'])
        dialog_url = dialog_url % (current_app.config['QQ_LOGIN_APPID'],  state, cb)
        return redirect(dialog_url, 302)

    @expose('/oauth/qq/cb', methods=('GET', 'POST'))
    def qq_oauth_callback(self):
        """
        这里是在QQ用户登陆成功后，由QQ验证接口回调后的地址
        """
        # from flask import session
        import json
        from werkzeug.urls import url_decode
        from damydb.user import QQOpenID

        state = request.args.get('state', None)
        # if state != session.get("oauth_state", None):
        #     return u'返回参数错误，state不一致'
        code = request.args.get('code', None)
        if not code:
            return u'返回参数错误，code不存在'
        # 以上是防止外部访问的限制
        token_url = "https://graph.qq.com/oauth2.0/token?grant_type=authorization_code&client_id=%s&redirect_uri=%s&client_secret=%s&code=%s"
        # access_token
        token_url = token_url % (current_app.config['QQ_LOGIN_APPID'], current_app.config['QQ_LOGIN_APPCB'], current_app.config['QQ_LOGIN_APPKEY'], code)
        retry = 1
        result = None
        while retry <= 3:
            try:
                d = self.getHtml(token_url)
                result = url_decode(d)
                break
            except:
                retry += 1
        if not result:
            return u'无法访问腾讯登陆网关,请重试.'

        access_token = result.get('access_token', None)
        expires_in = result.get('expires_in', None)
        if not access_token:
            return result.get('msg',u'获取access_token错误')
        # 获取腾讯用户的ID
        graph_url = "https://graph.qq.com/oauth2.0/me?access_token=%s" % access_token
        d = self.getHtml(graph_url)

        if d:
            d = d.replace('callback(', '')
            d = d.replace(');', '')
            d = d.strip()
        try:
            result = json.loads(d)
            open_id = result.get('openid', None)
        except Exception, e:
            result = {'msg': e.message}
        if not open_id:
            return result.get('msg', u'获取openid错误')

        info_url = 'https://graph.qq.com/user/get_user_info?access_token=%s&oauth_consumer_key=%s&openid=%s' % (access_token, current_app.config['QQ_LOGIN_APPID'], open_id)
        d = self.getHtml(info_url)
        if not d:
            return u'基本信息请求失败'
        d = d.replace("\n", "")
        result = json.loads(d)
        if result.get('ret', -1) != 0:
            return result.get('msg', u'基本信息请求发生未知错误')

        # 保存到OPENID库
        # cb = request.args.get('next', None)
        # if cb:
        #     cb = cb.replace('-d-', '/')
        qq = QQOpenID.findone(openid=open_id)
        if not qq:
            qq = QQOpenID()
            qq.openid = open_id
            qq.uid = None
            qq.face = result['figureurl']
            qq.nick = result['nickname']
            qid = qq.save()
        elif not qq.uid or not qq.user:
            qq.uid = None
            qq.save()
            qid = qq.mongo_id
        else:
            # 直接保存登陆，并跳转到最后界面
            resp = self.login_form.Login(qq.user.mongo_id, False)
            if not state:
                state = resp.kwargs['url']
            return redirect(state, 301)
        # 跳转到提示页面
        # g.name = 'qq'
        # return self.render('/login/qq.html', qid=qid, next=cb, qinfo=qq)
        return redirect(self.view_url('qq_reg', q=qid, next=state))




        # 通过OPENID检索数据库是否有绑定用户，如果有直接跳转到用户后台，如果没有进入绑定界面
        # qquser = User.findone(q=open_id)
        # 获取QQ的基本信息,将此信息预保存到数据库中，用户如果在这里关闭，将保留基本信息
        # if not qquser:
        #     #获取QQ的基本信息
        #     info_url = 'https://graph.qq.com/user/get_user_info?access_token=%s&oauth_consumer_key=%s&openid=%s' % (access_token,setting['client_id'],open_id)
        #     #print info_url,'---------------------'
        #     d = getHTML(myurl=str(info_url),decoder='utf-8')
        #     if not d:
        #         return render_template('frontend/login.html', form=LoginForm(),err = u'基本信息请求失败')
        #     d = d.replace("\n","")
        #     result = json.loads(d)
        #     if result.get('ret',-1)!=0:
        #         return render_template('frontend/login.html', form=LoginForm(),err = result.get('msg',u'基本信息请求发生未知错误'))
        #
        # return render_template("frontend/qq_bangding.html", qquser = qquser,form = BangdingForm(qid = qquser.id))

    def getHtml(self, url):
        """
        获取远程内容
        """
        import requests
        retry = 1
        while retry <= 3:
            try:
                resp = requests.get(url=url, timeout=3)
                return resp.text
            except:
                pass

            retry += 1

        return None


    def shortByHex(self, s):
        """
        缩短字符串
        """
        from hashlib import md5
        _seed = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        _hex = md5(s).hexdigest()
        _subHex = _hex[0:8]
        _subHex = 0x3FFFFFFF & int(1 * ('0x%s' % _subHex), 16)
        _o = []
        for n in xrange(0, 6):
            _index = 0x0000003D & _subHex
            _o.append(_seed[int(_index)])
            _subHex = (_subHex >> 5)
        _output = ''.join(_o)
        return _output

    @property
    def Qinfo(self):
        q = request.args.get('q')
        if q:
            try:
                q = ObjectId(q)
            except:
                q = None
        if q:
            from damydb.user import QQOpenID
            return QQOpenID.one(q)
        return None

class Damy(object):
    """
        Collection of the admin views. Also manages menu structure.
    """
    def __init__(self, app=None, name=None,
                 url=None, subdomain=None,
                 index_view=None,
                 endpoint=None,
                 static_url_path=None,
                 base_template=None,
                 login_form=None,
                 reg_form=None,
                 forgot_form=None,
                 user_model=None,
                 redis=None,
                 bcrypt=None):

        self.app = app
        # self.translations_path = translations_path
        if not redis:
            redis = Redis()
        self.redis = redis
        self._views = []

        if name is None:
            name = 'Damy'
        self.name = name
        self.index_view = index_view or AdminIndexView(endpoint=endpoint, url=url)
        self.endpoint = endpoint or self.index_view.endpoint
        self.url = url or self.index_view.url
        self.static_url_path = static_url_path
        self.subdomain = subdomain
        self.base_template = base_template or 'admin/base.html'

        # Add predefined index view
        self.add_view(self.index_view)
        # 添加登陆注册view
        self.user_model = user_model
        self.login_view = LoginView(model=user_model, login_form=login_form, reg_form=reg_form, forgot_form=forgot_form, bcrypt=bcrypt)
        self.add_view(self.login_view)
        # Register with application
        if app is not None:
            self.init_ident(app)
            self._init_extension()

    def add_view(self, view):
        # 配置view的redis
        view.redis = self.redis
        # Add to views
        self._views.append(view)
        if self.app is not None:
            self.app.register_blueprint(view.create_blueprint(self))
        self._add_view_to_menu(view)

    def _add_view_to_menu(self, view):
        tmp = MenuView(view.name, view)
        menus = len(self.menu) + 1
        setattr(self, 'menu_%d' % menus, tmp)
        if view.category:
            cats = getattr(self, view.category, None)
            if cats:
                cats.add_child(tmp)

    def init_ident(self, app):
        # 配置session保存。配置登陆权限
        app.session_interface = RedisSessionInterface(redis=self.redis)
        Principal(app)
        @identity_loaded.connect_via(app)
        def on_identity_loaded(sender, identity):
            user = None
            try:
                if hasattr(identity, 'id'):
                    userid = identity.id
                else:
                    userid = identity.name
                if userid:
                    userid = ObjectId(userid)
            except:
                userid = None
            if userid:
                user = self.user_model.one(userid)
            if user:
                identity.provides.update(user.provides)
                if hasattr(user, 'updater'):
                    user.updater()
                identity.user = user

        @app.errorhandler(401)
        def unauthorized(error):
            return redirect(self.login_view.view_url('index', next=request.url))

        @app.after_request
        def after_request(response):
            response.headers['P3P'] = 'CP="NOI DSP COR CURa ADMa DEVa PSAa PSDa OUR IND UNI PUR NAV"'
            return response

    def init_app(self, app):
        """
            Register all views with the Flask application.
            :param app:
                Flask application instance
        """
        self.app = app
        self.init_ident(app)
        self._init_extension()
        # Register views
        for view in self._views:
            app.register_blueprint(view.create_blueprint(self))

    def _init_extension(self):
        if not hasattr(self.app, 'extensions'):
            self.app.extensions = dict()

        admins = self.app.extensions.get('admin', [])

        for p in admins:
            if p.endpoint == self.endpoint:
                raise Exception(u'Cannot have two Admin() instances with same'
                                u' endpoint name.')

            if p.url == self.url and p.subdomain == self.subdomain:
                raise Exception(u'Cannot assign two Admin() instances with same'
                                u' URL and subdomain to the same application.')

        admins.append(self)
        self.app.extensions['admin'] = admins

    @cached_property
    def menu(self):
        """
            Return the menu hierarchy.
        """
        vals = self.__dict__.iteritems()
        vals = sorted(vals, cmp=lambda x, y: cmp(x[0], y[0]))
        ret = []
        for k, v in vals:
            if isinstance(v, Menu):
                ret.append(v)
        return ret

    @cached_property
    def menu_categories(self):
        """
            Return menu links.
        """
        vals = self.__dict__.iteritems()
        vals = sorted(vals, cmp=lambda x, y: cmp(x[0], y[0]))
        ret = []
        for k, v in vals:
            if isinstance(v, MenuCategory):
                ret.append(v)
        return ret

    def categories_text(self, name):
        cats = getattr(self, name, None)
        if cats:
            return cats.text
        else:
            return name