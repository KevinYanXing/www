# coding=utf-8
from werkzeug import cached_property


class MenuCategory:
    """
        Menu category item.
    """
    def __init__(self, name, text, homepage=None):
        self.name = name
        self.text = text
        self.homepage = homepage
        self.childs = []

    def add_child(self, item):
        self.childs.append(item)


class Menu(object):
    def __init__(self, name, view=None):
        self._view = view
        self.name = name

        view.menu = self

    @cached_property
    def url(self):
        raise NotImplementedError("请重载此属性")

class MenuView(Menu):
    """
        Admin view menu item
    """
    def __init__(self, name, view=None):
        super(MenuView, self).__init__(name, view)

    @cached_property
    def url(self):
        if self._view is None:
            return None
        return self._view.get_url('%s.%s' % (self._view.endpoint, self._view._default_view))


class MenuLink(Menu):
    """
        Admin link menu item
    """
    def __init__(self, name, link, view=None):
        super(MenuView, self).__init__(name, view)
        self.link = link

    @cached_property
    def url(self):
        return self.link