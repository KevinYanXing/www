# coding=utf-8
import json


class Charts(object):
    cfg = {}

    def __init__(self, id, **kwargs):
        self.id = id
        kwargs['id'] = id
        self.kwargs = kwargs

    def render(self):
        """
        声称页面上的配置文件
        :return:
        """
        tmp = self.cfg.copy()
        tmp.update(**self.kwargs)
        return json.dumps(tmp)


class LineCharts(Charts):
    cfg = {
        'theme': '',
        'id': '',
        'width': 1000,
        'height': 500,
        'plotCfg': {
            'margin': [50, 50, 80]  # 画板的边距
        },
        'xAxis': {
            'categories': []
        },
        'seriesOptions': {  # 设置多个序列共同的属性
                            'lineCfg': {  # 不同类型的图对应不同的共用属性，lineCfg,areaCfg,columnCfg等，type + Cfg 标示
                                          'smooth': True,
                                          'labels': {  # 标示显示文本
                                                       'label': {  # 文本样式
                                                                   'y': -15
                                                       },
                                          }
                            }
        },
        'tooltip': {
            'valueSuffix': ''
        },
        'series': []
    }


class BarCharts(Charts):
    cfg = {
        'theme': '',
        'id': 'canvas',
        'width': 1000,
        'height': 500,
        'invert': True,
        'xAxis': {
            'categories': [],
            'position': 'left',  # x轴居左
            'labels': {
                'label': {
                    'text-anchor': 'end',
                    'x': -12,
                    'y': 0
                }
            }
        },
        'yAxis': {
            'position': 'bottom',
            'min': 0
        },
        'tooltip': {
            'shared': True
        },
        'seriesOptions': {
            'columnCfg': {
                'stackType': 'normal'  # 层叠
            }
        },
        'series': []
    }
