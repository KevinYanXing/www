'''
Created on 2011-3-25

@author: damy
'''
# from flask.ext.principal import RoleNeed, Permission
from damyweb.pricipal import RoleNeed, Permission

administrator = Permission(RoleNeed('admin'))
manager = Permission(RoleNeed('manager'))
moderator = Permission(RoleNeed('moderator'))
master = Permission(RoleNeed('master'))
auth = Permission(RoleNeed('authenticated'))
member = Permission(RoleNeed('member'))
null = Permission(RoleNeed('null'))