# coding=utf-8
import hashlib, urllib


class Alipay():
    """
    out_trade_no 商户网站唯一订单号
    partner 合作身份者id，以2088开头的16位纯数字
    payment_type 支付类型
    return_url 页面跳转同步通知页面路径
    notify_url  服务器异步通知页面路径
    seller_email 卖家支付帐号
    subject 商品名称
    total_fee 付款金额
    show_url 商品展示地址
    key 安全检验码，以数字和字母组成的32位字符
    sign_type 签名方式 不需修改
    input_charset 字符编码格式 目前支持 gbk 或 utf-8
    defaultbank 银行代码
    paymethod　网银支付
    """
    out_trade_no = None
    subject = None
    total_fee = None
    defaultbank = None
    paymethod = None
    gateway = 'https://mapi.alipay.com/gateway.do?'


    def __init__(self, config):
        self.partner = config['ALIPAY_PARTNER']
        self.key = config['ALIPAY_KEY']
        self.return_url = config['ALIPAY_RETURN_URL']
        self.notify_url = config['ALIPAY_NOTIFY_URL']
        self.seller_email = config['ALIPAY_SELLER_EMAIL']
        self.sign_type = 'MD5'
        self.input_charset = 'utf-8'
        self.payment_type = '1'
        self.service = 'create_direct_pay_by_user'


    def createSign(self, parameters):
        """
        md5加密
        :param parameters:
        """
        parameters.sort()
        s = '&'.join(parameters) + self.key
        return hashlib.md5(s.encode("utf8")).hexdigest()


    def getSign(self):
        """
        生成请求签名
        """
        parameters = ['out_trade_no=' + str(self.out_trade_no),
                      'partner=' + self.partner,
                      'payment_type=' + self.payment_type,
                      'return_url=' + self.return_url,
                      'seller_email=' + self.seller_email,
                      'service=' + self.service,
                      'subject=' + self.subject,
                      'notify_url=' + self.notify_url,
                      'total_fee=' + str(self.total_fee),
                      '_input_charset=' + self.input_charset,

        ]
        #网银付款需要添加网银代码
        if self.defaultbank:
            parameters.append('defaultbank=' + self.defaultbank)
        if self.paymethod:
            parameters.append('paymethod=' + self.paymethod)
        return self.createSign(parameters)

    def getUrl(self):
        """
        请求url
        """
        parameters = ['out_trade_no=' + str(self.out_trade_no),
                      'partner=' + self.partner,
                      'payment_type=' + self.payment_type,
                      'return_url=' + self.return_url,
                      'seller_email=' + self.seller_email,
                      'service=' + self.service,
                      'subject=' + self.subject,
                      'notify_url=' + self.notify_url,
                      'total_fee=' + str(self.total_fee),
                      '_input_charset=' + self.input_charset,
                      'sign_type=' + self.sign_type,
                      'sign=' + self.getSign(),

        ]
        #网银付款需要添加网银代码
        if self.defaultbank:
            parameters.append('defaultbank=' + self.defaultbank)
        if self.paymethod:
            parameters.append('paymethod=' + self.paymethod)
        parameters.sort()
        s = '&'.join(parameters)
        url = self.gateway + s
        return url


    ###下面是支付返回后的操作###
    def verifyReturn(self,args):
        """
        验证是签名、较验ＩＤ是否正确
        """
        if self.notify_sign(args) and self.getResponse(args['notify_id']) == 'true':
            return True
        else:
            return False

    def notify_sign(self, args):
        """
        要据支付宝返回的请求参数生成返回签名,签名是否正确
        """
        parameters = []
        for k in args:
            if k == 'sign' or k == 'sign_type' or k == '': continue
            parameters.append(k + '=' + args[k])
        if self.createSign(parameters) == args['sign']:
            return True
        else:
            return False

    def veryfy_url(self,notify_id):
        """
        获取支付宝远程服务器ATN地址
        """
        parameters = ['service=notify_verify',
                      'partner=' + self.partner,
                      'notify_id='+notify_id

        ]
        s = '&'.join(parameters)
        return self.gateway + s

    def getResponse(self,notify_id):
        """
        获取远程服务器ATN结果
        """
        url = self.veryfy_url(notify_id)
        text = urllib.urlopen(url).read()
        return text