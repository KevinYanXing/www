# coding=utf-8
from base import BaseView, expose
from flask import request, redirect, abort, Response, json, flash
from helpers import get_mdict_item_or_list
from bson import ObjectId
from time import mktime
from datetime import datetime
import permissions as per
from .form_action import FormAction

class ModelView(BaseView):
    # Permissions
    can_create = True
    """Is model creation allowed"""

    can_edit = True
    """Is model editing allowed"""

    # Templates
    list_template = 'admin/model/list.html'
    """Default list view template"""

    edit_template = 'admin/model/edit.html'
    """Default edit template"""

    create_template = 'admin/model/create.html'

    form = None

    searchform = None


    modelper = per.administrator

    def __init__(self, model,
                 name=None, category=None, endpoint=None, url=None, static_folder=None,
                 menu_class_name=None, menu_icon_type=None, menu_icon_value=None):
        """
            Constructor.

            :param model:
                Model class
            :param name:
                View name. If not provided, will use the model class name
            :param category:
                View category
            :param endpoint:
                Base endpoint. If not provided, will use the model name + 'view'.
                For example if model name was 'User', endpoint will be
                'userview'
            :param url:
                Base URL. If not provided, will use endpoint as a URL.
            :param menu_class_name:
                Optional class name for the menu item.
            :param menu_icon_type:
                Optional icon. Possible icon types:

                 - `flask.ext.admin.consts.ICON_TYPE_GLYPH` - Bootstrap glyph icon
                 - `flask.ext.admin.consts.ICON_TYPE_IMAGE` - Image relative to Flask static directory
                 - `flask.ext.admin.consts.ICON_TYPE_IMAGE_URL` - Image with full URL
            :param menu_icon_value:
                Icon glyph name or URL, depending on `menu_icon_type` setting
        """

        # If name not provided, it is model name
        if name is None:
            name = '%s' % self._prettify_class_name(model.__name__)

        # If endpoint not provided, it is model name
        if endpoint is None:
            endpoint = model.__name__.lower()

        self.action = []
        self.charts = []
        self.model = model()
        super(ModelView, self).__init__(name, category, endpoint, url, static_folder,
                                            menu_class_name=menu_class_name,
                                            menu_icon_type=menu_icon_type,
                                            menu_icon_value=menu_icon_value)

        if self.can_edit:
            self.action.append(FormAction(text=u'删除', opr='del'))

        self.after_init()

    def after_init(self):
        pass

    def get_one(self, id):
        """
        获取一条数据
        :param id:
        :return:
        """
        id = ObjectId(id)
        return self.model.one(id)

    def list_where(self, req):
        """
        获取列表在这里可以根据请求的数据进行绑定条件筛选数据
        :param req:
        :return:
        """
        return {}


    def list_sort(self):
        """
        排序，可以重载
        :return:
        """
        return [('d', -1)]

    def list_item(self, item):
        """
        获取列表后的单条数据处理，返回dict数据
        :param item:
        :return:
        """
        ret = {}
        f = self.searchform()
        ''' 取消对全部属性的覆盖
        for c in item.data.keys():
            if type(item.data[c]) == ObjectId:
                ret[c] = str(item.data[c])
            else:
                ret[c] = item.data[c]
        '''
        # 再真正处理需要的数据
        for c in f.column:
            if not c.attrs.get('dataIndex'): continue
            val = getattr(item, c.attrs['dataIndex'])
            if type(c.fun) == bool and c.fun and val:
                if val:
                    val = val()
            elif c.fun:
                try:
                    val = c.fun(val, item)
                except TypeError:
                    val = c.fun(val)

            if type(val) == ObjectId:
                val = str(val)
            ret[c.attrs['dataIndex']] = val
        return ret

    def ajax_del(self, req):
        """
        删除指定数据
        :param req:
        :return:
        """
        if not self.can_edit:
            return {'success': False}

        ids = req.form.getlist('ids[]')
        for id in ids:
            item = self.get_one(id)
            if not item:
                continue
            item.remove()
        return {'success': True}

    def opr_del(self, req):
        return self.ajax_del(req)

    def ajax_opr(self, req):
        """
        操作
        :param req:
        :return:
        """
        saveType = req.form.get('saveType')
        fun = getattr(self, 'opr_%s' % saveType)
        if fun:
            return fun(req)
        return {'success': False}

    def ajax_list(self, req):
        limit = int(request.form.get('limit', 100))
        pageIndex = int(request.form.get('pageIndex', 0))
        startDate = request.form.get('startDate', '').strip()
        endDate = request.form.get('endDate', '').strip()
        where = self.list_where(request)
        if startDate and endDate:
            try:
                startDate = mktime(datetime.strptime(startDate, "%Y-%m-%d").timetuple())
                endDate = mktime(datetime.strptime(endDate, "%Y-%m-%d").timetuple())
                if endDate == startDate: endDate += 86400
            except:
                startDate = 0
                endDate = 0
            if endDate >= startDate:
                where['d'] = {'$lte': endDate, '$gte': startDate}
        pageIndex += 1

        ds = self.model.search(sort=self.list_sort(), nums=limit, page=pageIndex, **where)
        ret = []
        pos = 1
        for item in ds.items:
            tmp = self.list_item(item)
            tmp['z_index'] = pos
            tmp['_id'] = str(item.mongo_id)
            pos += 1
            ret.append(tmp)

        return {"rows": ret, "results": ds.total, "hasError": False}

    # @modelper.require(401)
    @expose('/')
    def index_view(self):
        self.modelper.test(401)
        form = None
        if self.searchform:
            form = self.searchform(self)
        return self.render(self.list_template, form=form)

    @expose('/new/', methods=('GET', 'POST'))
    def create_view(self):
        """
            Create model view
        """
        self.modelper.test(401)


        return_url = self.get_url('.index_view')

        if not self.can_create:
            return redirect(return_url)

        form = self.form(view=self)

        if form.result == form.SUCCESS:
            obj = type(self.model)()
            if not form.load_objval(obj):
                obj.save()
            flash(u'创建成功', 'success')
            if '_add_another' in request.form:
                return redirect(request.url)
            else:
                return redirect(return_url)
        elif form.result == form.FAILD:
            msg = u'<h2>创建失败</h2>' + form.errors_text(u'<p>%s ：%s</p>')
            flash(msg, 'error')

        return self.render(self.create_template, form=form)

    def after_edit(self, edit):
        pass

    @expose('/edit/', methods=('GET', 'POST'))
    def edit_view(self):
        """
            Edit model view
        """
        self.modelper.test(401)


        return_url = self.get_url('.index_view')

        if not self.can_edit:
            return redirect(return_url)


        id = get_mdict_item_or_list(request.args, 'id')
        if id is None:
            return redirect(return_url)

        model = self.get_one(id)

        if model is None:
            return redirect(return_url)
        form = self.form(view=self, obj=model)
        if form.result == form.SUCCESS:
            form.load_objval(model)
            model.save()
            self.after_edit(model)
            flash(u'编辑成功', 'success')
            return redirect(return_url)
        elif form.result == form.FAILD:
            msg = u'<h2>编辑失败</h2>' + form.errors_text(u'<p>%s ：%s</p>')
            flash(msg, 'error')
        return self.render(self.edit_template, model=model, form=form)

    @expose('/ajax/', methods=('GET', 'POST'))
    def ajax(self):
        self.modelper.test(401)


        name = request.args.get('name')
        name = 'ajax_' + name
        try:
            method = getattr(self, name)
        except:
            return abort(404)
        data = method(request)
        if type(data) == str:
            return redirect(data)
        if type(data) == Response:
            return data

        return Response(json.dumps(data), mimetype='application/json')

