# coding=utf-8
import random, json
from damyunit.sms import SmsSender
from datetime import date
from time import mktime, time
from damyunit.log import Log
class SMS:
    key = "POMELO_SMS_%s_%s"
    def __init__(self, config, to, ip, act, redis, log=None):
        """
        config 配置信息
        to 要发送到的手机号码
        ip 发送端IP
        act 短信内容模板ID
        """
        self.sender = SmsSender(config)
        self.config = config
        self.to = to
        self.ip = ip
        self.templateId = act
        self.redis = redis
        # if log:
        #     self.log = log
        # else:
        self.log = Log(log_name='dtask.web.sms')

    def send(self):
        # 生成验证码　
        mkey = random.randint(10000, 99999)
        # 1分钟内同一个号码只能发送一次
        if self.redis.get(self.key % ('SEND', self.to)):
            return 0
        # 每天号码发送限制
        tmp = self.redis.get(self.key % ('_TODAY_SEND', self.to))
        if not tmp:
            tmp = 0
        else:
            tmp = int(tmp)
        if tmp >= self.config.get('SMS_MAX_TODAY_NUM', 10):
            return 0

        # 2分钟内同一个IP只能发送一次
        if self.ip:
            if self.redis.get(self.key % ('SEND', self.ip)):
                return 0
            # 每天IP发送限制
            tmp = self.redis.get(self.key % ('_TODAY_SEND', self.ip))
            if not tmp:
                tmp = 0
            else:
                tmp = int(tmp)
            if tmp >= self.config.get('SMS_MAX_TODAY_IP', 10):
                return 0

        ret = self._action(mkey)
        if self.sender.is_ok(ret):
            # 发送次数限制
            if self.ip:
                self.redis.set(self.key % ('SEND', self.ip), 1)
                self.redis.expire(self.key % ('SEND', self.ip), 60)

            self.redis.set(self.key % ('SEND', self.to), 1)
            self.redis.expire(self.key % ('SEND', self.to), 60)
            # 结果存入redis
            self.redis.set(self.key % ('CODE', self.to), mkey)
            self.redis.expire(self.key % ('CODE', self.to), 300)
            # 每天号码次数限制
            time_left = mktime(date.today().timetuple()) + 86400 - time()
            time_left = int(time_left)
            self.redis.incr(self.key % ('_TODAY_SEND', self.to), 1)
            self.redis.expire(self.key % ('_TODAY_SEND', self.to), time_left)
            # 每天IP次数限制
            self.redis.incr(self.key % ('_TODAY_SEND', self.ip), 1)
            self.redis.expire(self.key % ('_TODAY_SEND', self.ip), time_left)
            self.log.info(m='send msg ok : {0}'.format(self.to))
            return 1
        else:
            self.log.warning(t=self.to, m=self.templateId, c='send msg faild', s=ret, b=self.sender.resp)
            return ret

    @staticmethod
    def getVal(to, redis):
        """
        获取短信发送结果
        """
        return redis.get(SMS.key % ('CODE', to))

    def _action(self, mkey):
        """
        #短信验证码（模板短信）
        #accountSid 主账号ID
        #accountToken 主账号Token
        #appId 应用ID
        #toNumber 被叫的号码
        #templateId 模板Id
        #param <可选> 内容数据，用于替换模板中{数字},用，号分隔
        """
        # ret = None
        try:
            return self.sender.send(self.templateId, self.to, str(mkey))
        except:
            self.log.err(t=self.to, m=self.templateId)
            return -6
        # if not ret or ret == '0':
        #     return -7
        # return ret