# coding=utf-8
'''
Created on 2011-4-23

@author: damy

'''
from functools import wraps
from flask import request, render_template, current_app
import werkzeug.datastructures
from wtforms.fields import HiddenField
from wtforms.widgets import HiddenInput
from wtforms.form import Form
from wtforms.compat import string_types, text_type
import json
from jinja2 import Markup

def _is_hidden(field):
    """Detect if the field is hidden."""
    if isinstance(field, HiddenField):
        return True
    if isinstance(field.widget, HiddenInput):
        return True
    return False


class Resp(Exception):
    def __init__(self,**kwargs):
        self.kwargs = kwargs

class SuccessResp(Resp):
    def __init__(self,message,url = None,**kwargs):
        super(SuccessResp,self).__init__(message = message,url = url,**kwargs)

class ErrorResp(Resp):
    def __init__(self,message,**kwargs):
        super(ErrorResp,self).__init__(message = message,**kwargs)

def damy(template = None):
    '''
    基本的返回
    '''
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            ctx = f(*args, **kwargs)
            return ctx.run(template)
        return decorated_function
    return decorator

class BaseForm(Form):
    def __init__(self,prefix='', **kwargs):
        #这里的数据不需要前面带过来
        formdata=None
        obj=None
        if self.is_submitted():
            #提交后对formdata进行绑定
            formdata = request.form
            if request.files:
                formdata = formdata.copy()
                formdata.update(request.files)
            elif request.json:
                formdata = werkzeug.datastructures.MultiDict(request.json)
        else:
            #不是提交的话就从重载的方法里面加载obj
            obj = self.load_data()

        super(BaseForm, self).__init__(formdata, obj, prefix, **kwargs)

    def load_data(self):
        """
        这里对数据进行初始化
        也可以对form进行另外的数据
        """
        return None

    def submit(self):
        """
        数据提交后的操作，在这里绑定数据，并进行保存或者相关处理，请重载此功能
        """
        raise Exception,u'请对此类进行submit的方法实现'

    def run(self,template):
        if self.is_submitted():
            if not self.validate_on_submit():
                return self._validate()

            try:
                self.submit()
            except SuccessResp,su:
                #成功了
                return self._success(su)
            except ErrorResp,ex:
                #验证出错了
                return self._error(ex)
        else:
            if not template: template = request.endpoint.replace('.', '/') + '.html'
            return self.render(template)

    def render(self, template, **kwargs):
        """
        返回响应内容
        """
        # Expose config info
        kwargs['config'] = current_app.config
        kwargs['form'] = self
        return render_template(template, **kwargs)

    def _validate(self):
        """
        显示表单验证的错误
        """
        err = dict()
        for field in self:
            if field.errors:
                for error in field.errors:
                    err[field.name] = unicode(error)
        #将这个err通过调用指定的JS方法实现
        return self._show_submit_finish(err,'validate')


    def _success(self,su):
        """
        显示操作成功的信息，su带有message,和，url，以及其他数据
        """
        return self._show_submit_finish(su.kwargs,'success')

    def _error(self,err):
        """
        显示操作错误信息
        """
        return self._show_submit_finish(err.kwargs,'error')


    def _show_submit_finish(self,val,method):
        val = json.dumps(val)
        val = 'parent.DAMY.loader.%s(%s);' %(method,val)
        val = '<html><head><script type="text/javascript">%s</script></head></html>' %val
        return Markup(val)

    def form(self,id = None,action = '',target = '__hidden_call',**kwargs):
        '''
        在HTML页面中调用此方法来实现form标签的render
        '''

        form_name = type(self).__name__
        if not id: id = form_name
        result = []
        result.append(u'<form action="')
        result.append(action)
        result.append(u'" method="post" class="ajax_form" onsubmit="DAMY.loader.submit(this);" target="'+ target +'" data-bind="ajax_form" id="')
        result.append(id)
        result.append(u'_form" name="')
        result.append(form_name)
        result.append(u'_form"')
        for k,v in kwargs.items():
            result.append(' '+ k + '="' + v + '"')
        result.append(u'>')
        result.append(self.hidden_tag())

        return Markup(u"".join(result))

    def is_submitted(self):
        """
        Checks if form has been submitted. The default case is if the HTTP
        method is **PUT** or **POST**.
        """

        return request and request.method in ("PUT", "POST")

    def hidden_tag(self, *fields):
        """
        Wraps hidden fields in a hidden DIV tag, in order to keep XHTML
        compliance.

        .. versionadded:: 0.3

        :param fields: list of hidden field names. If not provided will render
                       all hidden fields, including the CSRF field.
        """

        if not fields:
            fields = [f for f in self if _is_hidden(f)]

        rv = [u'<div style="display:none;">']
        for field in fields:
            if isinstance(field, string_types):
                field = getattr(self, field)
            rv.append(text_type(field))
        rv.append(u"</div>")

        return Markup(u"".join(rv))

    def validate_on_submit(self):
        """
        Checks if form has been submitted and if so runs validate. This is
        a shortcut, equivalent to ``form.is_submitted() and form.validate()``
        """
        return self.is_submitted() and self.validate()