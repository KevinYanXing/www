# coding=utf-8
from flask.ext.principal import Permission as per
from flask.ext.principal import IdentityContext as ctx
from functools import wraps
from flask import redirect, request


class IdentityContext(ctx):
    """
    重写，以实现自己的需求，有些方法需要外部定义
    """
    '''
    如果指定了这个valid_fun，此函数必须返回  返回的地址，如果不需要跳转地址直接返回None，继续里面的方法体
    '''
    valid_fun = None

    def __call__(self, f):
        @wraps(f)
        def _decorated(*args, **kw):
            with self:
                # 先处理自己的需求
                if self.valid_fun:
                    ret = self.valid_fun(f, *args, **kw)
                    if ret:
                        return redirect(ret)
                rv = f(*args, **kw)
            return rv
        return _decorated


class Permission(per):

    def require(self, http_exception=None):
        """
        重载此方法用于实现自身 需求
        :param http_exception:
        :return:
        """
        return IdentityContext(self, http_exception)