#coding=utf8
"""
dama = PyDama2Api('', '')
task = dama.decode("code.jpg", 42, timeout=20)
dama.get_result(task['id'])
"""


import time
import requests
import textwrap
import mcrypt
import urllib
from hashlib import md5


class PyDama2Encrypt:
    def __init__(self, app_key):
        self._content = mcrypt.MCRYPT("des", "ecb")
        if len(app_key) != 32:
            raise Exception(u"加密key必须为32位字符串")
        self._content.init(self._key16tokey8(self._hex2bin(app_key)))

    @staticmethod
    def _key16tokey8(key16):
        key8 = ''
        for i in xrange(0, 8):
            key8 += chr(ord(key16[i]) ^ ord(key16[i + 8]))
        return key8

    @staticmethod
    def _hex2bin(s):
        if len(s) % 2 == 1:
            raise Exception("Error String is Passed")

        res = ''
        for one in textwrap.wrap(s, 2):
            res += chr(int(one, 16))
        return res

    def encrypt(self, s):
        block = mcrypt.get_block_size('des', 'ecb')
        pad = block - (len(s) % block)
        s += chr(pad) * pad
        return self._content.encrypt(s).encode('hex')

    def decrypt(self, s):
        self._content.reinit()
        s = self._content.decrypt(self._hex2bin(s))
        pad = ord(s[-1])
        return s[:len(s) - pad]


class PyDama2Api:
    def __init__(self, username, password):
        self._HOST = "api.dama2.com"
        self._PORT = 7788
        self._APP_KEY = "6220e830988e361d748ac3d92baca265"
        self._APP_ID = 37619
        self._prefix_sess = '_dama2_api_'
        self._expire_time = 540
        self._username = username
        self.password = password
        self._dama2_lib = PyDama2Encrypt(self._APP_KEY)
        self._session = {}

    def api_url(self, path):
        return "http://%(host)s:%(port)d/%(path)s" % ({
            'host': self._HOST,
            'port': self._PORT,
            'path': path
        })

    def login(self):
        if self.is_auth_alive():
            return True
        req = requests.get(self.api_url("/app/preauth"))
        if req.status_code != 200 or req.reason != "OK":
            return False
        if req.json().get('ret', None) != "0":
            raise Exception("ret error", req.json().get('ret', None))
        password = md5(self.password).hexdigest()
        enc_info = '\n'.join([req.json().get('auth', ''), self._username, password])
        enc_info = self._dama2_lib.encrypt(enc_info)
        params = {'appID': self._APP_ID, 'encinfo': enc_info}
        params = urllib.urlencode(params)
        req = requests.get(self.api_url("/app/login?%s" % params))
        if req.json().get('ret', None) == '0':
            self.set_auth(req.json().get('auth', ''))
            return True
        if req.json().get('ret', None) == "-104":
            raise Exception("用户名或密码错误", 1)
        return False

    def set_auth(self, auth):
        self._session[self._prefix_sess + 'name'] = self._username
        self._session[self._prefix_sess + 'password'] = self.password
        self._session[self._prefix_sess + 'auth'] = urllib.unquote_plus(auth)
        self._session[self._prefix_sess + 'time'] = int(time.time())

    def is_auth_alive(self):
        if not (self._prefix_sess + 'auth') in self._session:
            return False
        if int(time.time()) - self._session.get(self._prefix_sess + 'time', 0) > self._expire_time:
            return False
        if self._session.get(self._prefix_sess + 'name', None) != self._username:
            return False
        if self._session.get(self._prefix_sess + 'password', None) != self.password:
            return False
        return True

    def get_auth(self):
        """
            获取用户auth信息
            @return mixed 成功返回auth, 失败返回false
        """
        if not self.is_auth_alive():
            self.login()
        return self._session.get(self._prefix_sess + 'auth', False)

    def http_request(self, path, params, files=None, method='GET'):
        if method == "GET":
            req = requests.get(self.api_url("%s?%s" % (path, urllib.urlencode(params))))
        else:
            req = requests.post(self.api_url(path), files=files, data=params)
        if req.status_code != 200 or req.reason != "OK":
            raise Exception(req.status_code, req.reason)
        if req.json().get('ret', None) in ['-10001', '-10003']:
            if (self._prefix_sess + 'auth') in self._session:
                del self._session[self._prefix_sess + 'auth']
            self.login()
            params['auth'] = self.get_auth()
            if method == "GET":
                req = requests.get(self.api_url("%s?%s" % (path, urllib.urlencode(params))))
            else:
                req = requests.get(self.api_url(path), files=files, data=params)
            if req.status_code != 200 or req.reason != "OK":
                raise Exception(req.status_code, req.reason)
        if 'auth' in req.json() and req.json().get('ret', None) == '0':
            self.set_auth(req.json()['auth'])
        return req.json()

    def register(self, username, password, email, qq='', tel=''):
        """
            注册用户
        """
        req = self.http_request("/app/preauth", {})
        if req.json().get('ret', None) != 0:
            return False
        password = md5(password).hexdigest()
        encinfo = '\n'.join([req.json().get('auth', ''), username, password])
        encinfo = self._dama2_lib.encrypt(encinfo)
        params = {'appID': self._APP_ID, 'encinfo': encinfo, 'qq': qq, 'email': email, 'tel': tel}
        req = self.http_request("/app/register", params)
        return req

    def read_info(self):
        return self.http_request('/app/readInfo', {'auth': self.get_auth()})

    def get_balance(self):
        return self.http_request('/app/getBalance', {'auth': self.get_auth()})

    def decode(self, filename, auth_type, length=None, timeout=None):
        """
            * POST 文件打码
            * post上传文件打码
            * @param string 图片文件的路径
            * @param int 验证码类型, 参考打码兔wiki, http://wiki.dama2.com/index.php?n=ApiDoc.GetSoftIDandKEY1
            * @param int 验证码长度 [可选]
            * @param int 超时时间, 表示验证码多少会超时
            * @return array
        """
        files = {'image': open(filename, 'rb')}
        params = {
            'type': auth_type,
            'auth': self.get_auth()
        }
        if length:
            params['len'] = length
        if timeout:
            params['timeout'] = timeout
        return self.http_request("/app/decode", params, files, "POST")

    def decode_url(self, url, auth_type, cookie=None, referer=None, length=None, timeout=None):
        """
            * URL 打码
            * 通过传递验证码的url地址来打码
            * @param string url地址
            * @param int 验证码类型, 参考打码兔wiki, http://wiki.dama2.com/index.php?n=ApiDoc.GetSoftIDandKEY1
            * @param string cookie值 [可选]
            * @param string referer [可选]
            * @param int 验证码的长度, 表示多少位验证码
            * @param int 超时时间, 表示验证码多少会超时
            * @return array
        """
        params = {
            'url': url,
            'type': auth_type,
            'auth': self.get_auth()
        }
        if cookie:
            params['cookie'] = cookie
        if referer:
            params['referer'] = referer
        if length:
            params['len'] = length
        if timeout:
            params['timeout'] = timeout
        return self.http_request('/app/decodeURL', params, "POST")

    def get_result(self, task_id):
        """
            * 查询打码结果
            * 由于打码的过程需要时间, 需要根据自己软件情况实现轮询来查询结果
            * @param int 验证码id,  由 decode 或 decode_url 函数打码成功后返回的id字段
            * @return array
        """
        params = {
            'auth': self.get_auth(),
            'id': task_id
        }
        return self.http_request("/app/getResult", params)

    def report_error(self, task_id):
        """
            * 报告错误
            * 根据get_result获取到打码的结果后, 判断打码是否正确, 不正确调用此接口
            * @param int 验证码id,  由 decode 或 decode_url 函数打码成功后返回的id字段
            * @return array
        """
        params = {
            'auth': self.get_auth(),
            'id': task_id
        }
        return self.http_request('/app/reportError', params)


