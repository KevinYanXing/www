# coding=utf-8
"""
sudo pip install whoosh
sudo pip install jieba

"""
__author__ = "damy"
import os
from whoosh.index import create_in, open_dir
from whoosh.fields import Schema, TEXT, ID, KEYWORD, DATETIME, NUMERIC
from whoosh.analysis import Tokenizer, Token
from whoosh import qparser
from jieba.analyse import ChineseAnalyzer
from datetime import datetime
analyzer = ChineseAnalyzer()


class WhooshCourt(object):
    """
    使用whoosh做全文检索
    """
    def __init__(self):
        """
        初始化
        """
        self.indexdir = None
        self.indexname = "lawer"
        self.schema = self.get_schema()
        self.ix = None

    def init_app(self, app):
        self.indexdir = app.config.get('WHOOSH_INDEX_DIR')
        if not os.path.exists(self.indexdir):
            os.mkdir(self.indexdir)
            create_in(self.indexdir, self.schema, indexname=self.indexname)
        # create an index obj and buffered writer
        self.ix = open_dir(self.indexdir, indexname=self.indexname)

    def build_index(self, datas):
        ix = create_in(self.indexdir, self.schema, indexname=self.indexname)
        writer = ix.writer()
        for item in datas:
            # print 'start', item.mongo_id
            if not item.idx:
                writer.add_document(**self._load_docfitem(item))
            elif item.idx == 2:
                writer.update_document(**self._load_docfitem(item))
            item.idx = 1
            item.save()
            # print 'finish', item.mongo_id
        writer.commit()

    # def _re_build_law(self, law):
    #     ret = []
    #     for law_item in law:
    #         for item in law_item['v']:
    #             ret.append('%s%s' % (law_item['k'], item['k']))
    #     # ret = ','.join(ret)
    #     # if not ret:
    #     #     ret = 'empty'
    #     return ret

    def _load_docfitem(self, item):
        if type(item) == dict:
            return {'nid': item['_id'],
                    'd': datetime.fromtimestamp(item['d']),
                    'title': item['title'],
                    'html': item['html'],
                    'court': item['court'],
                    'reason': item['reason'],
                    't': item['t'],
                    'process': item['process'],
                    'prov': item['prov'],
                    'city': item['city'],
                    'result': item['result'],
                    'money': item['money']
            }
        else:
            return {'nid': item.mongo_id,
                    'd': datetime.fromtimestamp(item.d),
                    'title': item.title,
                    'html': item.html,
                    'court': item.court,
                    'reason': item.reason,
                    't': item.t,
                    'process': item.process,
                    'prov': item.prov,
                    'city': item.city,
                    'result': item.result,
                    'money': item.money
            }

    def get_schema(self):
        return Schema(
            nid=ID(unique=True, stored=True),
            d=DATETIME(stored=True, sortable=True),
            title=TEXT(stored=True, analyzer=analyzer),
            html=TEXT(stored=False, analyzer=analyzer),
            court=TEXT(phrase=False, stored=True),
            reason=TEXT(phrase=False, stored=True),
            t=TEXT(phrase=False, stored=True),
            process=TEXT(phrase=False, stored=True),
            prov=NUMERIC(stored=True),
            city=NUMERIC(stored=True),
            result=NUMERIC(stored=True),
            money=NUMERIC(stored=True),
        )

    def commit(self, writer):
        """
        Commit the data to index.
        """
        writer.commit()
        return True

    # def update(self, data, writer=None):
    #     """
    #     更新文档
    #     """
    #     if writer is None:
    #         writer = self.ix.writer()
    #     writer.update_document(**self._load_docfitem(data))
    #     writer.commit()
    #
    # def add(self, data, writer=None):
    #     """
    #     新增文档
    #     """
    #     if writer is None:
    #         writer = self.ix.writer()
    #     writer.add_document(**self._load_docfitem(data))
    #     writer.commit()

    def parse_query(self, query):
        parser = qparser.MultifieldParser(
            ["court", "title", "reason", "html", "t", "process"], self.ix.schema)
        return parser.parse(query)

    def search(self, query, page, page_size=30):
        """
        Search the index and return the results list to be processed further.
        """
        results = []
        with self.ix.searcher() as searcher:
            result_page = searcher.search_page(
                self.parse_query(query), page, pagelen=page_size)
            # create a results list from the search results
            for result in result_page:
                results.append(dict(result))
        return {'results': results, 'total': result_page.total}

    def delele_by_id(self, id):
        writer = self.ix.writer()
        result = writer.delete_by_term('nid', str(id))
        writer.commit()
        return result

    def close(self):
        """
        Closes the searcher obj. Must be done manually.
        """
        self.ix.close()