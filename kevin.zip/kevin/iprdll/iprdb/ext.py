# coding=utf-8
def setup():
    import models as M
    pass

