# coding=utf-8
import time
import datetime
from damydb.models import Models
from damydb.ext import db
from werkzeug.utils import cached_property
from iprdb.help import Help

class PatentsImg(Models):
    """
    专利图片库
    _id 申请号/专利号
    page 总页数
    path 路径
    app_pic 申请文件
    pic 授权文件
    图片查看页面
    http://egaz.sipo.gov.cn/FileWeb/sfs?path=mOVz4AfiN7gtNcMRsSisG7aAln3SEAN_uVJQ9xEvsB2StZW6dPsBRXJtufsXmTigVgd-Ac5oNgAMVczawQBB56O7Ocew4VHAn88vKeEpJn8&format=swf&page=1
    """
    db = db.PATENTS

    @cached_property
    def app_pic_url(self):
        if not self.app_pic:
            return None
        url = 'http://egaz.sipo.gov.cn/FileWeb/sfs?path=%s&format=swf&page=1' % self.app_pic
        return url

    @cached_property
    def pic_url(self):
        if not self.pic:
            return None
        url = 'http://egaz.sipo.gov.cn/FileWeb/sfs?path=%s&format=swf&page=1' % self.pic
        return url

class PatentsTran(Models):
    """
    专利事务列表
    _id 申请号／专利号
    logs    日志列表，[{}]
    """
    db = db.PATENTS

    @cached_property
    def trans_detail(self):
        """
        获取专利事务的明细列表
        """
        return self.data.get('all')

class Patents(Models):
    """
    专利数据库
    申请号/专利号   _id
    申请日         appdate

    状态          status

    描述          desc

    公告号        ann_code
    公告日期      ann_date

    授权号        auth_code
    授权日        auth_date

    发明名称      name
    主分类号      cid   []
    姓名或名称     appperson
    发明人/设计人  author  []
    地址          addr
    邮编          zip
    代理人        agent_user
    代理公司      agent_name
    代理号        agent_code
    专利类型       ptype (1,2,3,4)

    分案申请      fenan
    pct进入国家阶段日 pct_d
    pct申请数据   pct_appd
    pct公布数据   pct_pubd
    对比文件      vs_paper
    优先权        priority

    status 3有权 2进行中 1无权

    缩略图         pic    http://epub.sipo.gov.cn/ ＋ 当前值得

    """
    db = db.PATENTS

    STATUS = {
        'rights': 3,  # 有权
        'invalid': 1,  # 无效
        'progress': 2  # 公告中
    }

    PTYPE = {
        u'发明公布': 1,
        u'发明授权': 2,
        u'实用新型': 3,
        u'外观设计': 4
    }

    @classmethod
    def index(cls):
        cls.ensure_index(appperson=-1, status=-1)
        cls.ensure_index(appperson=-1, name=-1)
        cls.ensure_index(appperson=-1, agent_name=-1)
        cls.ensure_index(appperson=-1, ptype=-1)
        cls.ensure_index(appperson=-1, appdate=-1)

    @staticmethod
    def format_ptype_id(tname):
        """
        根据专利类型转换成数字
        """
        ret = {
            u'发明公布': 1,
            u'发明授权': 2,
            u'实用新型': 3,
            u'外观设计': 4
        }
        return ret[tname]

    @staticmethod
    def format_ptype_en(tid):
        """
        将专利类型的ID转换成拼音，用于查询
        """
        ret = {
            1: 'fmmost',
            2: 'fmmost',
            3: 'xxmost',
            4: 'wgmost',
        }
        return ret[tid]

    @cached_property
    def ptype_cn(self):
        """
        专利类型的中文
        """
        ret = {
            1: u'发明公布',
            2: u'发明授权',
            3: u'实用新型',
            4: u'外观设计',
        }
        return ret[self.ptype]

    @cached_property
    def appdate_format(self):
        return Help.format_ts(self.appdate, formate=u'%Y年%m月%d日')

    @cached_property
    def pic_url(self):
        return 'http://epub.sipo.gov.cn/' + self.pic

    @cached_property
    def validity(self):
        """
        有效期
        """
        if self.ptype == 1:
            return 0
        elif self.ptype == 2:
            return 20
        else:
            return 10

    @cached_property
    def status(self):
        """
        有效期重置
        """
        if self.ptype == 1:
            ret = 2
        else:
            app_date = datetime.date.fromtimestamp(self.appdate)
            app_date = datetime.date(app_date.year + self.validity, app_date.month, app_date.day)
            now_date = datetime.date.today()
            if app_date < now_date:
                ret = 1
            else:
                ret = 3
        if ret != self.data.get('status'):
            Patents.upcmd({'_id': self.mongo_id}, update={'$set': {'status': ret}})
        return ret

    @cached_property
    def renewal_date(self):
        if not self.validity:
            return u'无'
        app_date = datetime.date.fromtimestamp(self.appdate)
        today = datetime.date.today()
        new_date = datetime.date(year=today.year, month=app_date.month, day=app_date.day)
        if new_date < today:
            new_date = datetime.date(year=today.year + 1, month=app_date.month, day=app_date.day)
        left_date = new_date - today
        if left_date.days >= 30:
            month = left_date.days / 30
            return u'%s个月后' % month
        else:
            return u'%s天后' % left_date.days

    @cached_property
    def ptype_ico(self):
        ret = {
            1: 'faminggongkaifuzhi',
            2: 'famingshouquanfuzhi',
            3: 'shiyongxinxingfuzhi',
            4: 'iconsheji2',
        }
        return ret[self.ptype]

    @cached_property
    def year_left(self):
        """
        计算时效
        """
        if self.status <= 2:
            return u'无'

        app_date = datetime.date.fromtimestamp(self.appdate)
        app_date = datetime.date(app_date.year + self.validity, app_date.month, app_date.day)
        today = datetime.date.today()
        d = app_date - today
        return int(d.days / 365)

    @staticmethod
    def cat_name(cid):
        c = PatentCat.findone(cid=cid)
        if c:
            return c.n
        else:
            return u'暂无'

    @cached_property
    def jb_img(self):
        if self.status == 1:
            return 'jb_wq.png'
        elif self.status == 2:
            return 'jb_jx.png'
        else:
            if self.renewal_date.find(u'天后') != -1:
                return 'jb_jjdq.png'
            else:
                return 'jb_yq.png'

    @cached_property
    def trans(self):
        return PatentsTran.one(self.mongo_id)

    @cached_property
    def patent_img(self):
        return PatentsImg.one(self.mongo_id)

class PatentCat(Models):
    """
    专利分类库
    cid     分类号（直接全拼）
    n   名称
    """
    db = db.PATENTS

    @classmethod
    def index(cls):
        """
        建立索引
        :return:
        """
        cls.ensure_index(cid=-1)