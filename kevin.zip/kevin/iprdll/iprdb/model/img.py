# coding=utf-8

import os
from PIL import Image, ImageEnhance

class Img:
    """
    图片操作辅助类
    """
    POSITION = ('LEFTTOP', 'RIGHTTOP', 'CENTER', 'LEFTBOTTOM', 'RIGHTBOTTOM')

    PADDING = 10

    def __init__(self, img_file, config=None):
        self.img_file = img_file
        if config:
            self.config = config
            self.mark_file = config.get('WARTER_MARK', None)
        else:
            self.config = {}
            self.mark_file = None

        self.img = Image.open(self.img_file)


    def reduce_opacity(self, im, opacity):
        """
        对图片进行透明处理
        :param im:
        :param opacity:
        :return:
        """
        assert opacity >= 0 and opacity <= 1
        if im.mode != 'RGBA':
            im = im.convert('RGBA')
        else:
            im = im.copy()
        alpha = im.split()[3]
        alpha = ImageEnhance.Brightness(alpha).enhance(opacity)
        im.putalpha(alpha)
        return im

    def watermark(self, position=POSITION[4], opacity=1):
        """
        给图片加上水印
        :param im:
        :param m_file:
        :param position:
        :param opacity:
        :return:
        """
        if not self.mark_file:
            return
        # 如果是动图不加水印
        if self.img.info.get('duration', 0) > 0:
            return

        mark = Image.open(self.mark_file)
        # '水印图太大，那么不加水印'
        if mark.size[0] * 2 >= self.img.size[0] or mark.size[1] * 2 >= self.img.size[1]:
            return

        # 对水印图进行透明处理
        if opacity < 1:
            mark = self.reduce_opacity(mark, opacity)
        if self.img.mode != 'RGBA':
            im = self.img.convert('RGBA')
        # create a transparent layer the size of the image and draw the
        # watermark in that layer.
        layer = Image.new('RGBA', self.img.size, (0, 0, 0, 0))
        if position == 'title':
            for y in range(0, self.img.size[1], mark.size[1]):
                for x in range(0, self.img.size[0], mark.size[0]):
                    layer.paste(mark, (x, y))
        elif position == 'scale':
            # scale, but preserve the aspect ratio
            ratio = min(float(self.img.size[0]) / mark.size[0], float(self.img.size[1]) / mark.size[1])
            w = int(mark.size[0] * ratio)
            h = int(mark.size[1] * ratio)
            mark = mark.resize((w, h))
            layer.paste(mark, ((self.img.size[0] - w) / 2, (self.img.size[1] - h) / 2))
        elif position == self.POSITION[0]:
            # lefttop
            position = (self.PADDING, self.PADDING)
            layer.paste(mark, position)
        elif position == self.POSITION[1]:
            # righttop
            position = (self.img.size[0] - mark.size[0]-self.PADDING, self.PADDING)
            layer.paste(mark, position)
        elif position == self.POSITION[2]:
            # center
            position = ((self.img.size[0] - mark.size[0])/2, (self.img.size[1] - mark.size[1])/2)
            layer.paste(mark, position)
        elif position == self.POSITION[3]:
            # l eft bottom
            position = (self.PADDING, self.img.size[1] - mark.size[1]-self.PADDING,)
            layer.paste(mark, position)
        else:
            # right bottom (default)
            position = (self.img.size[0] - mark.size[0]-self.PADDING, self.img.size[1] - mark.size[1]-self.PADDING,)
            layer.paste(mark, position)

        # composite the watermark with the layer
        self.img = Image.composite(layer, self.img, layer)
        return self.img

    def thumbnails(self, size, warter=True):
        """
        生成指定大小的缩略图
        :param size:
        :return:
        """
        if size[0] == 0 and size[1] == 0:
            '不缩'
            pass
        elif self.img.size[0] <= size[0] and self.img.size[1] <= size[1]:
            '不缩'
            pass
        else:
            self.img.thumbnail(size, Image.ANTIALIAS)
        if warter:
            self.watermark(self.POSITION[0], opacity=0.7)

        return self.img

    # def save(self, size):
    #     """
    #     保存文件到硬盘上
    #     并返回文件地址
    #     :return:
    #     """
    #     if size:
    #         size = map(str, size)
    #         size = '_'.join(size)
    #         pth = self.img_file.replace('.', '_%s.' % size)
    #     else:
    #         pth = self.img_file
    #     self.img.save(pth)
    #
    #     return pth




    @staticmethod
    def size_path(pth, size):
        """
        获取有尺寸的文件名
        :param pth:
        :param size:
        :return:
        """
        if type(size) != str and type(size) != unicode:
            size = map(str, size)
            size = '_'.join(size)

        main, ext = pth.rsplit('.', 1)
        return '%s_%s.%s' % (main, size, ext)

    @staticmethod
    def file_ext(pth):
        main, ext = pth.rsplit('.', 1)
        return ext