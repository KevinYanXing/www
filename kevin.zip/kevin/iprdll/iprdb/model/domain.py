# coding=utf-8
import socket
import datetime
import requests
from pyquery import PyQuery
from werkzeug.utils import cached_property

from damydb.ext import db
from iprdb.help import Help
from damydb.models import Models


class Domains(Models):
    """
    域名数据库
    domain  域名
    admin_name  注册人姓名
    reg_time    注册时间
    expire_time 过期时间

    title / title2  网站标题
    ip  IP
    user    当前用户
    status  状态
    status_code 状态码
    lock    锁定 boolean
    """
    db = db.DOMAINS

    STATUS = {
        'normal': 1,  # 正常
        'abnormal': 0  # 异常
    }

    @staticmethod
    def whois_from_aizhan(domain):
        html = []
        url = 'http://whois.aizhan.com/index.php?r=site/searchDomain&s=%s&update=true&field=base' % domain
        resp = requests.get(url)
        html.append(resp.text)
        url = 'http://whois.aizhan.com/index.php?r=site/searchDomain&s=%s&update=true&field=details' % domain
        resp = requests.get(url)
        html.append(resp.text)
        return ''.join(html)

    @staticmethod
    def whois_domain(domain):
        # try:
        #     w = pythonwhois.get_whois(domain)
        #     info = {
        #         'admin_name': w['contacts']['registrant']['name'],
        #         'reg_time': Help.format_ts(time.mktime(w['creation_date'][-1].timetuple()), formate=u'%Y年%m月%d日'),
        #         'expire_time': Help.format_ts(time.mktime(w['expiration_date'][-1].timetuple()), formate=u'%Y年%m月%d日')
        #     }
        #     return info
        # except:
        #     return
        def date_parser(s):
            return s.split(':')[1].strip().replace('-', u'年', 1).replace('-', u'月', 1) + u'日'

        text = Domains.whois_from_aizhan(domain)
        html = PyQuery(text)
        info = {
            'admin_name': html('a[href^="/reverse-whois/?registrant="]').text()
        }
        tmp = text.split('</br>')
        for r in tmp:
            if u'过期时间' in r:
                info['expire_time'] = date_parser(r)
            if u'创建时间' in r:
                info['reg_time'] = date_parser(r)
        return info

    @staticmethod
    def site_info(domain):
        try:
            url = 'http://%s' % domain
            resp = requests.get(url)
            status = Domains.STATUS['abnormal']
            if resp.status_code == 200:
                status = Domains.STATUS['normal']
            html = PyQuery(resp.content)
            info = {
                'title': html('title').text().strip(),
                'ip': socket.gethostbyname('%s' % domain),
                'status': status,
                'status_code': resp.status_code
            }
            return info
        except:
            return None

    @cached_property
    def format_reg_time(self):
        return Help.format_ts(self.reg_time, formate=u'%Y年%m月%d日')

    @cached_property
    def format_expire_time(self):
        return Help.format_ts(self.expire_time, formate=u'%Y年%m月%d日')

    @cached_property
    def left_date(self):
        expire_date = datetime.date.fromtimestamp(self.expire_time)
        today = datetime.date.today()
        left_days = expire_date - today
        tmp_days = left_days.days
        year = 0
        month = 0
        if tmp_days <= 0:
            return u'已过期'
        if tmp_days > 365:
            year = tmp_days / 365
            tmp_days %= 365
        if tmp_days > 30:
            month = tmp_days / 30
            tmp_days %= 30
        s = ''
        if year > 0:
            s += u'%s年' % year

        if month > 0:
            s += u'%s个月' % month

        if tmp_days > 0:
            s += u'%s天' % tmp_days
        return s

    @cached_property
    def expiring(self):
        """
        即将到期
        剩余时间在30天以内的定义为即将到期
        """
        expire_date = datetime.date.fromtimestamp(self.expire_time)
        today = datetime.date.today()
        left_days = expire_date - today
        if left_days.days <= 30:
            return True

    @cached_property
    def status_code_format(self):
        if self.status_code == 200:
            return u'网站访问正常 状态码：%s' % self.status_code
        else:
            return u'网站访问异常 状态码：%s' % self.status_code

    @cached_property
    def can_edit(self):
        if self.auid == Help.get_curr_user_id():
            return True
        else:
            return False
