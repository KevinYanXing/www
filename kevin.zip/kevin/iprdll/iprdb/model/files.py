# coding=utf-8
from damydb.ext import db
from damydb.models import Models
from werkzeug.utils import cached_property
from bson import ObjectId
from upbase import Upload
import os
from img import Img

class Files(Models):
    """
    上传的文件列表
    _id
    name 文件路径
    uid 上传用户ID
    sizes 生成小图的尺寸列表, ['300_300', '100_100']
    """
    db = db.FILES

    @classmethod
    def index(cls):
        cls.ensure_index(uid=-1)

    @classmethod
    def new_file(cls, file, file_type, uid, config):
        """
        生成并保存上传的文件
        :param file:
        :param file_type:
        :param  uid: 上传文件的用户名
        :param config: 网站配置文件
        :return: 返回上传的文件ID
        """
        # 先存文件
        file_id = ObjectId()
        upload = Upload(file_type, config)
        pth = upload.save(file, str(file_id) + '.')
        if pth < 0:
            return pth
        item = cls()
        item.mongo_id = file_id
        item.name = pth
        item.uid = uid
        item.addsave()
        # print file_id
        return file_id

    def beforeRemove(self):
        """
        移除图片数据的时候要将所有小图数据全部清空掉
        这里需要配置文件的dest配置
        :return:
        """
        try:
            os.remove(self.file_path)
        except:
            pass
        # 如果有的话

        if self.sizes:
            for item in self.sizes:
                pth = Img.size_path(self.file_path, item)
                try:
                    os.remove(pth)
                except:
                    pass

    def thumb(self, size=None):
        """
        生成指定大小的图片［注意，这个只有在文件是图片的时候才能调用］
        :param size:
        :return: 返回缩图地址
        """
        if size and size != [0, 0] and size != (0, 0):
            pth = Img.size_path(self.file_path, size)
            if os.path.exists(pth):
                return pth
            img = Img(self.file_path)
            img.thumbnails(size)
            img.img.save(pth)
            # 将这个size写入数据库中备用
            tmp = self.sizes
            if not tmp:
                tmp = []
            size = tuple(size)
            tmp.append('%d_%d' % size)
            self.sizes = tmp
            self.save()

            return pth
        else:
            return self.file_path



    @cached_property
    def file_path(self):
        """
        主文件路径
        :return:
        """
        from flask import current_app
        pth = current_app.config.get('UPLOAD_DEST')
        pth = os.path.join(pth, self.name)
        return pth

    @cached_property
    def ext(self):
        """
        获取文件扩展名
        :return:
        """
        return Img.file_ext(self.name)

    @staticmethod
    def spilt_path(pth):
        """
        返回一个文件路径的文件夹名，和文件名
        :param pth:
        :return:
        """
        return os.path.dirname(pth), os.path.basename(pth)