# coding=utf-8
from werkzeug.utils import secure_filename
import os
import posixpath

def lowercase_ext(filename):
    if '.' in filename:
        main, ext = filename.rsplit('.', 1)
        return main + '.' + ext.lower()
    else:
        return filename.lower()

def extension(filename):
    return filename.rsplit('.', 1)[-1]

class Upload:
    """
    文件上传类库,重新修改
    """
    def __init__(self, upType, config):
        self.upType = upType.upper()
        self.config = config
        self.dest = self.config.get('UPLOAD_DEST')
        self.type_setting = self.config.get('UPLOAD_%s_SETTING' % self.upType, {})
        self.max_size = self.type_setting.get('SIZE', 100) * 1024
        self.exts = self.type_setting.get('EXTS', [])
        # self.exts = map(lambda a: a.lower(), self.exts)

    def extension_allowed(self, ext):
        """
        验证文件扩展名是否允许上传
        :param ext:
        :return:
        """
        return ext.lower() in self.exts

    def file_allowed(self, storage, basename):
        """
        验证文件是否允许上传
        :param storage:
        :param basename:
        :return:
        这里还可以处理大小限制
        """

        return self.extension_allowed(extension(basename))

    def resolve_conflict(self, target_folder, basename):
        """
        防止存储的文件名重复
        """
        name, ext = basename.rsplit('.', 1)
        count = 0
        while True:
            count = count + 1
            newname = '%s_%d.%s' % (name, count, ext)
            if not os.path.exists(os.path.join(target_folder, newname)):
                return newname


    def save(self, storage, name=None):
        """
        保存当前文件
        :param storage: 需要保存的文件
        :param name:    保存后的名字，如果最后直接带“.”符号就是保存上传原格式，否则保存文件名指定的格式,这个名字不允许带上目录名
        :return:
                -1 表示扩展名不允许或者文件大小限制
        """
        # if not isinstance(storage, FileStorage):
        #     raise TypeError("storage must be a werkzeug.FileStorage")
        # if folder is None and name is not None and "/" in name:
        #     folder, name = name.rsplit("/", 1)

        basename = lowercase_ext(secure_filename(storage.filename))
        if name:
            if name.endswith('.'):
                basename = name + extension(basename)
            else:
                basename = name

        if not self.file_allowed(storage, basename):
            return -1

        # if folder:
        target_folder = os.path.join(self.dest, self.upType.lower())
        # else:
        #     target_folder = self.dest
        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
        if os.path.exists(os.path.join(target_folder, basename)):
            basename = self.resolve_conflict(target_folder, basename)

        target = os.path.join(target_folder, basename)
        storage.save(target)
        return posixpath.join(self.upType.lower(), basename)

