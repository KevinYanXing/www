# coding=utf-8
from damydb.models import Models, ChildModel
from damydb.ext import db
from werkzeug.utils import cached_property
from iprdb.help import Help
from iprdb.model.tm import Tms
from iprdb.model.copyright import Ucr
from iprdb.model.patent import Patents
from iprdb.model.domain import Domains
from damydb.user import User


class Target(Models):
    """
    侵权人档案数据库
    n 侵权人名
    desc 描述
    uid 所属用户ID
    pid 图片封面ID

    clist  案件列表(最新的案件放在最上面)
        c 内容 t 类型 s 状态 d 时间 _id 主键（用于删除) files {'name', 'desc'} rp 回复 pay 支出 income 收入
        状态 PROCESS
        rp = [{
            '_id': object id
            'uid': uid
            't': time
            'c': reply
        }]

    addr 地址


    tms 商标列表
    []
    pts 专利列表
    []
    """
    db = db.TARGET

    @classmethod
    def index(cls, d_tb_name=None):
        cls.ensure_index(d_tb_name=d_tb_name, uid=-1)
        cls.ensure_index(d_tb_name=d_tb_name, uid=-1, n=-1)


    PROCESS = dict(ing=1,   # 进行中
                   end=2)   # 已经结束

    CASETYPE = {'diaocha': 2,       # 调查
                'lvshihan': 1,      # 律师函
                'xingzheng': 4,     # 行政查处
                'xingshi': 5,       # 刑事打击
                'susong': 6,        # 诉讼
                'gongzheng': 3}     # 公正

    CASETYPE_STR = [
        (1, u'律师函'),
        (2, u'调查'),
        (3, u'公证'),
        (4, u'行政处罚'),
        (5, u'刑事打击'),
        (6, u'诉讼')
    ]

    TARGET_TYPE = [
        (1, U'生产商'),
        (2, U'批发商'),
        (3, U'零售商'),
        (4, U'网商')
    ]

    TARGET_MEMS = [
        (1, U'1-10人'),
        (2, U'10-100人'),
        (3, U'100-300人'),
        (4, U'300-1000人'),
        (5, U'1000人以上'),
    ]
    ADDRTYPE = {
        'base': 0,  # 基本
        'factory': 1,  # 工厂
        'shop': 2,  # 门市
        'company': 3  # 办公室
    }

    @cached_property
    def mems_cn(self):
        """
        人数
        :return:
        """
        for k, v in self.TARGET_MEMS:
            if k == self.mems:
                return v
        return ''

    @cached_property
    def tt_cn(self):
        """
        主体类型
        :return:
        """
        for k, v in self.TARGET_TYPE:
            if k == self.tt:
                return v
        return ''

    @cached_property
    def def_pic(self):
        """
        获取封面
        :return:
        """
        if not self.pid:
            return 'target_empty'
        return self.pid

    @cached_property
    def def_addr(self):
        """
        获取默认的地址
        :return:
        """
        if self.addrs:
            return self.addrs[0]
        return {'a': '', 'p': '', 't': 0, 'c': ''}

    @cached_property
    def last_status(self):
        if not self.clist:
            return u'新增'

        ret = ''
        item = self.clist[0]
        for k, v in self.CASETYPE_STR:
            if k == item['t']:
                ret = v
                break
        if item.get('s') == self.PROCESS['end']:
            ret += u'完成'
        else:
            ret += u'中'
        return ret

    @cached_property
    def clist_format(self):
        atype = [u'基本', u'工厂', u'门市', u'办公室']
        case_list = self.clist[::]
        for case in case_list:
            case['t'] = self.CASETYPE_STR[case['t']-1][1]
            case['days_ago'] = Help.days_ago(case['d'])
            case['d'] = Help.format_ts(case['d'], formate=u'%Y年%m月%d日')
            case['addr']['atype'] = atype[case['addr']['atype']]
            for f in case['files']:
                ext_name = f['name'].split('.')[-1]
                if ext_name in ['jpg', 'jpe', 'jpeg', 'png', 'gif', 'svg', 'bmp']:
                    f['img'] = 1
            if 'rp' in case:
                for reply in case['rp']:
                    reply['t'] = Help.days_ago(reply['t'])
                    reply['uid'] = User.one(self.uid)
            if 'tms' in case:
                case['with_tms'] = [Tms.one(tm) for tm in case['tms']]
            if 'copyrights' in case:
                case['with_copyrights'] = [Ucr.one(cpr) for cpr in case['copyrights']]
            if 'patents' in case:
                case['with_patents'] = [Patents.one(pt) for pt in case['patents']]
            if 'domains' in case:
                case['with_domains'] = [Domains.one(d) for d in case['domains']]

        return case_list

    @cached_property
    def case_type_count(self):
        clist = self.clist
        result = {x: 0 for x in range(1, 7)}
        for case in clist:
            result[case['t']] += 1
        return result

    @cached_property
    def tms_count(self):
        return sum([len(x['tms']) for x in self.clist if 'tms' in x])

    @cached_property
    def patents_count(self):
        return sum([len(x['patents']) for x in self.clist if 'patents' in x])

    @cached_property
    def copyrights_count(self):
        return sum([len(x['copyrights']) for x in self.clist if 'copyrights' in x])

    @cached_property
    def domains_count(self):
        return sum([len(x['domains']) for x in self.clist if 'domains' in x])

    def type_count(self, i):
        return len([x['t'] for x in self.clist if x['t'] == i])

    @cached_property
    def addr_list(self):
        return [x['addr'] for x in self.clist]

    @cached_property
    def tms_list(self):
        tms = []
        [tms.extend(x['tms']) for x in self.clist if 'tms' in x]
        tms = set(tms)
        tms = [Tms.one(x) for x in tms]
        return tms

    @cached_property
    def patent_list(self):
        patents = []
        [patents.extend(x['patents']) for x in self.clist if 'patents' in x]
        patents = set(patents)
        patents = [Patents.one(x) for x in patents]
        return patents

    @cached_property
    def copyright_list(self):
        copyrights = []
        [copyrights.extend(x['copyrights']) for x in self.clist if 'copyrights' in x]
        copyrights = set(copyrights)
        copyrights = [Ucr.one(x) for x in copyrights]
        return copyrights

    @cached_property
    def domain_list(self):
        domains = []
        [domains.extend(x['domains']) for x in self.clist if 'domains' in x]
        domains = set(domains)
        domains = [Domains.one(x) for x in domains]
        return domains

    @cached_property
    def income_total(self):
        income = 0
        for case in self.clist:
            income += case['income']
        return income

    @cached_property
    def pay_total(self):
        pay = 0
        for case in self.clist:
            pay += case['pay']
        return pay


class Clist(ChildModel):
    _parent = Target

    @cached_property
    def target(self):
        return Target.one(self._pid)

    @cached_property
    def can_reply(self):
        if self.target.uid != Help.currentUser().mongo_id:
            return False
        return True

    @cached_property
    def can_delete(self):
        if self.uid != Help.get_curr_user_id():
            return False
        return True
