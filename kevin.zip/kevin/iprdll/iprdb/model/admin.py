# coding=utf-8
from damydb.models import Models
from damydb.ext import db
from werkzeug.utils import cached_property
from datetime import datetime


class Vistor(Models):
    """
    通过推广的来访记录
    d 时间
    uid 注册id，只是访问没有纪录
    z   来自那个渠道
    q   来自那个关键词
    w   访问地址
    """
    db = db.VISTOR

    @cached_property
    def d_date(self):
        if self.d:
            return datetime.fromtimestamp(self.d).strftime('%Y-%m-%d %H:%M:%S')
        else:
            return '--'

    @cached_property
    def user(self):
        if self.uid:
            from damydb.user import User
            u = User.findone(uf=self.mongo_id)
            return u
        else:
            return None

    @cached_property
    def u_name(self):
        if self.user:
            return self.user.u
        else:
            return u'没注册'

    @cached_property
    def r_name(self):
        if self.user:
            return self.user.role_name
        else:
            return u'--'



class Pays(Models):
    """
    购买纪录
    d 购买日期
    u 购买用户ID
    r 版本
    b 银行ID
    s 状态
    m 总金额
    y 订购年份
    re 版本过期时间
    """
    db = db.PAYS

    @classmethod
    def index(cls):
        cls.ensure_index(u=-1, d=-1)

    @cached_property
    def user(self):
        """
        获取购买用户
        :return:
        """
        from damydb.user import User
        return User.one(self.u)

    def pay_sucess(self):
        """
        确认订单支付
        :return:
        """
        if self.s:
            return
        self.s = True
        self.save()
        if not self.user:
            return
        self.user.re = self.re
        self.user.r = self.r
        self.user.save()
        return True

    @cached_property
    def d_date(self):
        if self.d:
            return datetime.fromtimestamp(self.d).strftime('%Y-%m-%d %H:%M:%S')
        else:
            return '--'

    @cached_property
    def u_name(self):
        return self.user.u

    @cached_property
    def u_from(self):
        return self.user.uf

    @cached_property
    def re_date(self):
        return datetime.fromtimestamp(self.re).strftime('%Y-%m-%d')

    @cached_property
    def s_name(self):
        if self.s:
            return u'<span style="color:green">成功</span>'
        else:
            return u'<b style="color:red">失败</b>'

    @cached_property
    def r_name(self):
        from damydb.user import User
        return User.ROLES[self.r]

    # @cached_property
    # def note_desc(self):
    #     """
    #     处理记录条数
    #     :return:
    #     """
    #     if not self.note:
    #         return u'<b style="color:red">未处理</b>'
    #     return self.note

class Activekey(Models):
    """
    激活码管理
    d     创建日期
    v     激活码值
    ud    使用日期
    r     赠送版本
    rd    赠送版本到期时间
    """
    db = db.ACTIVEKEY

    @classmethod
    def index(cls):
        cls.ensure_index(v=-1)

    @cached_property
    def d_date(self):
        return datetime.fromtimestamp(self.d).strftime('%Y-%m-%d')

    @cached_property
    def rd_date(self):
        return datetime.fromtimestamp(self.rd).strftime('%Y-%m-%d')

    @cached_property
    def ud_date(self):
        if self.ud:
            return datetime.fromtimestamp(self.d).strftime('%Y-%m-%d')
        else:
            return u'未使用'

    @cached_property
    def role_name(self):
        from damydb.user import User
        return User.ROLES.get(self.r)


class Applys(Models):
    """
    d now
    uid 用户id
    note 反馈内容
    status 当前状态
    cid 客服id
    """
    STATUS = {
        'deny': 0,
        'accept': 1,
        'submit': 2
    }
    db = db.APPLYS

    @property
    def status_format(self):
        return [u'未通过', u'已通过', u'已提交'][self.status]

    @cached_property
    def user(self):
        """
        获取提交此条信息的用户数据
        :return:
        """
        from damydb.user import User
        if self.status in [0, 1]:
            return User.one(self.cid)
        else:
            return User.one(self.uid)


class Message(Models):
    """
    通知功能
    uid 用户ID
    d 通知时间
    status 状态（0 未读， 1 已读）
    title   标题
    msg     内容  支持HTML内容
    mt  类型： 0 商标 1 专利 2 版权 3 域名 4 调查案件 5 系统
    """
    db = db.MESSAGE
    # 通知状态
    STATUS = {
        'unread': 0,
        'read': 1
    }
    # 通知内容类型
    MESSAGE_TYPE = {
        'tm': 0,
        'patent': 1,
        'copyright': 2,
        'domain': 3,
        'case': 4,
        'sys': 5
    }

    @cached_property
    def user(self):
        from damydb.user import User
        return User.one(self.uid)

    @cached_property
    def message_type_cn(self):
        ret = [u'商标', u'专利', u'版权', u'域名', u'案件', u'系统']
        return ret[self.mt if self.mt else 0]

    @classmethod
    def send(cls, title, msg, uid, mt):
        """
        发送通知
        :param title:  标题
        :param msg:  内容
        :param uid: 接收人
        :param mt: 通知类型
        :return:
        """
        obj = cls()
        obj.msg = msg
        obj.title = title
        obj.status = 0
        obj.uid = uid
        obj.mt = mt
        obj.save()

    @classmethod
    def unread_count(cls, uid):
        """
        获取多少条未读通知
        :param uid:
        :return:
        """
        return cls.count(uid=uid, status=0)

    @classmethod
    def unread_list(cls, uid):
        """
        获取所有未读通知的列表(前10条)
        :param uid:
        :return:
        """
        return cls.top(sort=[('d', -1)], uid=uid, status=0, nums=10)

    def read(self):
        """
        标记为已读
        :return:
        """
        self.set_read(self.uid, self.mongo_id)

    @classmethod
    def set_read(cls, uid, id=None):
        """
        更新指定的ID为已读
        :param id:
        :return:
        """
        if id:
            cls.upcmd(where={'_id': id, 'uid': uid}, update={'$set': {'status': 1}}, upsert=False, multi=False)
        elif uid:
            cls.upcmd(where={'uid': uid}, update={'$set': {'status': 1}}, upsert=False, multi=False)