# coding=utf-8
from damydb.ext import db
from damydb.models import Models

class Tasklog(Models):
    db = db.TASKLOG

    @classmethod
    def index(cls):
        cls.ensure_index(d=-1)
        cls.ensure_index(s=-1)
        cls.ensure_index(ser=-1)
        cls.ensure_index(iden=-1)
        cls.ensure_index(l=-1)

class Weblog(Models):
    db = db.WEBLOG

    @classmethod
    def index(cls):
        cls.ensure_index(d=-1)
        cls.ensure_index(s=-1)
        cls.ensure_index(i=-1)