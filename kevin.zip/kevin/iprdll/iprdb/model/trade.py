# coding=utf-8
from damydb.models import Models
from damydb.ext import db
from werkzeug.utils import cached_property
from iprdb.model.tm import Tms
from iprdb.model.patent import Patents
from iprdb.model.copyright import Ucr
from iprdb.model.domain import Domains
from iprdb.help import Help


class Trade(Models):
    """
    ipr_type 类型
    con object_id
    to 联系人
    tel 电话
    price 价格
    bail 保证金
    ends 下架时间
    desc 描述
    uid user object_id
    license_file 证书
    trust_file 委托书
    """
    db = db.TRADE

    IPR_TYPES = {
        'tm': 0,
        'patent': 1,
        'copyright': 2,
        'domain': 3
    }

    @classmethod
    def index(cls):
        cls.ensure_index(uid=-1)
        cls.ensure_index(uid=-1, con=-1, ipr_type=-1)

    @cached_property
    def ipr(self):
        if self.ipr_type == self.IPR_TYPES['tm']:
            return Tms.one(self.con)
        if self.ipr_type == self.IPR_TYPES['patent']:
            return Patents.one(self.con)
        if self.ipr_type == self.IPR_TYPES['copyright']:
            return Ucr.one(self.con)
        if self.ipr_type == self.IPR_TYPES['domain']:
            return Domains.one(self.con)

    @cached_property
    def ipr_type_format(self):
        s = [u'商标', u'专利', u'版权', u'域名']
        return s[self.ipr_type]

    @cached_property
    def ends_format(self):
        return Help.format_ts(self.ends, formate=u'%Y年%m月%d日')
