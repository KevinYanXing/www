# coding=utf-8
from damydb.models import Models
from damydb.ext import db
from werkzeug.utils import cached_property
from iprdb.help import Help


class Copyright(Models):
    """
    版权数据库
    # 名称
    ret['n'] = html.eq(1).text()
    # 类型
    ret['tp'] = html.eq(3).text()
    # 权利人姓名
    ret['rg'] = html.eq(5).text()
    # 国籍
    ret['nt'] = html.eq(7).text()
    # 省份
    ret['pv'] = html.eq(9).text()
    # 城市
    ret['ct'] = html.eq(11).text()
    # 作者
    ret['auth'] = html.eq(13).text()
    # 完成日期
    ret['fd'] = Help.str_time_to_float(html.eq(15).text())
    # 首次发表日期
    ret['fpd'] = Help.str_time_to_float(html.eq(17).text())
    #
    ret['_id'] = html.eq(19).text()
    # 登记日期
    ret['ad'] = Help.str_time_to_float(html.eq(21).text())
    # 发布日期
    ret['pd'] = Help.str_time_to_float(html.eq(23).text())
    """
    db = db.COPYRIGHT


class Ucr(Models):
    """
    # reg_no 登记号
    # uid 用户id
    """
    db = db.COPYRIGHT

    @cached_property
    def format_fd(self):
        return Help.format_ts(self.fd, formate=u'%Y年%m月%d日')

    @cached_property
    def format_fpd(self):
        return Help.format_ts(self.fpd, formate=u'%Y年%m月%d日')

    @cached_property
    def format_ad(self):
        return Help.format_ts(self.ad, formate=u'%Y年%m月%d日')

    @cached_property
    def format_pd(self):
        return Help.format_ts(self.pd, formate=u'%Y年%m月%d日')

    @cached_property
    def can_edit(self):
        if self.auid == Help.get_curr_user_id():
            return True
        else:
            return False
