# coding=utf-8
from damydb.models import Models, ChildModel
from damydb.ext import db


class Court(Models):
    """
    法律文书数据库
    doc 编号
    title 标题
    d     案件日期
    court 法院名
    t     文书类型
    """
    db = db.COURT
#
#
# class Test(Models):
#     db = db.COURT
#
# class TestChild(ChildModel):
#
#     _parent = Test
