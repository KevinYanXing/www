# coding=utf-8
from damydb.models import Models
from damydb.ext import db
from datetime import datetime
from werkzeug.utils import cached_property
from time import time
from files import Files

class Searchhistory(Models):
    """
    搜索历史记录
    _id
    uid 用户ID
    d   搜索时间
    w   搜索内容
    """
    db = db.TMS

    @cached_property
    def d_date(self):
        return datetime.fromtimestamp(self.d).strftime('%Y-%m-%d')

class Ulist(Models):
    """
    使用记录
    _id
    tid 商标ID
    d   使用时间
    t   适用类型
    addr 使用地址
    pics 使用当场图片
    """
    db = db.TMS
    ULIST_T = {
        1 : u'展会',
        2 : u'广告',
        3 : u'产品',
        4 : u'许可'
    }

    @cached_property
    def tms(self):
        """
        商标详情
        """
        return Tms.one(self.tid)

    @cached_property
    def t_cn(self):
        """
        类型的中文描述
        """
        return self.ULIST_T[self.t]

    @cached_property
    def d_date(self):
        return datetime.fromtimestamp(self.d).strftime('%Y-%m-%d')

    def afterRemove(self):
        """
        同时删除图片
        """
        for id in self.pics:
            f = Files.one(id)
            f.remove()

class Tms(Models):
    """
    _id
    name 商标名
    uname 申请人（名）
    reg_no  注册号
    cid  注册类别
    agent   代理人（名）
    d  更新时间
    """
    REGISTER = 1  # 已注册
    INVALID = 0  # 无效
    UNDO = 2  # 撤销三年
    RENEWAL = 3  # 续费中
    UNSTABLE = 4  # 不稳定

    REGISTER_KEYS = [u'商标已注册', u'补发注册证完成', u'商标续展完成', u'商标注册申请完成']  # 已注册
    INVALID_KEYS = [u'商标无效', u'无效宣告完成']  # 无效
    UNDO_KEYS = [u'撤销三年不使用审理完成', u'撤销连续三年停止使用注册商标中',
                 u'撤销连续三年停止使用注册商标申请完成', u'撤销三年不使用待审中']  # 撤销三年
    RENEWAL_KEYS = [u'商标续展中', u'商标续展待审中']  # 续费中

    db = db.TMS

    @cached_property
    def ulist(self):
        """
        使用证据列表
        :return:
        """
        return Ulist.query(tid=self.mongo_id)

    @classmethod
    def index(cls):
        cls.ensure_index(com_name=-1, n=-1)
        cls.ensure_index(com_name=-1, agent=-1)
        cls.ensure_index(com_name=-1, cid=-1)
        cls.ensure_index(com_name=-1, reg_no=-1)
        cls.ensure_index(com_name=-1, process=-1)
        cls.ensure_index(com_name=-1, appDate=-1)
        cls.ensure_index(com_name=-1, private_date_start=-1, private_date_end=-1)

    @property
    def after_year(self):
        if self.private_date_start:
            start_time = datetime.fromtimestamp(self.private_date_start)
            now_time = datetime.today()
            return now_time.year - start_time.year

    @staticmethod
    def process_format(v):
        if v in Tms.REGISTER_KEYS:
            return Tms.REGISTER
        elif v in Tms.INVALID_KEYS:
            return Tms.INVALID
        elif v in Tms.UNDO_KEYS:
            return Tms.UNDO
        elif v in Tms.RENEWAL_KEYS:
            return Tms.RENEWAL
        else:
            return Tms.UNSTABLE

    @cached_property
    def last_status(self):
        if self.status:
            return self.status[-1]['state']

    @cached_property
    def cat_name(self):
        return TmsCat.name(int(self.cid))

    @cached_property
    def jb_img(self):
        return self.process_to_img(self.process, self.private_date_end)

    @staticmethod
    def process_to_img(process, private_date_end):
        """
        将当前状态和最后有效时间判断商标状态角标
        :param process:
        :param private_date_end:
        :return:
        """
        if process:
            if private_date_end and private_date_end - time() <= 86400 * 360:
                return 'jb_jjdq.png'
            return 'jb_yzc.png'
        return 'jb_wx.png'


    @cached_property
    def same_tm(self):
        return Tms.query(n=self.n, reg_no={'$ne': self.reg_no})

    @cached_property
    def same_goods_cids(self):
        ret = set()
        for item in self.same_tm:
            ret.add(int(item.cid))
        return list(ret)

    @cached_property
    def same_goods(self):
        ret = dict()
        for item in self.same_tm:
            if item.cid not in ret.keys():
                ret[item.cid] = {}
            for k, v in item.goods.iteritems():
                if k not in ret[item.cid].keys():
                    ret[item.cid][k] = []
                ret[item.cid][k].extend(v)
        return ret

    @staticmethod
    def check_process(end, status):
        """
        判断商标是否有效的算法
        :param end:     有效期时间结束
        :param status:  状态列表
        :return:
        """
        process = 1
        if not end or end <= time():
            return 0
        # if end and end > time():
        for item in status:
            if item['state'].find(u'已无效')!=-1:
                return 0
            #     if item['state'].find(u'商标已注册') != -1 or item['state'].find(u'注册证明') != -1:
            #         process = 1
            # if process == 0 and status and status[-1]['state'].find(u'续展')!=-1:
            #     process = 1
        return process

class TmsCat(Models):
    """
        cid: 类目
        note: 注释
        use: 用途
    """
    db = db.TMS_CAT

    @cached_property
    def child_cat(self):
        return TmsChildCat.query(parent_id=self.cid, sort=[('cid', 1)])

    @staticmethod
    def name(i):
        ret = [u"化学原料", u"颜料油漆", u"日化用品", u"燃料油脂", u"医药", u"金属材料", u"机械设备", u"手工器械", u"科学仪器",
               u"医疗器械", u"灯具空调", u"运输工具", u"军火烟火", u"珠宝钟表", u"乐器", u"办公用品", u"橡胶制品", u"皮革皮具",
               u"建筑材料", u"家具", u"厨房洁具", u"绳网袋篷", u"纱线丝", u"布料床单", u"服装鞋帽", u"钮扣拉链", u"地毯席垫",
               u"健身器材", u"食品", u"方便食品", u"饲料种籽", u"啤酒饮料", u"酒", u"烟草烟具", u"广告销售", u"金融物管",
               u"建筑修理", u"通讯服务", u"运输贮藏", u"材料加工", u"教育娱乐", u"网站服务", u"餐饮住宿", u"医疗园艺", u"社会服务"]
        return ret[i - 1]


class TmsChildCat(Models):
    """
        cid: 类目
        n: 名称
        parent_id: 父级id
    """
    db = db.TMS_CHILD_CAT


class TmsCatGoods(Models):
    """
        pid: 商品id
        n: 商品名称
        n_eng: 英文商品名
        note: 备注
        parent_id: 父级id
        cid: 类目id
    """
    db = db.TMS_CAT_GOODS