# coding=utf-8
import time
from datetime import datetime
from damydb.ext import get_current_user

class Help:
    def __init__(self):
        pass

    @staticmethod
    def format_ts(ts, formate='%Y-%m-%d %H:%M:%S'):
        if type(ts) == int:
            ts = float(ts)

        if type(ts) == float:
            ts = datetime.fromtimestamp(ts)
        elif not ts:
            return ''
        formate = formate.encode('utf-8')
        ret = ts.strftime(formate)

        return ret.decode('utf-8')

    @staticmethod
    def days_ago(ts):
        try:
            d = datetime.fromtimestamp(ts)
            now = datetime.fromtimestamp(time.time())
            left = now - d
            return left.days
        except:
            return 0

    @staticmethod
    def get_curr_user_id():
        """
        获取当前在操作的实际用户ID
        :return:
        """
        from flask import session
        from bson import ObjectId
        if session.get('admin_id'):
            ret = ObjectId(session.admin_id)
        else:
            ret = get_current_user().mongo_id
        return ret

    @staticmethod
    def currentUser():
        return get_current_user()
