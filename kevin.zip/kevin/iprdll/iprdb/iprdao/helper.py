# coding=utf-8
from damydb.ext import db
from damydb.models import Models
from datetime import datetime
from werkzeug.utils import cached_property
from damydb.user import User
from flask import url_for
from iprdb.banklist import getCityname,getAreaname

def format_ts(ts, format='%Y-%m-%d %H:%M:%S'):
    if not ts:
        return None
    if type(ts) == int:
        ts = float(ts)

    if type(ts) == float:
        ts = datetime.fromtimestamp(ts)
    elif not ts:
        return ''
    format = format.encode('utf-8')
    ret = ts.strftime(format)

    return ret.decode('utf-8')

class Article(Models):
    """
    _id
    title: 文章标题
    content: 文章内容
    d: 发布时间
    type_name:类型
    cateid: 类别ID
    """
    db = db.HELPER

    @cached_property
    def type_name(self):
        """
         当前文章的类型名
        :return:
        """
        if self.typeid == 1:
            return u"普通"
        if self.typeid == 2:
            return u"常见问题"
        if self.typeid == 3:
            return u"公告"



    @cached_property
    def category(self):
        """
         当前文章的类别对象数据
        :return:
        """
        return Catalog.one(self.cateid)

    @cached_property
    def category_name(self):
        """
         当前文章的类别名称
        :return:
        """
        return Catalog.one(self.cateid).name

    @cached_property
    def art_title(self):
        """
         当前文章标题(防止过长)
        :return:
        """
        ret = self.title
        if len(ret) > 13:
            t = ret[:13] + u"..."
        else:
            t = ret
        return t

    @cached_property
    def create_time(self):
        """
         当前文章的创建时间
        :return:
        """
        return format_ts(self.d,'%Y-%m-%d %H:%M:%S')



class Catalog(Models):
    """
    类别数据库
    _id
    name: 　类别名
    """
    db = db.HELPER

    @cached_property
    def articles(self):
        """
         当前类别的文章对象数据
        :return:
        """
        return Article.query(cateid=self.mongo_id)

    @cached_property
    def article_num(self):
        """
         当前类别的文章条数
        :return:
        """
        return Article.count(cateid=self.mongo_id)

    def beforeRemove(self):
        """
        删除当前类别删除该类别的文章
        """
        for item in self.articles:
            item.remove()

    @cached_property
    def create_time(self):
        """
         当前类别的创建时间
        :return:
        """
        return format_ts(self.d,'%Y-%m-%d %H:%M:%S')

class Feedbacks(Models):
    """
    反馈数据库
    _id
    d
    content     反馈内容
    uid         来自用户ID
    recontent   客服回复内容
    rd         客服回复时间
    """

    db = db.FEEDBACKS

    @cached_property
    def addTime(self):
        """
         反馈添加时间
        :return:
        """
        return format_ts(self.d,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def reTime(self):
        """
         反馈回复时间
        :return:
        """
        return format_ts(self.rd,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def user(self):
        """
        反馈提交用户
        :return:
        """
        return User.one(self.uid)

    @cached_property
    def user_name(self):
        """
        反馈提交的用户名
        :return:
        """
        tmp = self.user
        return u'{0}({1})'.format(tmp.n, tmp.u)

class Certification(Models):
    """
    实名认证数据库
    _id
    d
    name        姓名
    idcard      身份证号
    picid       身份证照片的id
    uid         来自用户ID
    verify      审核内容
    vd          审核时间
    sta         状态
    kindof      绑定类型(1:银行卡,2:支付宝)
    bankcard    卡号/账号
    major       身份
    """
    db = db.CERTIFICATION


    @cached_property
    def case_name(self):
        """
        返回案件类型优势
        :return:
        """
        cs = [0,0,0,0,0]
        for case in self.ca:
            if case ==  1:
                cs[0] = 1
            elif case ==  2:
                cs[1] = 1
            elif case ==  3:
                cs[2] = 1
            elif case ==  4:
                cs[3] = 1
            elif case ==  5:
                cs[4] = 1
        return cs

    @cached_property
    def ba_name(self):
        ba_name = []
        for ba in self.ba:
            for b in ba:
                ba_name.append(b)
        return  ba_name

    @cached_property
    def city_name(self):
        cs_name = []
        for cs in self.cs:
            cs_city = getCityname(cs)
            cs_name.append(cs_city)
        return  cs_name

    @cached_property
    def area_name(self):
        cs_name = {}
        for cs in self.cs:
            cs_area = getAreaname(cs[:2])
            cs_city = getCityname(cs)
            if cs_name.has_key(cs_area):
                cs_name[cs_area].append(cs_city)
            else:
                cs_name[cs_area]=[cs_city]
        return  cs_name

    @cached_property
    def addTime(self):
        """
         实名添加时间
        :return:
        """
        return format_ts(self.d,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def veTime(self):
        """
         审核时间
        :return:
        """
        return format_ts(self.vd,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def user(self):
        """
        实名用户
        :return:
        """
        return User.one(self.uid)

    @cached_property
    def user_name(self):
        """
        实名的用户名
        :return:
        """
        tmp = self.user
        return u'{0}({1})'.format(tmp.n, tmp.u)

    @cached_property
    def status(self):
        """
         实名状态
        :return:
        """
        if self.sta == 1:
            return u"新增"
        if self.sta == 2:
            return u"已通过"
        if self.sta == 3:
            return u"已拒绝"

    @cached_property
    def showmajor(self):
        """
         返回身份
        :return:
        """
        if self.major == 0:
            return u"无"
        if self.major == 1:
            return u"调查员"
        if self.major == 2:
            return u"律师"
        if self.major == 3:
            return u"咨询师"

class Rightauth(Models):
    """
    品牌认证数据库
    _id
    d
    company     公司名
    brand       品牌名
    introduction品牌介绍
    logoid      logo图片的id
    licenceid   营业执照照片的id
    brandcertid 商标证照片id
    uid         来自用户ID
    verify      审核内容
    vd          审核时间
    sta         状态(1:新增2:已通过3:已拒绝)
    """
    db = db.RIGHTAUTH

    @cached_property
    def addTime(self):
        """
         认证添加时间
        :return:
        """
        return format_ts(self.d,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def veTime(self):
        """
         审核时间
        :return:
        """
        return format_ts(self.vd,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def user(self):
        """
        品牌认证用户
        :return:
        """
        return User.one(self.uid)

    @cached_property
    def cases_num(self):
        from iprdb.iprdao.main import Cases
        return Cases.count(bid=self.mongo_id)

    @cached_property
    def clues_num(self):
        from iprdb.iprdao.main import Clues
        return Clues.count(bid=self.mongo_id)


    @cached_property
    def user_name(self):
        """
        品牌认证用户名
        :return:
        """
        tmp = self.user
        return u'{0}({1})'.format(tmp.n, tmp.u)

    @cached_property
    def status(self):
        """
         认证状态
        :return:
        """
        if self.sta == 1:
            return u"新增"
        if self.sta == 2:
            return u"已通过"
        if self.sta == 3:
            return u"已拒绝"

class Sendnews(Models):
    """
    发私信数据库
    _id
    d
    uid         来自用户ID
    fid         接收消息的用户ID
    content     消息内容
    sta         状态(1:已读2:未读)
    """
    db = db.SENDNEWS

    @cached_property
    def user(self):
        """
        返回当前消息的接收消息的用户
        :return:
        """
        return User.one(self.fid)

    @cached_property
    def user_name(self):
        """
        返回当前消息的接收消息的用户名
        :return:
        """
        tmp = self.user
        return u'{0}({1})'.format(tmp.n, tmp.u)

    @cached_property
    def pid(self):
        """
        返回当前消息的接收消息的用户头像id
        :return:
        """
        tmp = self.user
        if tmp.pid:
            tmp =  url_for('member.file_show', id=tmp.pid[0], width=46, height=46)
        else:
            tmp = url_for('static', filename='i/user-unlogin-icon.png')
        return tmp

class Financeout(Models):
    """
    提现数据库
    _id
    d
    uid         来自用户ID
    balance     余额
    outnum      提现金额
    left        提现后剩余金额
    """
    db = db.FINANCEOUT

    @cached_property
    def addTime(self):
        """
         提现时间
        :return:
        """
        return format_ts(self.d,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def veTime(self):
        """
         审核时间
        :return:
        """
        return format_ts(self.vd,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def bankcard(self):
        """
        返回当前用户绑定的银行卡/支付宝
        :return:
        """
        user = Certification.findone(uid=self.uid)
        return user.bankcard

    @cached_property
    def left(self):
        """
        提现后余额
        :return:
        """
        return self.balance - self.outnum

    @cached_property
    def user(self):
        """
        提现用户
        :return:
        """
        from damydb.user import User
        return User.one(self.uid)

    @cached_property
    def user_name(self):
        """
        提现用户名
        :return:
        """
        tmp = self.user
        return u'{0}({1})'.format(tmp.n, tmp.u)

    @cached_property
    def status(self):
        """
         提现状态
        :return:
        """
        if self.sta == 1:
            return u"新增"
        if self.sta == 2:
            return u"已成功"

class Transrecord(Models):
    """
    交易记录数据库
    _id
    d
    uid         来自用户ID
    balance     余额
    money       操作的金额数
    kindof      交易类型(1:收入,2:支出)
    disc        描述
    """
    db = db.TRANSRECORD

class Financefin(Models):
    """
    提现数据库
    _id
    d
    uid         来自用户ID
    balance     余额
    outnum      提现金额
    left        提现后剩余金额
    """
    db = db.FINANCEFIN

    @cached_property
    def addTime(self):
        """
         申请转入时间
        :return:
        """
        return format_ts(self.d,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def veTime(self):
        """
         审核时间
        :return:
        """
        return format_ts(self.vd,'%Y-%m-%d %H:%M:%S')

    @cached_property
    def left(self):
        """
        申请转入后金额
        :return:
        """
        return self.balance - self.outnum

    @cached_property
    def user(self):
        """
        申请转入的用户
        :return:
        """
        from damydb.user import User
        return User.one(self.uid)

    @cached_property
    def user_name(self):
        """
        申请转入的用户名
        :return:
        """
        tmp = self.user
        return u'{0}({1})'.format(tmp.n, tmp.u)

    @cached_property
    def status(self):
        """
        转入状态
        :return:
        """
        if self.sta == 1:
            return u"新增"
        if self.sta == 2:
            return u"已成功"
        if self.sta == 3:
            return u"已失败"
