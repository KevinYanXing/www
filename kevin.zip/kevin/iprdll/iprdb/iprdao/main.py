# coding=utf-8
from damydb.ext import db
from damydb.models import Models
from werkzeug.utils import cached_property
from damydb.user import User
from flask import url_for
from iprdb.iprdao.helper import Certification,format_ts

class Brands(Models):
    """
    品牌列表
    一个品牌表示一个商标
    _id
    name 名称(全称)
    sname 简称
    logo logo图片地址
    uid 所属权利人
    clist 该品牌拥有的各种权利列表,比如,拥有什么商标,专利,商标所在分类,注册号,专利号,著作权
    [
        {
        '_id':主键, 'n': 名称, 't': 专利/商标/著作权等类型, 'i': 专利号,商标号,著作权ID等, 'c': 其它内容(比如商标所在分类)
        }
        ...
    ]
    desc 品牌的其它描述
    """
    db = db.BRANDS


class Targets(Models):
    """
    侵权人列表(线索转换成案件的时候自动生成的)
    name    名称
    addr    地址
    phone   电话
    pic     图片
    desc    描述
    ttype   类型
    prov    省份
    city    城市
    d       添加时间
    """
    db = db.TARGETS

    @cached_property
    def addTime(self):
        """
        添加时间
        :return:
        """
        return format_ts(self.d)

class Clues(Models):
    """
    线索,这个属于临时数据库,存的数据比较多.
    只有转成正式案件后,才能将侵权人信息进入侵权人数据库
    同事转存一份到案件去
    _id 主键
    d 时间(发布)
    uid 服务商ID
    qid 权利人ID
    bid 品牌ID
    comments {
        _id
        d
        c 内容
        u 来自用户ID
        a 附件列表[id...]
    }
    各种回复, 各种现场图片,文档等都将上传到这个附件来
    执行建议(刑事打击\行政处罚\律师警告函\民事诉讼)
    s [1: 进行中, 2: 失败 3: 成功]
    money  营收金额(如果转成案件这个就属于案件的一部分金额)
    # 侵权人信息
    target:{
        tname     侵权人名称
        tcode     侵权人社会信用代码
        tnature   侵权人基本性质
        tarea     经营场所面积
        tstaffnum 员工人数
        tprov     所在省份
        tcity     所在城市
        taddr     侵权人详细地址
        ttelphone 侵权人固定电话
        tmobphone 侵权人手机
        email     侵权人邮箱
        tfax      侵权人传真
        qq        侵权人qq
        wsite     侵权人网址
        tphpoto   侵权人图片
        tdesc     侵权人描述
        prodname  侵权产品名称
        prodmodel 侵全产品型号
        prodprice 侵全产品价格
        prodphoto 侵全产品照片

        ...
        不够的后面补
    }
    """

    STATUS = {
        'pub': -1, # 待发布
        'new': 0, # 新线索
        'ing': 1, #进行中
        'close': 2, #失败
        'ok': 3, #成功
    }

    @cached_property
    def status_cn(self):
        """
        返回状态中文
        """
        ret = {
            -1:u'待发布',
            0: u'新线索',
            1: u'进行中',
            2: u'失败',
            3: u'成功'
        }
        return ret.get(self.s, u'未定义')

    @cached_property
    def status_color(self):
        """
        返回状态颜色
        :return:
        """
        ret = {
            -1:u'blue',
            0: u'yellow',
            1: u'green',
            2: u'grey',
            3: u'red'
        }
        return ret.get(self.s, u'grey')

    db = db.CLUES

    @cached_property
    def brand(self):
        from .helper import Rightauth
        return Rightauth.one(self.bid)

    @staticmethod
    def exe_name(val):
        """
        返回处理名称
        """
        ret = {
            1: u'刑事打击',
            2: u'行政处罚',
            3: u'律师警告函',
            4: u'民事诉讼'
        }
        return ret.get(val, u'未定义')

    @cached_property
    def nature(self):
        """
         侵权人基本性质
        :return:
        """
        if self.tnature == 1:
            return u"生产工厂"
        if self.tnature == 2:
            return u"外贸公司"
        if self.tnature == 3:
            return u"批发商"
        if self.tnature == 4:
            return u"零售商"
        if self.tnature == 5:
            return u"仓库"
        if self.tnature == 6:
            return u"其他"

    @cached_property
    def staffnum(self):
        """
         员工人数
        :return:
        """
        if self.tstaffnum == 1:
            return u"小于5人"
        if self.tstaffnum == 2:
            return u"6-10人"
        if self.tstaffnum == 3:
            return u"11-30人"
        if self.tstaffnum == 4:
            return u"31-50人"
        if self.tstaffnum == 5:
            return u"51-100人"
        if self.tstaffnum == 6:
            return u"100人以上"

    @cached_property
    def area(self):
        """
         经营面积
        :return:
        """
        if self.tarea == 1:
            return u"小于50㎡"
        if self.tarea == 2:
            return u"51-100㎡"
        if self.tarea == 3:
            return u"101-300㎡"
        if self.tarea == 4:
            return u"301-500㎡"
        if self.tarea == 5:
            return u"501-1000㎡"
        if self.tarea == 6:
            return u"1000㎡以上"

    @cached_property
    def adduser(self):
        return User.one(self.uid)

    @cached_property
    def adduserp(self):
        """
        返回用户小头像
        :return:
        """
        tmp = self.adduser
        if tmp.pid:
            tmp = url_for('member.file_show', id=tmp.pid[0], width=32, height=32)
        else:
            tmp = url_for('static', filename='i/user-unlogin-icon.png',width=32,height=32)
        return tmp

    @cached_property
    def addcert(self):
        return Certification.findone(uid=self.uid)

    @cached_property
    def owncert(self):
        return Certification.findone(uid=self.qid)

    @cached_property
    def ownuser(self):
        return User.one(self.qid)

    @cached_property
    def ownuserp(self):
        """
        返回用户小头像
        :return:
        """
        tmp = self.ownuser
        if tmp.pid:
            tmp = url_for('member.file_show', id=tmp.pid[0], width=32, height=32)
        else:
            tmp = url_for('static', filename='i/user-unlogin-icon.png',width=32,height=32)
        return tmp

    @cached_property
    def addTime(self):
        """
        添加时间
        :return:
        """
        return format_ts(self.d,"%Y-%m-%d")

    @cached_property
    def pubTime(self):
        """
        发布时间
        :return:
        """
        return format_ts(self.pd,"%Y-%m-%d")

    @cached_property
    def finishTime(self):
        """
        完成/失败时间
        :return:
        """
        return format_ts(self.fd,"%Y-%m-%d")

    @cached_property
    def last_info(self):
        """
        获取最后的信息
        """
        ret = self.comments
        if not ret:
            return u'<p style="color:#cccccc;text-align:center;">暂无更新</p>'
        ret = ret[-1]
        if len(ret['t']) > 13:
            t = ret['t'][:13] + u"..."
        else:
            t = ret['t']
        return u'<p>{0}</p><p style="color:#cccccc">{1}</p>'.format(t,format_ts(ret['d'],'%Y-%m-%d'))

class Cases(Models):
    """
    正式的案件数据库(可以是权利人委托,也可以是从线索提交并转换过来)
    _id
    d
    fid 服务商ID,执行这个案件的人
    uid 权利人ID
    bid 品牌ID
    title 标题
    content 内容(可以跟线索一样)
    cid 线索ID,如果为空,表示这个案件是权利人直接委派的
    tid 侵权人ID
    comments {
        _id
        d
        c 内容
        u 来自用户ID
        a 附件列表[id...]
    }

    各种回复, 如果有诉讼的话,诉讼文书,判决书都将作为附件提交到这个评论里面来.如果要提供各种授权证书的话,也从这里提交,根据进度来提交
    exe [
        多种方式
    ]
    处理方式(刑事打击\行政处罚\律师警告函\民事诉讼), 由权利人随时增加

    status [0: 新案件, 1: 进行中(服务商有回复后就成为这个状态), 2: 已关闭(权利人才能关闭) 3: 已完成]
    money  悬赏金额(这个是总金额,包含了线索上报金额,以及每个阶段的金额)
    tmoney 总收入金额(进行到某个阶段后当前总共收到的金额), 总金额-这个数值 = 还有多少没收到,按阶段付费
    pay  支付方案
    [
        {'n': 阶段名,'m': 支付金额}
        ...
    ]
    process
    plist 查扣清单(如果涉及查扣的话)
    [
        {'n': 产品名, 'p': 单价 , 'm': 数量, 'b': 产品编号}
    ]
    target:{
        tname     侵权人名称
        tcode     侵权人社会信用代码
        tnature   侵权人基本性质
        tarea     经营场所面积
        tstaffnum 员工人数
        tprov     所在省份
        tcity     所在城市
        taddr     侵权人详细地址
        ttelphone 侵权人固定电话
        tmobphone 侵权人手机
        email     侵权人邮箱
        tfax      侵权人传真
        qq        侵权人qq
        wsite     侵权人网址
        tphpoto   侵权人图片
        tdesc     侵权人描述
        prodname  侵权产品名称
        prodmodel 侵全产品型号
        prodprice 侵全产品价格
        prodphoto 侵全产品照片
    }
    """
    db  = db.CASES

    STATUS = {
        'pub':-1,  # 待发布
        'new': 0,  # 新案件
        'ing': 1,  # 进行中
        'close': 2,# 已关闭
        'ok': 3    # 已完成
    }

    @cached_property
    def status_cn(self):
        """
        返回状态的中文描述
        :return:
        """
        ret = {
            -1:u'待发布',
            0: u'新案件',
            1: u'进行中',
            2: u'已关闭',
            3: u'已完成'
        }
        return ret.get(self.s)

    @cached_property
    def status_color(self):
        """
        返回状态颜色
        :return:
        """
        ret = {
            -1:u'blue',
            0: u'yellow',
            1: u'green',
            2: u'grey',
            3: u'red'
        }
        return ret.get(self.s, u'grey')

    EXES = {
        'xingshi': 1, # 刑事打击
        'xingzheng': 2, # 行政处罚
        'jinggao': 3, # 律师警告函
        'minshi': 4 # 民事诉讼
    }

    @staticmethod
    def exe_name(val):
        """
        返回处理名称
        """
        ret = {
            1: u'刑事打击',
            2: u'行政处罚',
            3: u'律师警告函',
            4: u'民事诉讼'
        }
        return ret.get(val, u'未定义')

    @cached_property
    def addTime(self):
        """
        添加时间
        :return:
        """
        return format_ts(self.d,"%Y-%m-%d")

    @cached_property
    def pubTime(self):
        """
        发布时间
        :return:
        """
        return format_ts(self.pd,"%Y-%m-%d")

    @cached_property
    def finishTime(self):
        """
        完成/失败时间
        :return:
        """
        return format_ts(self.fd,"%Y-%m-%d")

    # #案件添加
    # @cached_property
    # def status_cn(self):
    #     """
    #     返回状态中文
    #     """
    #     ret = {
    #         1: u'进行中',
    #         2: u'失败',
    #         3: u'成功'
    #     }
    #     return ret.get(self.status, u'未定义')

    @cached_property
    def brand(self):
        from .helper import Rightauth
        return Rightauth.one(self.bid)

    @cached_property
    def user(self):
        from damydb.user import User
        return User.one(self.fid)

    @cached_property
    def nature(self):
        """
         侵权人基本性质
        :return:
        """
        if self.tnature == 1:
            return u"生产工厂"
        if self.tnature == 2:
            return u"外贸公司"
        if self.tnature == 3:
            return u"批发商"
        if self.tnature == 4:
            return u"零售商"
        if self.tnature == 5:
            return u"仓库"
        if self.tnature == 6:
            return u"其他"

    @cached_property
    def staffnum(self):
        """
         员工人数
        :return:
        """
        if self.tstaffnum == 1:
            return u"小于5人"
        if self.tstaffnum == 2:
            return u"6-10人"
        if self.tstaffnum == 3:
            return u"11-30人"
        if self.tstaffnum == 4:
            return u"31-50人"
        if self.tstaffnum == 5:
            return u"51-100人"
        if self.tstaffnum == 6:
            return u"100人以上"

    @cached_property
    def area(self):
        """
         经营面积
        :return:
        """
        if self.tarea == 1:
            return u"小于50㎡"
        if self.tarea == 2:
            return u"51-100㎡"
        if self.tarea == 3:
            return u"101-300㎡"
        if self.tarea == 4:
            return u"301-500㎡"
        if self.tarea == 5:
            return u"501-1000㎡"
        if self.tarea == 6:
            return u"1000㎡以上"

    @cached_property
    def adduser(self):
        return User.one(self.uid)

    @cached_property
    def adduserp(self):
        """
        返回用户小头像
        :return:
        """
        tmp = self.adduser
        if tmp.pid:
            tmp = url_for('member.file_show', id=tmp.pid[0], width=32, height=32)
        else:
            tmp = url_for('static', filename='i/user-unlogin-icon.png',width=32,height=32)
        return tmp

    @cached_property
    def addcert(self):
        return Certification.findone(uid=self.uid)

    @cached_property
    def owncert(self):
        return Certification.findone(uid=self.fid)

    @cached_property
    def ownuser(self):
        return User.one(self.fid)

    @cached_property
    def ownuserp(self):
        """
        返回用户小头像
        :return:
        """
        tmp = self.ownuser
        if tmp.pid:
            tmp = url_for('member.file_show', id=tmp.pid[0], width=32, height=32)
        else:
            tmp = url_for('static', filename='i/user-unlogin-icon.png',width=32,height=32)
        return tmp

    @cached_property
    def last_info(self):
        """
        获取最后的信息
        """
        ret = self.comments
        if not ret:
            return u'<p style="color:#cccccc;text-align:center;">暂无更新</p>'
        ret = ret[-1]
        if len(ret['t']) > 13:
            t = ret['t'][:13] + u"..."
        else:
            t = ret['t']
        return u'<p>{0}</p><p style="color:#cccccc">{1}</p>'.format(t,format_ts(ret['d'],'%Y-%m-%d'))
#案件添加

#线索案件评价
class Evaluate(Models):
    """
    评价数据库
    _id
    d: 　时间
    q: 服务质量
    coop:配合情况
    c:  评价内容
    u: 评论用户id
    e: 案件/线索id
    f: 被评论用户
    """
    db = db.EVALUATE

    @cached_property
    def user_info(self):
        user_p = Cases.one(self.e)
        if not user_p:
            user_p = Clues.one(self.e)

        return user_p

    @cached_property
    def eva_resource(self):
        re = u'案件'
        eva = Cases.one(self.e)
        if not eva:
            re = u'线索'
        return re

    @cached_property
    def user_eva(self):
        user_eva = User.one(self.u)
        return user_eva

