# coding=utf-8
from damydb.ext import db
from damydb.models import Models
from werkzeug.utils import cached_property
from datetime import datetime
import os
import functools
from bson import ObjectId
from help import Help


from model.tm import Tms, TmsCat, TmsCatGoods, TmsChildCat
from model.patent import PatentCat, Patents, PatentsImg, PatentsTran
from model.admin import Vistor, Pays, Activekey, Applys, Message
from model.copyright import Copyright, Ucr
from model.court import Court
from model.files import Files

def log(func):
    @functools.wraps(func)
    def wrapper(*args, **kw):
        print '\r\n====================='
        return func(*args, **kw)
    return wrapper


def no_repeat_set(key, item_list):
    """
    list去重，返回set
    """
    if not key:
        return set([item for item in item_list])
    return set([getattr(item, key) for item in item_list])

class Lawcourt(Models):
    """
    法院数据库
    prov 省
    city 市
    name 全称
    """
    db = db.LAWBOOK

    @classmethod
    def index(cls):
        cls.ensure_index(prov=-1)
        cls.ensure_index(city=-1)
        cls.ensure_index(name=-1)



class Lawreason(Models):
    """
    案由数据库
    pid
    name 名称
    """
    db = db.LAWBOOK
    @classmethod
    def index(cls):
        cls.ensure_index(name=-1)

class Lawtype(Models):
    """
    文书类型数据库
    name 类型名
    """
    db = db.LAWBOOK

class Lawer(Models):
    """
    律师数据库
    name
    prov 省
    city 市
    company 所在律所
    其它参数后面慢慢完善
    """
    db = db.LAWBOOK

    @classmethod
    def index(cls):
        cls.ensure_index(name=-1)
        cls.ensure_index(total=-1)
        cls.ensure_index(company=-1)

    def results(self, key):
        where = {key: self.mongo_id}
        total = Lawbook.count(**where)
        where['result'] = 1
        win = Lawbook.count(**where)
        where['result'] = 0
        lost = Lawbook.count(**where)
        return [win, lost, total]

    @cached_property
    def fresults(self):
        """
        结果列表
        """
        return self.results('fuserid')

    @cached_property
    def tresults(self):
        """
        结果列表
        """
        return self.results('tuserid')

    @cached_property
    def money(self):
        """
        总赔偿额
        """
        datas = Lawbook.query(sort=[('d', -1)], fuserid=self.mongo_id, money={'$gt': 0})
        total = 0
        for item in datas:
            total += item.money
        return total


class Lawbook(Models):
    """
    法律文书数据库
    _id 编号
    oid 外网ID
    bookid  案号
    court 法院
    cid 法院ID
    title 标题
    d     案件日期
    reason 案由
    rid  案由ID
    t     文书类型
    tid  类型ID
    process 程序
    pid 程序ID
    users 人员列表 [{'n': '名字', 't': '头衔 律师/代理人/原告', 'd': '部门 律师的话会有律所'}]
    lawerid 如果被分配到律师的话,这个是关联
    fuserid: [] 原告律师id
    tuserid: [] 被告律师id
    money 赔偿金额
    result 原告输/赢
    """
    db = db.LAWBOOK

    @classmethod
    def index(cls):
        """
        索引
        """
        cls.ensure_index(fuserid=-1)
        cls.ensure_index(tuserid=-1)
        cls.ensure_index(rid=-1)
        cls.ensure_index(tid=-1)
        cls.ensure_index(pid=-1)
        cls.ensure_index(cid=-1)
        cls.ensure_index(d=-1)
        cls.ensure_index(result=-1)

class AppPerson(Models):
    """
    所有申请人
    n 名字
    status 获取数据状态（是否已经获取数据）
    """
    db = db.APPPERSON

    def remove_tms(self):
        """
        清空相关商标数据
        """
        all_tms = Tms.query(com_name=self.n)
        for tm in all_tms:
            tm.detail.remove()
            tm.remove()
        # -----------------


class Companies(Models):
    """
    n 公司名
    his_n 历史名称 list
    imgs 执照 list
    uid 用户id
    status 当前状态
    """
    STATUS = {
        'deny': 0,
        'accept': 1,
        'submit': 2
    }
    db = db.COMPANIES

    @classmethod
    def index(cls):
        cls.ensure_index(uid=-1)
        cls.ensure_index(uid=-1, status=-1)

    @cached_property
    def imgs(self):
        return ','.join(map(str, self.data.get('imgs')))

    @cached_property
    def inner_imgs(self):
        return self.data.get('imgs')

    @cached_property
    def user(self):
        """
        获取提交此条信息的用户数据
        :return:
        """
        from damydb.user import User
        return User.one(self.uid)

    @cached_property
    def apply_list(self):
        return Applys.query(uid=self.uid, sort=[('d', -1)])

    @cached_property
    def status_format(self):
        if not self.status:
            return u'用户提交'
        return [u'未通过', u'已通过', u'已提交'][self.status]

    @cached_property
    def name_list(self):
        if self.his_n:
            self.his_n.append(self.n)
            return self.his_n
        else:
            return [self.n]


class Trades(Models):
    """
    IPR交易库
    _id mongo id
    to 授权对象
    money 金额
    expire_date 到期时间
    rights 商品 [] / 类目[]
    img_id 授权证书id
    ipr_id tm.mongo_id
    ipr_type 0:tm, 1:patent
    """
    db = db.TRADES
    TYPE_TM = 0
    TYPE_PATENT = 1

    @classmethod
    def index(cls):
        cls.ensure_index(uid=-1)
        cls.ensure_index(uid=-1, ipr_id=-1, ipr_type=-1)

    @cached_property
    def expire_time(self):
        return Help.format_ts(self.expire_date, formate='%Y-%m-%d')
