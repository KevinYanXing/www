# --*-- coding:utf-8 --*--
from fmail import Mail
from jinja2 import Environment
from jinja2 import FileSystemLoader
import os

class DEmail:
    """
    邮件处理类
    """
    def init_app(self, app):
        self.mail = Mail(app)
        options = {'loader': FileSystemLoader(os.path.join(os.getcwd(), 'app'))}
        self.env = Environment(**options)
        self.sender = app.config['DEFAULT_MAIL_SENDER']

    def render_template(self, pth, **kwargs):
        rv = self.env.get_template(pth)
        return rv.render(**kwargs)

    def send(self, title, to, data, mail_type):
        """
        发送邮件
        """
        content = self.render_template('templates/mails/%s.html' % mail_type, data=data)

        self.mail.send_message(subject=title, recipients=to, html=content, sender=self.sender)
        return True


