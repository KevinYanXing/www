# -*- coding: utf-8 -*-
#
from __future__ import with_statement

import imp


class ConfigAttribute(object):
    """Makes an attribute forward to the config"""

    def __init__(self, name, get_converter=None):
        self.__name__ = name
        self.get_converter = get_converter

    def __get__(self, obj, type=None):
        if obj is None:
            return self
        rv = obj.config[self.__name__]
        if self.get_converter is not None:
            rv = self.get_converter(rv)
        return rv

    def __set__(self, obj, value):
        obj.config[self.__name__] = value


class Config(dict):

    def __init__(self, config_path, defaults=None):
        dict.__init__(self, defaults or {})
        self.config_path = config_path
        self.from_pyfile()

    def from_pyfile(self):

        d = imp.new_module('config')
        d.__file__ = self.config_path
        try:
            execfile(self.config_path, d.__dict__)
        except IOError, e:
            e.strerror = 'Unable to load configuration file (%s)' % e.strerror
            raise

        self._from_object(d)
        return True

    def _from_object(self, obj):
        for key in dir(obj):
            if key.isupper():
                self[key] = getattr(obj, key)

    def __repr__(self):
        return '<%s %s>' % (self.__class__.__name__, dict.__repr__(self))
