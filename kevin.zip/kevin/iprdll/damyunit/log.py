# -*- coding: utf-8 -*-
import syslog
import traceback


class Log:
    def __init__(self, log_name=None, debug=False):
        if log_name:
            self.open(log_name, debug)

    @staticmethod
    def open(log_name, debug=False):
        if debug:
            syslog.openlog(log_name, syslog.LOG_PERROR, syslog.LOG_LOCAL0)
        else:
            syslog.openlog(log_name, 0, syslog.LOG_LOCAL0)

    @staticmethod
    def close():
        syslog.closelog()

    @staticmethod
    def err(**kw):
        '''
        记录出错日志
        kw:需要记录的信息
        ret:无返回
        '''
        Log._log(level=syslog.LOG_ERR,**kw)

    @staticmethod
    def warning(**kw):
        '''
        记录告警日志
        kw:需要记录的信息
        ret:无返回
        '''
        Log._log(level=syslog.LOG_WARNING,**kw)

    @staticmethod
    def info(**kw):
        '''
        记录INFO日志
        kw:需要记录的信息
        ret:无返回
        '''
        Log._log(level=syslog.LOG_INFO,**kw)

    @staticmethod
    def _log(**kw):
        '''
        集体记录信息
        kw:需要记录的信息参数
        ret:无返回
        '''
        exc = ''
        level = kw.pop('level', syslog.LOG_WARNING)
        if level == syslog.LOG_ERR: exc = traceback.format_exc()
        for k in kw.keys():
            content = kw.get(k)
            if type(content) == unicode:
                content = content.encode('utf-8')
            content = str(content)
            exc += ' ：' +  content

        syslog.syslog(level, exc)