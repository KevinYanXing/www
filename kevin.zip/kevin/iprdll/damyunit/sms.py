# -*- coding: utf-8 -*-
import datetime, random, urllib2, hashlib, base64, json, requests


def getSig(accountSid, accountToken, timestamp):
    sig = accountSid + accountToken + timestamp
    return hashlib.md5(sig).hexdigest().upper()


# 发起http请求
def urlOpen(req, data=None):
    try:
        res = urllib2.urlopen(req, data)
        data = res.read()
        res.close()
    except urllib2.HTTPError, error:
        data = error.read()
        error.close()
    return data


# 生成授权信息
def getAuth(accountSid, timestamp):
    src = accountSid + ":" + timestamp
    return base64.encodestring(src).strip()


# 生成HTTP报文
def createHttpReq(req, url, accountSid, timestamp, responseMode, body):
    req.add_header("Authorization", getAuth(accountSid, timestamp))
    if responseMode:
        req.add_header("Accept", "application/" + responseMode)
        req.add_header("Content-Type", "application/" + responseMode + ";charset=utf-8")
    if body:
        req.add_header("Content-Length", len(body))
        req.add_data(body)
    return req


class SmsSender:

    def __init__(self, config):
        self.accountSid = config.get('SMS_SID')
        self.accountToken = config.get('SMS_TOKEN')
        self.appId = config.get('SMS_APPID')
        self.host = config.get('SMS_HOST')
        self.port = config.get('SMS_PORT')
        self.softver = config.get('SMS_VER')
        self.responseMode = config.get('SMS_RESPONSEMODE', 'json')

        self.used = config.get('SMS_USED')
        self.sms2_url = config.get('SMS2_URL')
        self.sms2_content = config.get('SMS2_CONTENT')
        self.sms2_uid = config.get('SMS2_UID')
        self.sms2_psw = config.get('SMS2_PSW')

        if self.used not in ['1', '2']:
            self.used = 'r'

        self.resp = ''

    def send(self, templateId, to, content):
        """
        发送
        模版ID
        发送到
        内容，用逗号分开
        """
        if self.used == 'r':
            self.used = random.randint(1, 2)
            self.used = str(self.used)

        if self.used == '1':
            return self.send_sms_1(templateId, to, content)
        else:
            return self.send_sms_2(templateId, to, content)

    def send_sms_2(self, templateId, to, content):
        content = content.split(',')
        content = tuple(content)
        tmp = self.sms2_content.get(str(templateId))
        content = tmp % content

        # pw = hashlib.md5()
        # pw.update(self.sms2_psw)
        # pw = pw.hexdigest().upper()
        # data = u"""<Group Login_Name="%s" Login_Pwd="%s" OpKind="0" InterFaceID="" SerType="测试">
        # <E_Time>%s</E_Time> <Item>
        # <Task> <Recive_Phone_Number>%s</Recive_Phone_Number> <Content><![CDATA[%s]]></Content> <Search_ID>%d</Search_ID>
        # </Task></Item></Group>""" % (self.sms2_uid, pw, datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'), to, content, templateId)
        # data = data.encode('gb2312')

        data = {'name': self.sms2_uid, 'pwd': self.sms2_psw, 'content': content, 'mobile': to, 'type': 'pt'}

        # print data

        resp = requests.post(self.sms2_url, data=data)

        # print resp.text, resp.url
        self.resp = resp.text
        try:
            return resp.text.split(',')[0]
        except:
            return resp.text


    def send_sms_1(self, templateId, to, content):
        if type(content) == unicode:
            content = urllib2.quote(content.encode('utf-8'))

        now = datetime.datetime.now()
        timestamp = now.strftime("%Y%m%d%H%M%S")
        signature = getSig(self.accountSid, self.accountToken, timestamp)
        url = self.host + ":" + self.port + "/" + self.softver + "/Accounts/" + self.accountSid + "/Messages/templateSMS?sig=" + signature
        body = '{"templateSMS":{ "appId":"%s","to":"%s","templateId":"%s","param":"%s"}}' % (self.appId, to, templateId, content)
        req = urllib2.Request(url)
        ret =  urlOpen(createHttpReq(req, url, self.accountSid, timestamp, self.responseMode, body))
        ret = json.loads(ret)

        return ret['resp']['respCode']

    def is_ok(self, ret):
        return ret in ['000000', '00', '0']