# -*- coding: utf-8 -*-
from optparse import OptionParser
from damyunit.log import Log
from damyunit.config import Config
from time import sleep
from pymongo.errors import DuplicateKeyError, DocumentTooLarge

class Service(object):
    def __init__(self, args):
        # 初始化配置文件
        self.test = args.test == 'y'

        cfg = Config(args.config, {})

        db_pth = cfg.get('DB', 'db.cfg')
        try:
            self.config = Config(db_pth, {})
            self.config.update(**cfg)
        except:
            self.config = cfg
        # 加载日志系统
        self.debug = self.config['DEBUG']
        log_ident = self.config.get('LOG_IDENT')
        if not log_ident:
            if hasattr(self, 'log_ident'):
                log_ident = self.log_ident
            else:
                log_ident = self.__class__.__name__

        self.log = Log(log_ident, self.debug)

    def method_retry(self, fun, *args, **kwargs):
        """
        对方法进行重试
        :param fun:
        :param times:
        :param kwargs:
        :return:
        """
        log = False
        retry = 0
        result = None
        times = kwargs.pop('times', -1)
        # print args
        while 1:
            try:
                if args:
                    result = fun(*args)
                else:
                    result = fun(**kwargs)
                break
            except DuplicateKeyError, e:
                self.log.err(m='method: {0}'.format(fun))
                return -1
            except DocumentTooLarge, e:
                self.log.err(m='method: {0}'.format(fun))
                return -2
            except:
                if not log :
                    self.log.err(m='=====error!!!!!!!======,method {0} error'.format(fun))
                    log = True
                sleep(2)
                retry += 1
            if 0 < times <= retry:
                self.log.warning(m='method {0} error,retry end'.format(fun))
                log = False
                break
        if log:
            self.log.info(m='retry {0} end and finish method, {1}'.format(retry, fun))
        return result

    @classmethod
    def sleep(cls, timespan):
        """
        休息指定时间，这个方法可以重写
        :param timespan:
        :return:
        """
        sleep(timespan)

    def run(self):
        raise NotImplementedError('请重载此方法')

    @classmethod
    def server_for_ever(cls):
        ser_name = cls.__name__.lower()
        description = u"API服务框架，版权所有@damy "
        parser = OptionParser(usage="usage: %prog [options]",
                              version="%prog D0.1 BETA, Copyright (c) Damy",
                              description=description, add_help_option=True)

        parser.add_option("-c", "--config", nargs=1, type="str", dest="config",
                          help=u"配置文件路径.", default='%s.cfg' % ser_name)
        parser.add_option("-t", "--test", nargs=1, type="str", dest="test",
                          help=u"是否启用测试模式.", default='n')

        (options, args) = parser.parse_args()

        app = cls(options)
        while 1:
            ret = False
            try:
                ret=app.run()
            except Exception as e:
                if e == KeyboardInterrupt:
                    break
                else:
                    Log.err(m=ser_name)
            if not ret:
                cls.sleep(1)
            else:
                break