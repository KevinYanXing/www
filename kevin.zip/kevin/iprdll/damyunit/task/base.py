# coding=utf-8
from damyunit.service import Service
from damyunit.dredis import DRedis
from damydb.ext import db

from gevent import pool, monkey, sleep
monkey.patch_all()

class Base(Service):
    def __init__(self, args):
        super(Base, self).__init__(args)
        self.status_redis = DRedis()
        self.init_status_redis()
        self.pool = pool.Pool(self.config.get('MAX_POOL', 30))
        db.init_app(self, 'DBS')

    def init_status_redis(self):
        """
        初始化状态redis,可以让状态redis分开来.
        :return:
        """
        self.status_redis.init_app(self, 'STATUS_REDIS_')

    @classmethod
    def sleep(cls, timespan):
        sleep(timespan)

    def run(self):
        """
        开始服务
        :return:
        """
        self.log.info(m='start')
        if self.test:
            self.run_run()
            return True

        while 1:
            # 加载任务
            self.run_run()

    def run_run(self):
        pass

    def ip_addr(self):
        import socket
        try:
            return socket.gethostbyname(socket.gethostname()) + "_" + self.config.get('ID', '')
        except:
            self.log.err()
        return '1'