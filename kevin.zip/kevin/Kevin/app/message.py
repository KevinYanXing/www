# coding=utf-8
from flask import flash

"""
这是一个用于发出信息给前端显示的辅助类库
"""
class Message:

    WARNING = 'notice'
    ERROR = 'error'
    INFO = 'info'
    SUCCESS = 'success'

    @staticmethod
    def warning(msg):
        flash(msg, category=Message.WARNING)

    @staticmethod
    def error(msg):
        flash(msg, category=Message.ERROR)

    @staticmethod
    def success(msg):
        flash(msg, category=Message.SUCCESS)

    @staticmethod
    def info(msg):
        flash(msg, category=Message.INFO)