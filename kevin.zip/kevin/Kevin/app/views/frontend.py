# coding=utf-8
from flask import Blueprint, request, abort, redirect, url_for, g, jsonify, make_response, current_app, send_from_directory
from app.help import Help
from iprdb.iprdao.helper import Catalog,Article
from damyweb.alipay import Alipay
from iprdb.models import Pays
from bson import ObjectId
import os

frontend = Blueprint('frontend', __name__)

@frontend.route('/')
def index():
    return Help.render('/frontend/index.html')

@frontend.route("/favicon.ico")
def favicon():
    return send_from_directory(os.path.join(current_app.root_path, 'static'),
                               'favicon.ico', mimetype='image/x-icon', add_etags=False, cache_timeout=2592000)