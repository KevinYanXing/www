#coding=utf-8
from flask import Blueprint, jsonify, request, g, current_app, abort, send_from_directory, redirect, url_for
from iprdb.model.files import Files
from damyweb.permissions import auth
from damydb.user import User
from app.help import Help
from bson import ObjectId
from iprdb.iprdao.helper import Rightauth
import json, os
from damydb.pagination import Paged

member = Blueprint('member', __name__)

@member.route('/', methods=("GET", "POST"))
@auth.require(401)
def index():
    curr_user = Help.currentUser()
    right_num = Rightauth.count(sta=2,uid={'$ne':curr_user.mongo_id})
    return Help.render(template='/member/index.html',right_num=right_num)

@member.route('/img/updel', methods=("GET", "POST"))
@auth.require(401)
def img_updel():
    id = request.args.get('id')
    try:
        id = ObjectId(id)
    except:
        id = None

    if not id:
        return jsonify({})

    item = Files.get_or_404(id)
    item.remove()
    return jsonify({})

@member.route('/file/show/<string:id>/', methods=("GET", "POST"))
@member.route('/file/show/<string:id>/<int:width>x<int:height>.jpg', methods=("GET", "POST"))
@auth.require(401)
def file_show(id, width=0, height=0):
    try:
        oid = ObjectId(id)
    except:
        oid = None

    item = None
    if oid:
        item = Files.one(oid)
    if not item:
        pth = os.path.join(current_app.static_folder, 'images/empty.jpg')
    else:
        # 这里判断一下,如果是图片的话就缩略显示,如果是其它附件的话,就显示附件的类型图片
        if not width and not height and item.ext in ['doc', 'docx', 'xls', 'pdf', 'ppt']:
            pth = item.file_path
        elif item.ext in ['doc', 'docx', 'xls', 'pdf', 'ppt']:
            pth = os.path.join(current_app.static_folder, 'filetype/{0}.png'.format(item.ext))
        else:
            pth = item.thumb(size=[width, height])

    path, name = Files.spilt_path(pth)
    return send_from_directory(path, name, add_etags=False, cache_timeout=2592000)