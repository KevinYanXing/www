# coding=utf-8
__author__ = 'damy'
from flask import Flask, request, render_template, jsonify, url_for
from app.ext import bcrypt, redisCache
from app.views.frontend import frontend
from app.views.member import member
from damydb.ext import db


def create_app(cfg):
    app = Flask(__name__)
    app.config.from_pyfile(cfg)
    app.add_url_rule('/<path:filename>', endpoint='static', view_func=app.send_static_file, subdomain='static')
    configure_blueprints(app)
    configure_errorhandlers(app)
    configure_extensions(app)
    return app

def configure_blueprints(app):
    app.register_blueprint(frontend, url_prefix='')
    app.register_blueprint(member, url_prefix='/member')

def configure_extensions(app):
    app.jinja_env.add_extension("jinja2.ext.loopcontrols")
    db.init_app(app, dbs='DBS')
    redisCache.init_app(app)
    bcrypt.init_app(app)
    # 管理系统和登陆系统
    from admin import Admin
    admin = Admin(app)


def configure_errorhandlers(app):
    @app.errorhandler(500)
    def server_error(error):
        import traceback
        import syslog
        exstr = traceback.format_exc()
        syslog.openlog('iprdao.com')
        syslog.syslog(syslog.LOG_ERR, exstr)
        syslog.closelog()
        # ----------------------------------
        if request.is_xhr:
            return jsonify(error=u'抱歉，出错啦')
        return render_template("errors/500.html", error=error), 500

    @app.errorhandler(503)
    def server_slow(error):
        if request.is_xhr:
            return jsonify(error=u'抱歉，出错啦')
        return render_template("errors/503.html", error=error), 503

    @app.errorhandler(404)
    def server_nofound(error):
        if request.is_xhr:
            return jsonify(error=u'抱歉，出错啦')
        return render_template("errors/404.html", error=error), 404

    @app.errorhandler(403)
    def server_forb(error):
        if request.is_xhr:
            return jsonify(error=u'抱歉，出错啦')
        return render_template("errors/403.html", error=error), 403
