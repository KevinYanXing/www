# coding=utf-8
import json, werkzeug
from flask import request, get_flashed_messages, url_for
from wtforms.form import Form
from jinja2 import Markup
from wtforms.fields import HiddenField, StringField, SelectField, SelectMultipleField, BooleanField, TextAreaField, PasswordField
from wtforms.widgets import HiddenInput, CheckboxInput
from wtforms.compat import string_types, text_type
from app.help import Help
from datetime import datetime
from time import mktime

def _is_hidden(field):
    """Detect if the field is hidden."""
    if isinstance(field, HiddenField):
        return True
    if isinstance(field.widget, HiddenInput):
        return True
    return False

_Field_Args = ['label', 'validators', 'filters', 'description', 'id', 'default', 'widget', '_form', '_name', '_prefix', '_translations', 'meta', 'choices']

class DCheckbox(CheckboxInput):
    """
    checkbox组件
    """
    Dtype = 'checkbox'

    def __init__(self, **kwargs):

        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DCheckbox, self).__init__(**kwargs)

class DUpload(HiddenField):
    """
    上传组件
    """
    Dtype = 'upload'

    def __init__(self, saver=None, remover=None, kvlist={}, max_size=1, max_files=1,
                 allow_ext='image/*', remove_cb=None, save_cb=None, **kwargs):
        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DUpload, self).__init__(**kwargs)
        # 上传到的地址
        if type(saver) == str:
            self.saver = url_for(saver, **kvlist)
        else:
            self.saver = saver()
        # 删除的地址
        if type(remover) == str:
            self.remover = url_for(remover)
        else:
            self.remover = remover()

        # 最大文件大小限制, 以MB为限制
        self.max_size = max_size
        # 上传最大文件数
        self.max_files = max_files
        # 上传文件允许的文件类型
        self.allow_ext = allow_ext
        # 上传文件附加的参数
        self.kvlist = kvlist
        # 相关回调
        self.remove_cb = remove_cb
        self.save_cb = save_cb

    def process_data(self, value):
        if value:
            if type(value) != list:
                value = [value]
            ret = []
            for item in value:
                ret.append(str(item))
            self.data = ','.join(ret)
        else:
            self.data = value


class DInput(StringField):
    """
    允许带其它参数的输入框
    """
    Dtype = 'text'

    def __init__(self, **kwargs):

        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DInput, self).__init__(**kwargs)

class DDate(StringField):
    """
    允许带其它参数的输入框
    """
    Dtype = 'date'

    def __init__(self, **kwargs):

        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DDate, self).__init__(**kwargs)

    def process_data(self, value):
        if value:
            self.data = datetime.fromtimestamp(value).strftime('%Y-%m-%d')
        else:
            self.data = value
    def process_formdata(self, valuelist):
        if valuelist:
            self.data = mktime(datetime.strptime(valuelist[0], '%Y-%m-%d').timetuple())

class DPassword(PasswordField):
    Dtype = 'text'

    def __init__(self, **kwargs):

        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DPassword, self).__init__(**kwargs)


class DText(TextAreaField):
    """
    允许带其它参数的输入框
    """
    Dtype = 'text'

    def __init__(self, **kwargs):
        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DText, self).__init__(**kwargs)

class DHtmlText(TextAreaField):
    """
    允许带其它参数的输入框
    """
    Dtype = 'html'

    def __init__(self, **kwargs):
        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DHtmlText, self).__init__(**kwargs)

class DBoolField(BooleanField):
    Dtype = 'boolean'

    def __init__(self, false_values=None, col=6, **kwargs):
        if false_values is not None:
            self.false_values = false_values
        self.col = col
        super(DBoolField, self).__init__(**kwargs)


class DSelect(SelectField):
    """
    允许带其它参数的选择框
    """
    Dtype = 'select'

    def __init__(self, fun=None, col=6, **kwargs):
        for k in kwargs.keys():
            if k not in _Field_Args and k != 'coerce':
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DSelect, self).__init__(**kwargs)
        self.col = col
        if fun:
            self.choices = fun(self)

class LocSelect(SelectField):
    """
    地区选择框

    使用示例:
    prov = LocSelect(label=u'省份', col=3, Dtype='loc_select', city_id='city')
    city = LocSelect(label=u'城市', col=3, coerce=str)
    """
    Dtype = 'select'

    @staticmethod
    def load_province_choices():
        from app.utils.location import PROVINCE
        return [(x, x) for x, y in PROVINCE]

    @staticmethod
    def load_city_choices():
        from app.utils.location import PROVINCE
        r = []
        for k, v in PROVINCE:
            r.extend(v)
        return [(x, x) for x in r]

    def __init__(self, col=6, **kwargs):
        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(LocSelect, self).__init__(**kwargs)
        self.col = col
        if hasattr(self, 'city_id'):
            self.choices = self.load_province_choices()
        else:
            self.choices = self.load_city_choices()

    def pre_validate(self, form):
        pass

class DMuiltSelect(SelectMultipleField):
    """
    多选
    """
    Dtype = 'multi_select'

    def __init__(self, fun=None, col=6, lg=6, **kwargs):
        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DMuiltSelect, self).__init__(**kwargs)
        self.col = col
        self.lg = lg
        if fun:
            self.choices = fun(self)


class DMuiltSearchSelect(SelectMultipleField):
    """
    多选
    """
    Dtype = 'multi_search_select'

    def __init__(self, fun=None, col=6, lg=6, **kwargs):
        for k in kwargs.keys():
            if k not in _Field_Args:
                setattr(self, k, kwargs[k])
                kwargs.pop(k)
        super(DMuiltSearchSelect, self).__init__(**kwargs)
        self.col = col
        self.lg = lg
        if fun:
            self.choices = fun(self)


class BaseForm(Form):

    button_text = u'提交'

    isTop = True

    def __init__(self, template=None, **kwargs):
        self.template = template
        self.kwargs = kwargs
        self.obj = self.item()
        # 自动处理表单数据
        if self.is_submitted:
            formdata = request.form
            if request.files:
                formdata = formdata.copy()
                formdata.update(request.files)
            elif request.json:
                formdata = werkzeug.datastructures.MultiDict(request.json)
        else:
            formdata = None

        super(BaseForm, self).__init__(formdata=formdata, obj=self.obj, **kwargs)


    def item(self):
        """
        根据请求的URL参数获取单条数据，这个方法如果需要的话请重载。
        一般在修改数据的时候才需要这个方法有返回
        如果不是修改，新增的时候，根据URL参数判断是否带有ID，如果不带又ID直接返回None
        只有在非提交数据的时候才会请求这个方法
        从这个方法得到数据后，会自动将同名属性赋值到表单项中
        :return:
        """
        return None

    def submit(self):
        """
        一定要重载此方法,用于表单提交成功后的操作
        成功，直接返回跳转到的地址
        失败，返回None或者False
        成功失败信息都字节写入flash里面即可
        :return:
        """
        raise NotImplementedError(u'请重载表单的submit方法')

    def run(self, **kwargs):
        """
        全局调用执行，根据是submit还是普通来返回
        :return:
        """
        if self.is_submitted:
            if not self.validate():
                return self._valid_error()

            ret = self.submit()
            if not ret:
                return self._submit_error()

            return self._submit_ok(ret)
        else:
            return self.render(**kwargs)

    def render(self, **kwargs):
        """
        返回响应内容
        """
        if not self.template:
            template = request.endpoint.replace('.', '/') + '.html'
        else:
            template = self.template

        kwargs['form'] = self

        return Help.render(template, **kwargs)


    def _submit_ok(self, url):
        """
        执行成功后，跳转到URL
        """
        if url.find('submit_') == 0:
            return self._show_submit_finish({'params': url[7:]}, 'submit_finish')

        return self._show_submit_finish({'url': url}, 'redirect')

    def _submit_error(self):
        """
        返回flash里面的
        """
        msgs = get_flashed_messages(with_categories=True)
        err = {}
        for k, v in msgs:
            if k not in err.keys():
                err[k] = [v]
            else:
                err[k].append(v)
        return self._show_submit_finish(err, 'errors')

    def _valid_error(self):
        """
        返回JS代码
        """
        err = dict()
        for field in self:
            if field.errors:
                for error in field.errors:
                    err[field.name] = unicode(error)
                    if _is_hidden(field):
                        err[field.name + '__hidden'] = True
        # 将这个err通过调用指定的JS方法实现
        return self._show_submit_finish(err, 'validate')

    def _show_submit_finish(self, val, method):
        """
        输出JS响应
        :param val:
        :param method:
        :return:
        """

        if method == 'validate' or self.isTop:
            val = json.dumps(val)
            val = 'top.DAMY.loader.%s(%s);' %(method, val)
        else:
            val['me'] = True
            val = json.dumps(val)
            val = 'parent.DAMY.loader.%s(%s);' %(method, val)

        val = '<html><head><noscript><meta http-equiv="refresh" content="0;url=about:noscript"></noscript><script type="text/javascript">%s</script></head></html>' %val
        return Markup(val)

    @property
    def is_submitted(self):
        """
        检查是不是表单提交的操作
        """
        return request and request.method in ("PUT", "POST")


    def form(self, id=None, action='', target='__hidden_call', **kwargs):
        """
        在HTML页面中调用此方法来实现form标签的render
        """
        form_name = type(self).__name__
        if not id:
            id = form_name
        result = []
        result.append(u'<form action="')
        result.append(action)
        result.append(u'" method="post" class="ajax_form" onsubmit="DAMY.loader.submit(this);" target="'+target+ u'" data-bind="ajax_form" id="')
        result.append(id)
        result.append(u'_form" name="')
        result.append(form_name)
        result.append(u'_form"')
        for k, v in kwargs.items():
            result.append(' '+k+'="' + v + '"')
        result.append(u'>')
        result.append(self.hidden_tag())

        return Markup(u"".join(result))

    def hidden_tag(self, *fields):
        """
        Wraps hidden fields in a hidden DIV tag, in order to keep XHTML
        compliance.

        .. versionadded:: 0.3

        :param fields: list of hidden field names. If not provided will render
                       all hidden fields, including the CSRF field.
        """

        if not fields:
            fields = [f for f in self if _is_hidden(f)]

        rv = [u'<div style="display:none;">']
        for field in fields:
            if isinstance(field, string_types):
                field = getattr(self, field)
            rv.append(text_type(field))
        rv.append(u"</div>")

        return Markup(u"".join(rv))