# coding=utf-8
from flask.ext.bcrypt import Bcrypt
from damyunit.dredis import DRedis

redisCache = DRedis()
bcrypt = Bcrypt()