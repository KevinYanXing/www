//String.prototype.trim = function()
//{
//    return this.replace(/^\s*|\s*$/g,"");
//};
//Array.prototype.remove = function(n)
//{
//    if (n < 0)
//    {
//        return this;
//    }
//    else
//    {
//        return this.slice(0, n).concat(this.slice(n + 1, this.length));
//    }
//};
var DAMY = new Object();
DAMY.loader = {
    hornTip_flag: !0,
    stack_top_right:{
            "dir1": "down",
            "dir2": "left",
            "push": "top",
            "spacing1": 10,
            "spacing2": 10
    },
    ui_lineMove: function(t,e,n,s,i){
        return 0===s?t.find(".ui-select-listBox-l-red").css("left",e*n-1).width(e-1):(null==s&&(s=200),t.find(".ui-select-listBox-l-red").stop().animate({left:e*n-1},s,function(){return i?i():void 0}))
    },
    ui_selectListBox: function(t,e){
        var n;
        return n=this,$(".ui-select-listBox").each(function(){var s,i,o;return s=$(this),o=$(this).find(".ui-select-listBox-list").outerWidth(),i=$(this).find(".ui-select-listBox-list--now").index(),n.ui_lineMove(s,o,i,0),$(this).find(".ui-select-listBox-list").hover(function(){var i;return i=$(this).index(),n.ui_lineMove(s,o,i,e),$(this).click(function(){return t?($(this).siblings(".ui-select-listBox-list").removeClass("ui-select-listBox-list--now"),$(this).addClass("ui-select-listBox-list--now"),t(i)):void 0})}),$(this).mouseleave(function(){var t;return t=$(this).find(".ui-select-listBox-list--now").index(),n.ui_lineMove(s,o,t,e)})})
    },
    setUserSecurityPop: function(){
        var t,e,n;
        return t=$(".j_userSecurityIcon"),n=".j_userSecurityPop",e=0,t.bind("mouseenter",function(){var t,s,i,o;return $(n).length>0&&$(n).remove(),i='<div class="user-security-pop j_userSecurityPop" style="z-index: 10001;"><em class="user-security-pop-ico"></em><div class="user-security-pop-content"></div></div>',t=$(i),t.find(".user-security-pop-content").html($(this).attr("data-msg")),o=$(this).offset().top,s=$(this).offset().left,t.css({top:o+50,left:s-93,opacity:0}),$("body").append(t),setTimeout(function(){return t.css({top:o+40,opacity:1})},10),clearTimeout(e),t.bind("mouseleave",function(){return e=setTimeout(function(){return $(n).remove()},500)}),t.bind("mouseenter",function(){return clearTimeout(e)})}).bind("mouseleave",function(){return e=setTimeout(function(){return $(n).remove()},500)})
    },
    hornTip:function(t){
        var e,n;
        return n=$("#J_ui_assetTip-box"),t=t||3e3,e=null,n.find("li").length>1&&DAMY.loader.hornTip_flag&&(DAMY.loader.hornTip_flag=!1,n.hover(function(){return clearInterval(e)},function(){return e=setInterval(function(){var t,e;return t=n.find("li:first"),e=t.height(),t.animate({marginTop:0-e+"px"},1e3,function(){return t.css("marginTop",0).appendTo(n)})},t)}).trigger("mouseleave"))
    },
    submit : function(frm){
        var loading = $(frm).attr('loading');
        if(loading){
            alert('正在提交中，请稍后...');
            return false;
        }
        var obj = $(frm).find('button[type="submit"]');
        obj.attr('data-text', obj.html());
        obj.html('处理中...');
        $(frm).attr('loading', 'true');
        return true;
    },
    resetForm: function(){
        var obj = $('button[type="submit"]');
        if(!obj.length){
            obj = $("#diaolog_iframe").contents().find('button[type="submit"]');
            obj.html(obj.attr('data-text'));
            $("#diaolog_iframe").contents().find('form').removeAttr('loading');
        }else{
            obj.html(obj.attr('data-text'));
            $('form').removeAttr('loading');
        }
    },
    validate:function(msg){
        for (var name in msg){
            if(msg[name + '__hidden']){
                this.showtips(msg[name], 'error');
            }else{
                var obj = $('form');
                if(!$('#'+name).length){
                    obj = $("#diaolog_iframe").contents();
                }
                obj.find('#' + name).focus(function () {
                    var id = $(this).attr('id');
                    obj.find('#label_' + id).removeClass('state-error');
                    obj.find('#info_' + id).html('');
                });
                obj.find('#' + name).click(function () {
                    var id = $(this).attr('id');
                    obj.find('#label_' + id).removeClass('state-error');
                    obj.find('#info_' + id).html('');
                });
                obj.find('#label_' + name).addClass('state-error');
                obj.find('#info_' + name).html(msg[name]);
            }
        }
        this.resetForm();
    },
    errors:function(msg){
        for(var name in msg){
            if(name && msg[name]){
                for(var idx in msg[name]){
                    this.showtips(msg[name][idx], name);
                }
            }
        }
        this.resetForm();
    },
    showtips:function(msg, msg_type){
        new PNotify({
            title: '数据提交',
            text: msg,
            shadow: true,
            opacity: 1,
            addclass: 'stack_top_right',
            type: msg_type,
            stack: this.stack_top_right,
            width: '290px'
        });
    },
    redirect:function(args){
        if(args.me){
            location.href = args.url;
        }else{
            parent.location.href = args.url;
        }
    },
    remove_img:function(obj){
        var url = $(obj).attr('url_data');
        var id = $(obj).attr('url_id');
        var field_id = $(obj).attr('field_id');
        if(url.indexOf('?')!=-1){
            url = url + '&id=' + id;
        }else{
            url = url + '?id=' + id;
        }
        $.get(url, function(data){
            $(obj).parent().remove();
            var field_val = $('#' + field_id).val().split(',').filter(function(a){ return a!=id });
            $('#' + field_id).val(field_val.join(','));
        });
    },
    show_loading:function(div_id,des){
        html = '<div class="loading-point"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div>';
        if(des!=null & des!="" & des != undefined){
            html += '<div class="text-danger">' + des + '</div>';
        }
        html += '</div>';
        $("#"+div_id).html(html);
    },
    showUrlBox: function(url,height,width,title){
        $('#diaolog_iframe').attr('src',url);
        $('#diaolog_iframe').css('height',(height - 50) + 'px')
        $("#dialog").dialog( "option", "height",  height );
        $("#dialog").dialog( "option", "width",  width );
        $("#dialog").dialog( "option", "title",  title );
        $("#dialog").dialog("open");
        return false;
    },
    closeUrlBox: function(method){
        if(method){
            location.href = location.href;
        }else{
            $("#dialog").dialog("close");
        }
    },
    submit_finish: function (cb) {
        eval(cb.params + '();');
    }
};
$(function(){
    if($('#dialog').length){
        $('#dialog').dialog({
                    autoOpen: false,
                    resizable:false,
                    height: 140,
                    width:200,
                    modal: true,
                    buttons: {}
        });
    }
});
function file_upload_func(id, max_files, remover) {
    var dataType = 'json';
    var field_id = '#' + id;
    if ($.NV('name') == "firefox" || $.NV('name') == "chrome") {
        dataType = '';
    }
    $('#upload_' + id).fileupload({
        dataType: dataType,
        send: function (e) {
            var tmp = $(field_id).val();
            if (tmp) tmp = tmp.split(',');
            if (tmp.length >= max_files) {
                alert('只能上传' + max_files + '张图片');
                return false;
            }
        },
        done: function (e, data) {
            var json = data.result;
            if(typeof json == "string"){
                json = $.parseJSON(json);
            }
            //alert(json);
            //json = $.parseJSON(json);
            //json = eval(json)[0];
            var th_pics = $('#thpics_' + id);
            $.each(json, function (index, file) {
                if (file.result) {
                    var html_str = '<div class="img_item">' +
                        '<img id="pti_' + id + '" src="' + file.url + '" width="223" height="168">' +
                        '<span class="item_del" field_id="' + id + '" url_data="' + remover + '" url_id="'
                        + file.id + '" onclick="DAMY.loader.remove_img(this)">删除</span></div>';
                    th_pics.append(html_str);
                    html_str = $(field_id).val();
                    if (html_str) {
                        html_str = html_str + ',';
                    }
                    $(field_id).val(html_str + file.id);
//                                total_files += 1;
                } else {
                    alert("上传失败:" + file.errorMsg + "!");
                }
            });
        },
        error: function (e, data) {
            var json = data.result;
            try {
                json = $.parseJSON(json);
            } catch (err) {
                json = e.responseText;
                if (json == null || json == undefined) {
                    alert("上传失败.");
                    return;
                }
            }
        },
        progressall: function (e, data) {
            var progress = parseInt(data.loaded / data.total * 100, 10);
        }
    }).prop('disabled', !$.support.fileInput)
        .parent().addClass($.support.fileInput ? undefined : 'disabled');
}