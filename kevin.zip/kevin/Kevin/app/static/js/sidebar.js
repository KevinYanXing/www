$(function(){
    var i = $('<div class="ui-sidebar"></div>');
    i.html(sidebar_html);
    $("body").append(i);
    $(window).bind("scroll",function(){
        scrollTop = $(window).scrollTop(), scrollTop > 200 ? i.find(".backtop").css("display", "block") : i.find(".backtop").css("display", "none");

    });
    i.find(".backtop").bind("click", function () {
        $("body, html").animate({
            scrollTop: 0
        }, 500, "easeInOutQuint")
    });
});