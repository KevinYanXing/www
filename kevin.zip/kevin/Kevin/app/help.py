# coding=utf-8
from time import time, mktime
from flask import render_template, g
from datetime import date, datetime, timedelta


class Help:
    def __init__(self):
        pass

    @staticmethod
    def get_curr_user_id():
        """
        获取当前在操作的实际用户ID
        :return:
        """
        from flask import session
        from bson import ObjectId
        if session.get('admin_id'):
            ret = ObjectId(session.admin_id)
        else:
            ret = Help.currentUser().mongo_id
        return ret

    @staticmethod
    def split(val, sp):
        if not val:
            return []
        return val.split(sp)

    @staticmethod
    def year_days():
        """
        计算今年总天数
        :return:
        """
        n = datetime.now()
        span = (mktime(datetime(n.year + 1, 1, 1).timetuple()) - mktime(datetime(n.year, 1, 1).timetuple())) / 86400.00
        return span

    @staticmethod
    def get_weekday(ts):
        week = [u'星期一', u'星期二', u'星期三', u'星期四', u'星期五',u'星期六',u'星期日']
        week_no = date.fromtimestamp(ts).isoweekday()
        return week[week_no - 1]


    @staticmethod
    def render(template, **kwargs):
        kwargs['help'] = Help
        return render_template(template, **kwargs)

    @staticmethod
    def format_money(val):
        if type(val) == str or type(val) == unicode:
            val = float(val)
        val = round(val, 2)
        val = str(val)
        if val[-2:].find('.') != -1:
            val = val + '0'
        return val

    @staticmethod
    def format_ts(ts, format='%Y-%m-%d %H:%M:%S'):
        if not ts:
            return None
        if type(ts) == int:
            ts = float(ts)

        if type(ts) == float:
            ts = datetime.fromtimestamp(ts)
        elif not ts:
            return ''
        format = format.encode('utf-8')
        try:
            ret = ts.strftime(format)
        except:
            return ts

        return ret.decode('utf-8')

    @staticmethod
    def str_to_ts(val, formate='%Y-%m-%d %H:%M:%S'):
        """
        将文本时间转换成时间戳
        """
        tmp = datetime.strptime(val, formate)
        return mktime(tmp.timetuple())


    @staticmethod
    def time_left(ts):
        """
        计算多少小时或者多少天之前
        :param ts:
        :return:
        """
        try:
            ts = float(ts)
        except:
            ts = time()
        tleft = time() - ts
        if tleft < 86400:
            return u'%d小时前' % int(tleft / 3600)

        return u'%d天前' % int(tleft / 86400)

    @staticmethod
    def format_short_money(val, tag=None):
        if not val:
            return u'0.00'
        val = float(val)
        if val > 10000:
            val = (val/10000)
            if not tag or not isinstance(tag, str):
                val = str(float('%.2f' % val)) + u'万'
            else:
                val = u'%s<%s>万</%s>' % (str(float('%.2f' % val)), tag, tag)
        else:
            val = '%.2f' % val
        return val

    @staticmethod
    def format_float(val):
        return float('%.2f' % val)

    @staticmethod
    def gt_today(ts):
        return ts > time()

    @staticmethod
    def gt_yesterday(ts):
        return ts > mktime(date.timetuple(date.today() - timedelta(1)))

    @staticmethod
    def list_join(l, s):
        lis = [str(item) for item in l]
        return s.join(lis)



    @staticmethod
    def get_yes_ts():
        return mktime((date.today() - timedelta(days=1)).timetuple())


    @staticmethod
    def totalPage(total, perpage=15):
        """
        计算总页数
        :param count:
        :return:
        """
        ret = total % perpage
        if ret == 0:
            ret = total / perpage
        else:
            ret = total / perpage + 1
        return ret

    @staticmethod
    def today_ts():
        return time()

    @staticmethod
    def notify_title(cat):
        from app.message import Message
        if cat == Message.WARNING:
            return u'注意:'
        elif cat == Message.ERROR:
            return u'出错了:'
        elif cat == Message.SUCCESS:
            return u'成功:'
        else:
            return u'提示:'

    @staticmethod
    def currentUser():
        """
        获取当前用户对象
        :return:
        """
        if not hasattr(g, 'identity') or not hasattr(g.identity, 'user'):
            return None
        return g.identity.user

    @staticmethod
    def anns():
        from iprdb.iprdao.helper import Article
        ret = Article.top(sort=[('d', -1)], nums=5, typeid=3)
        if not ret:
            ret = [Article(data={'title': u'暂无公告', '_id': None})]
        return ret

    @staticmethod
    def build_args(css, value, readonly, cols, rows):
        args = {'class': 'input required ' + css, 'readonly': readonly}
        if cols:
            args['cols'] = cols
        if value:
            args['value'] = value
        if rows:
            args['rows'] = rows

        return args