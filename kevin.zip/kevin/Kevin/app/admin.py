# coding=utf-8
from damyweb.base import Damy
from damyweb.base import MenuCategory
from damydb.user import User

from ext import redisCache, bcrypt

class Admin:
    def __init__(self, app):
        admin = Damy(app, name=u'商城', user_model=User, redis=redisCache, bcrypt=bcrypt)

        admin.user = MenuCategory(name='user', text=u'管理员功能')
        admin.manager = MenuCategory(name='manager', text=u'客服功能')
        # Add views
