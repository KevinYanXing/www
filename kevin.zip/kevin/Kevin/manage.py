# coding=utf-8
from app import create_app
from flask.ext.script import Manager
from damydb.user import User
from app.ext import bcrypt

app = create_app("config.cfg")
manage = Manager(app)

@manage.command
def init(u):
    # 测试
    user = User.findone(u=u)
    if not user:
        user = User()
        user.u = u
        user.n = u'严滔'
        user.p = bcrypt.generate_password_hash('123456')
        user.r = 300
    else:
        user.p = bcrypt.generate_password_hash('123456')
        user.r = 300
    user.save()
    print 'finish'

if __name__ == "__main__":
    manage.run()
